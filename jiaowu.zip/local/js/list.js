"use strict";

var titleText = "教务系统";

var jsonObj = [{
    "appName": "教务系统",
    "appImgUrl": "../img/OA.png",
    "appLink": "http://117.35.118.209/default2.aspx"
}];

if (window.yspUser && window.yspUser.getMenu) {
    jsonObj = EAPI.devices.android.getMenus();
    next();
} else {
    EAPI.devices.ios.getMenus(function (data) {
        jsonObj = data;
        next();
    });
}

function next() {
    var title = document.getElementById('title');
    title.textContent = titleText;
    document.title = titleText;
    var menu = document.getElementById('menu');
    var menu_list = document.createElement('ul');
    menu_list.className = "list";
    jsonObj.forEach(function (elem) {
        var li = document.createElement('li');
        li.className = "item item-linked";
        var a = document.createElement('a');
        a.href = elem.appLink;
        var img = document.createElement('img');
        img.src = elem.appImgUrl;
        img.width = "32";
        var div_media = document.createElement('div');
        div_media.className = "item-media";
        var div_main = document.createElement('div');
        div_main.className = "item-main";
        var h3 = document.createElement('h3');
        h3.className = "item-title";
        h3.textContent = elem.appName;
        var span = document.createElement('span');
        span.className = "icon icon-right-nav item-icon";
        div_main.appendChild(h3);
        div_main.appendChild(span);
        div_media.appendChild(img);
        a.appendChild(div_media);
        a.appendChild(div_main);
        li.appendChild(a);
        menu_list.appendChild(li);
    });
    menu.appendChild(menu_list);
}
