window.onbeforeprint = function(){
    for(var i=0; i<document.all.length; i++){
        if (document.all(i).className=="HideOnPrint")
            document.all(i).style.display = "none";
        if (document.all(i).className=="RemoveOnPrint")
            document.all(i).style.visibility = "none";
        if (document.all(i).className=="ShowOnPrint")
            document.all(i).style.display = "block";
    }
}

window.onafterprint = function(){
    for(var i=0; i<document.all.length; i++){
        if (document.all(i).className=="HideOnPrint")
            document.all(i).style.display = "block";
        if (document.all(i).className=="RemoveOnPrint")
            document.all(i).style.visibility = "visible";
        if (document.all(i).className=="ShowOnPrint")
            document.all(i).style.display = "none";
    }
}

function printPart(strHTML){
   var newwin = window.open();
   newwin.document.open();
   newwin.document.write(strHTML);
   newwin.document.close();
   newwin.focus();
   newwin.print();
}

function preview(strHTML){
   var newwin = window.open();
   newwin.document.open();
   newwin.document.write(strHTML);
   newwin.document.close();
   newwin.focus();
}

function PrintSuccess(TableName){
   var strHTML = buildPrintHTML(TableName);
   printPart(strHTML);
}

///����ѧ���ɼ�
function buildPrintHTML(TableName){
    var oTable = window.document.getElementById(TableName);
    var rowID =  oTable.parentNode.parentNode.parentNode.rowIndex - 1;
    var reg = new RegExp("<tbody>","ig")
    //�����ɼ��б���ʹ֧�ַ�ҳ
    var newOuterHTML = "<table width='100%'>" + oTable.innerHTML + "</table>";
    newOuterHTML = newOuterHTML.replace(reg,"<thead>");
    var position = newOuterHTML.indexOf("</TR>");
    if(position == -1)
    {
		position = newOuterHTML.indexOf("</tr>");
    }
    newOuterHTML = newOuterHTML.substring(0,position+5) + "</thead><tbody>" + newOuterHTML.substr(position+5)

    var strHTML;
    strHTML = "<html><head><title>ѧ��ѧϰ�ɼ�</title><link href='Default.css' type='text/css' rel='stylesheet'>";
    strHTML += "</head><body>";
    strHTML += "<TABLE width='100%'>"
    strHTML += "<thead><TR><TD ColSpan='3' class='tdline'>" + window.document.getElementById("Label4").parentNode.innerHTML + "</TD></TR>"
    strHTML += "<TR><TD>" + window.document.getElementById("tabcj").rows[rowID].cells[1].innerHTML + window.document.getElementById("tabcj").rows[rowID].cells[2].innerHTML + "</TD>";
    strHTML += "<TD>" + window.document.getElementById("tabcj").rows[rowID].cells[3].innerHTML + window.document.getElementById("tabcj").rows[rowID].cells[4].innerHTML + "</TD>";
    strHTML += "<TD>" + window.document.getElementById("tabcj").rows[rowID].cells[5].innerHTML + window.document.getElementById("tabcj").rows[rowID].cells[6].innerHTML + "</TD></TR>";
    strHTML += "<TR><TD ColSpan=\'2\'>" + window.document.getElementById("tabcj").rows[rowID].cells[7].innerHTML + window.document.getElementById("tabcj").rows[rowID].cells[8].innerHTML + "</TD>";
    strHTML += "<TD>" + window.document.getElementById("tabcj").rows[rowID].cells[9].innerHTML + window.document.getElementById("tabcj").rows[rowID].cells[10].innerHTML + "</TD></TR></thead>";
    strHTML += "<tbody><TR><TD ColSpan='3'>" + newOuterHTML + "</TD></TR></tbody></TABLE>";
    strHTML += "</body></html>";

    return strHTML;
}
function PrintDgsxzz(TableName){
   var strHTML = buildPrintDgsxzz(TableName);
   printPart(strHTML);
}

function buildPrintDgsxzz(TableName){
   var oTable = window.document.getElementById(TableName);
   // var rowID =  oTable.parentElement.parentElement.rowIndex - 1;

    var strHTML;
    strHTML = "<html><head><title></title><link href='Default.css' type='text/css' rel='stylesheet'>";
    strHTML += "<TABLE width='645' CellPadding='3' CellSpacing='0' Border='0' align='center' id='printTable'><TR><TD >";
    strHTML += "<TABLE width='100%'>";
	strHTML += "<thead>" + oTable.rows(0).outerHTML;+ "</thead>";
	strHTML += "<tbody>";
	strHTML += oTable.rows(1).outerHTML;
    strHTML += oTable.rows(2).outerHTML;
    strHTML += oTable.rows(3).outerHTML;
    strHTML += oTable.rows(4).outerHTML;
	strHTML +=  "</tbody>";
	strHTML +=  "</table>";
    strHTML += "</TD></TR></TABLE>";
    strHTML += "</body></html>";

    return strHTML;
}
function PrintJXRL(TableName){
    strHTML = buildPrintJXRL(TableName);
    var winContentDoc = window.document.getElementById("oFrame");
    winContentDoc.contentWindow.document.open();
	winContentDoc.contentWindow.document.write(strHTML);
	winContentDoc.contentWindow.document.close();

    oFrame.focus();
	oFrame.print();
}

function buildPrintJXRL(TableName){
    var oTable = window.document.getElementById(TableName);
    var rowID =  oTable.parentElement.parentElement.rowIndex - 1;

    var strHTML;
    strHTML = "<html><head><title></title><link href='Default.css' type='text/css' rel='stylesheet'>"
    strHTML += "<TABLE width='645' CellPadding='3' CellSpacing='0' Border='0' id='printTable'>";
    strHTML += oTable.rows(0).outerHTML;
    strHTML += oTable.rows(1).outerHTML;
    strHTML += oTable.rows(2).outerHTML;
    strHTML += oTable.rows(3).outerHTML;
    strHTML += oTable.rows(4).outerHTML;
    strHTML += "<TR><TD colspan='4'>" + buildPrintJXRLBodyHTML() + "</TD></TR>";
    strHTML += "</TABLE>";
    strHTML += "</body></html>";

    return strHTML;
}

function buildPrintJXRLBodyHTML(){
    var vTable = window.document.getElementById("JXRL");
    var BodyHTML = "";
    if (vTable.rows.length > 10){
        var oTableHeader = vTable.rows(0).outerHTML;
        var oTableFooter = "<TR><TD Width='30pt' NoWrap>��ע</TD><TD ColSpan='4' vAlign=top>" + document.all("txtBZ").innerHTML + "</TD></TR>";
        BodyHTML = "<TABLE id='JXRL' CellPadding='3' CellSpacing='0' Border='1' BorderColor='#B0B0B0' HEIGHT='820pt' Style='Border-CollApse:CollApse; Width:100%'>";
        BodyHTML = BodyHTML + oTableHeader;
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(1).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(1).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(1).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(1).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(1).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(2).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(2).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(2).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(2).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(2).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(3).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(3).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(3).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(3).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(3).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(4).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(4).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(4).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(4).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(4).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(5).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(5).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(5).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(5).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(5).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(6).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(6).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(6).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(6).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(6).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(7).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(7).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(7).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(7).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(7).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(8).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(8).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(8).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(8).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(8).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "</TABLE><br><Div align=right>�� <b>1</b> ҳ</Div><P Class='PageNext'></P>";
        BodyHTML = BodyHTML + "<TABLE id='JXRL2' CellPadding='3' CellSpacing='0' Border='1' BorderColor='#B0B0B0' HEIGHT='910pt' Style='Border-CollApse:CollApse; Width:100%'>" ;
        BodyHTML = BodyHTML + oTableHeader;
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(9).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(9).cells(1).children[0].value + "</PRE></TD><TD>" + vTable.rows(9).cells(2).children[0].value + "</TD><TD>" + vTable.rows(9).cells(3).children[0].value + "</TD><TD>" + vTable.rows(9).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(10).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(10).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(10).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(10).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(10).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(11).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(11).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(11).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(11).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(11).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(12).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(12).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(12).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(12).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(12).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(13).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(13).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(13).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(13).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(13).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(14).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(14).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(14).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(14).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(14).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(15).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(15).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(15).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(15).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(15).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(16).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(16).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(16).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(16).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(16).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + oTableFooter + "</TABLE><br><br><br><Div align=right>�� <b>2</b> ҳ</Div>";

    }
    else{
        var oTableHeader = vTable.rows(0).outerHTML;
        var oTableFooter = "<TR><TD Width='30pt' NoWrap>��ע</TD><TD ColSpan='4' vAlign=top>" + document.all("txtBZ").innerHTML + "</TD></TR>";
        BodyHTML = "<TABLE id='JXRL' CellPadding='3' CellSpacing='0' Border='1' BorderColor='#B0B0B0' HEIGHT='820pt' Style='Border-CollApse:CollApse; Width:100%'>";
        BodyHTML = BodyHTML + oTableHeader;
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(1).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(1).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(1).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(1).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(1).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(2).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(2).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(2).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(2).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(2).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(3).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(3).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(3).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(3).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(3).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(4).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(4).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(4).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(4).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(4).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(5).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(5).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(5).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(5).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(5).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(6).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(6).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(6).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(6).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(6).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(7).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(7).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(7).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(7).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(7).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + "<TR>" + vTable.rows(8).cells(0).outerHTML + "<TD Valign=Top Width='70pt' nowrap><PRE>" + vTable.rows(8).cells(1).children[0].value + "</PRE></TD><TD Valign=Top Class='breakAll'><PRE>" + vTable.rows(8).cells(2).children[0].value + "</PRE></TD><TD Valign=Top Width='150pt' nowrap Class='breakAll'><PRE>" + vTable.rows(8).cells(3).children[0].value + "</PRE></TD><TD Valign=Top Width='35pt' nowrap>" + vTable.rows(8).cells(4).children[0].value + "</TD></TR>";
        BodyHTML = BodyHTML + oTableFooter + "</TABLE>";
    }
    return BodyHTML;
}

///xsxjyd.aspx
function PrintXsxjyd(TableName,Pdata){

   var strHTML = buildPrintXsxjyd(TableName,Pdata);

   printPart(strHTML);
}

function buildPrintXsxjyd(TableName,Pdata){
   var oTable = window.document.getElementById(TableName);
   // var rowID =  oTable.parentElement.parentElement.rowIndex - 1;

    var strHTML;
    strHTML = "<html><head><title></title><link href='Default.css' type='text/css' rel='stylesheet'>";
    strHTML += "<TABLE width='645' CellPadding='3' CellSpacing='0' Border='0' align='center' id='printTable'><TR><TD >";
    strHTML += "<TABLE width='100%'>";
	strHTML += "<thead><tr><th  colspan='8'>" + document.getElementById('trhead').innerHTML + "<br><br></th></tr></thead>";
	strHTML += "<tbody>";
	strHTML += "<tr>" + oTable.rows[0].innerHTML + "</tr>";
    strHTML += "<tr>" + oTable.rows[1].innerHTML + "</tr>";
	strHTML += "<TR><TD align=middle>ѧ ��</TD><TD colSpan=2 align=middle>" + Pdata[0] + "</TD> ";
	strHTML += "<TD align=middle>ѧ ��</TD><TD colSpan=2 align=middle>" + Pdata[1] + "</TD>";
	strHTML += "<TD align=middle>��ϵ�绰</TD><TD  align=middle>" + Pdata[2] + "</TD></TR>";
	strHTML += "<TR><TD align=middle>�춯����</TD><TD width='90' align=middle>" + Pdata[3] + "</TD>";
	strHTML += "<TD colSpan=2 noWrap align=middle>�춯����ʱ��</TD><TD colSpan=2 align=middle>" + Pdata[4] + "</TD>";
	strHTML += "<TD align=middle>�춯ԭ�� </TD><TD align=middle>" + Pdata[5] + "</TD></TR>";
	strHTML += "<TR><TD align=middle><BR>���� <P>����<BR><BR></P></TD><TD colSpan=7>" + Pdata[6] + "</TD></TR>";
	strHTML += "<tr>" + oTable.rows[5].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[6].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[7].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[8].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[9].innerHTML + "</tr>";
	/*strHTML += oTable.rows[0].outerHTML;
	strHTML += oTable.rows[1].outerHTML;
	strHTML += oTable.rows[5].outerHTML;
    strHTML += oTable.rows[6].outerHTML;
    strHTML += oTable.rows[7].outerHTML;
    strHTML += oTable.rows[8].outerHTML;
	strHTML += oTable.rows[9].outerHTML;*/
	strHTML +=  "</tbody>";
	strHTML +=  "</table>";
    strHTML += "</TD></TR></TABLE>";
    strHTML += "</body></html>";

    return strHTML;
}
function XszzyP(TableName,Pdata){

   var strHTML = buildPrintXszzy(TableName,Pdata);

   printPart(strHTML);
}

function buildPrintXszzy(TableName,Pdata){
   var oTable = window.document.getElementById(TableName);
   // var rowID =  oTable.parentElement.parentElement.rowIndex - 1;

    var strHTML;
    strHTML = "<html><head><title></title><link href='Default.css' type='text/css' rel='stylesheet'>";
    strHTML += "<TABLE width='645' CellPadding='3' CellSpacing='0' Border='0' align='center' id='printTable'><TR><TD >";
    strHTML += "<TABLE width='100%'>";
	strHTML += "<thead><tr><th  colspan='8'>" + document.getElementById('trhead').innerHTML + "<br><br></th></tr></thead>";
	strHTML += "<tbody>";
	strHTML += "<tr>" + oTable.rows[0].innerHTML + "</tr>";
    strHTML += "<tr>" + oTable.rows[1].innerHTML + "</tr>";
strHTML += " <tr><td colSpan='2' align='center'>ѧ������ѧԺ����ϸ��ַ��</td><td colSpan='4' align='center'>" + Pdata[5] + "</td>";
strHTML += " <td align='center'>��ϵ�绰</td><td>" + Pdata[1] + "</td></tr>";
strHTML += "<tr><td align='center' nowrap>��ѧ����</td><td>" + Pdata[7] + "</td>";
strHTML += "<td colSpan='3' align='center'>����ת��ѧԺ��רҵ</td><td colSpan='3'>" + Pdata[4] + "</td></tr>";
strHTML += "<tr><td align='center'>�γ��ۼƼ���</td><td>" + Pdata[6] + "</td>";
strHTML += "	<td colSpan='2' align='center'>�߿��ܷ�(�Ļ�����)</td><td colSpan='2'>" + Pdata[3] + "</td>";
strHTML += "	<td align='center'>�߿���</td><td>" + Pdata[2] + "</td></tr>";
strHTML += "<tr><td height='120' align='center'>����<br>����</td><td colSpan='7' align='left'>" + Pdata[0] + "</td></tr>";
	strHTML += "<tr>" + oTable.rows[6].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[7].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[8].innerHTML + "</tr>";
	strHTML += "<tr>" + oTable.rows[9].innerHTML + "</tr>";
		strHTML += "<tr>" + oTable.rows[10].innerHTML + "</tr>";
			strHTML += "<tr>" + oTable.rows[11].innerHTML + "</tr>";
	/*strHTML += oTable.rows[0].outerHTML;
	strHTML += oTable.rows[1].outerHTML;
	strHTML += oTable.rows[5].outerHTML;
    strHTML += oTable.rows[6].outerHTML;
    strHTML += oTable.rows[7].outerHTML;
    strHTML += oTable.rows[8].outerHTML;
	strHTML += oTable.rows[9].outerHTML;*/
	strHTML +=  "</tbody>";
	strHTML +=  "</table>";
    strHTML += "</TD></TR></TABLE>";
    strHTML += "</body></html>";

    return strHTML;
}
