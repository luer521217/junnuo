(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control19: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var oPage = {
        "currentPage": aSpan[0].textContent,
        "totalPage": aSpan[1].textContent,
        "totalRecords": aSpan[2].textContent
      };
      return oPage;
    },
    doAction_uiControl31: function (data, elem) {},
    getTemplate_uiControl31: function () {
      var selfTemplate = "const MyPage = React.createClass({\n  render:function(){\n    var data = this.props.data.customData;         return <div className=\"pagenation\"><span>第{data.currentPage}页/共{data.totalPage}页</span><span>总共{data.totalRecords}条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        data.totalPage,\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        data.totalRecords,\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control21: function (elem) {
      var info = [{
        "text": "首页",
        "index": "0"
      }, {
        "text": "上一页",
        "index": "1"
      }, {
        "text": "下一页",
        "index": "2"
      }, {
        "text": "末页",
        "index": "3"
      }];
      return info;
    },
    doAction_uiControl34: function (data, elem) {
      var index = parseInt(data.dataCustom);elem.querySelectorAll("div")[1].querySelectorAll("input")[index].dispatchEvent(new Event("click"));
      // elem.querySelectorAll("div")[1].querySelectorAll("input")[index].dispatchEvent(new Event("click"));
      // $(elem).children("div").eq(1).querySelectorAll("input")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl34: function () {
      var selfTemplate = "const MyBtn = React.createClass({\n\n\trender: function() {\n\n  \tvar data = this.props.data.customData;\n\n    var items = data.map( function(item) {\n\n    \treturn <span data-index={item.index}>{item.text}</span>\n\n    });\n\n    return <div onClick={this.onClick} className=\"pageBtn\">{items}</div>\n\n  },\n\n  onClick: function(e) {\n\n  \tvar target = e.target;\n\n    var index = target.getAttribute(\"data-index\");\n\n    var handler = this.props.customHandler;\n\n    handler({\n\n    \tdata: index\n\n    });\n\n  }\n\n});\n\nexport default MyBtn;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n\tvalue: true\n});\nvar MyBtn = React.createClass({\n\tdisplayName: \"MyBtn\",\n\n\n\trender: function render() {\n\n\t\tvar data = this.props.data.customData;\n\n\t\tvar items = data.map(function (item) {\n\n\t\t\treturn React.createElement(\n\t\t\t\t\"span\",\n\t\t\t\t{ \"data-index\": item.index },\n\t\t\t\titem.text\n\t\t\t);\n\t\t});\n\n\t\treturn React.createElement(\n\t\t\t\"div\",\n\t\t\t{ onClick: this.onClick, className: \"pageBtn\" },\n\t\t\titems\n\t\t);\n\t},\n\n\tonClick: function onClick(e) {\n\n\t\tvar target = e.target;\n\n\t\tvar index = target.getAttribute(\"data-index\");\n\n\t\tvar handler = this.props.customHandler;\n\n\t\thandler({\n\n\t\t\tdata: index\n\n\t\t});\n\t}\n\n});\n\nexports.default = MyBtn;";
    },
    getData_control39: function (elem) {
      var aSpan = elem.querySelectorAll("span");

      var oPage = {

        "currentPage": aSpan[0].textContent,

        "totalPage": aSpan[1].textContent,

        "totalRecords": aSpan[2].textContent

      };

      return oPage;
    },
    doAction_uiControl48: function (data, elem) {},
    getTemplate_uiControl48: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\n\trender: function() {\n\n  \tvar data = this.props.data.customData;\n\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共{data.totalPage}页</span><span>总共{data.totalRecords}条记录</span></div>\n\n  }\n\n});\n\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n\tvalue: true\n});\nvar MyPage = React.createClass({\n\tdisplayName: \"MyPage\",\n\n\n\trender: function render() {\n\n\t\tvar data = this.props.data.customData;\n\n\t\treturn React.createElement(\n\t\t\t\"div\",\n\t\t\t{ className: \"pagenation\" },\n\t\t\tReact.createElement(\n\t\t\t\t\"span\",\n\t\t\t\tnull,\n\t\t\t\t\"第\",\n\t\t\t\tdata.currentPage,\n\t\t\t\t\"页/共\",\n\t\t\t\tdata.totalPage,\n\t\t\t\t\"页\"\n\t\t\t),\n\t\t\tReact.createElement(\n\t\t\t\t\"span\",\n\t\t\t\tnull,\n\t\t\t\t\"总共\",\n\t\t\t\tdata.totalRecords,\n\t\t\t\t\"条记录\"\n\t\t\t)\n\t\t);\n\t}\n\n});\n\nexports.default = MyPage;";
    },
    getData_control40: function (elem) {
      var info = [{

        "text": "首页",

        "index": "0"

      }, {

        "text": "上一页",

        "index": "1"

      }, {

        "text": "下一页",

        "index": "2"

      }, {

        "text": "末页",

        "index": "3"

      }];

      return info;
    },
    doAction_uiControl49: function (data, elem) {
      var index = parseInt(data.dataCustom);

      elem.querySelectorAll("input")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl49: function () {
      var selfTemplate = "const MyBtn = React.createClass({\n\n\trender: function() {\n\n  \tvar data = this.props.data.customData;\n\n    var items = data.map( function(item) {\n\n    \treturn <span data-index={item.index}>{item.text}</span>\n\n    });\n\n    return <div onClick={this.onClick} className=\"pageBtn\">{items}</div>\n\n  },\n\n  onClick: function(e) {\n\n  \tvar target = e.target;\n\n    var index = target.getAttribute(\"data-index\");\n\n    var handler = this.props.customHandler;\n\n    handler({\n\n    \tdata: index\n\n    });\n\n  }\n\n});\n\nexport default MyBtn;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n\tvalue: true\n});\nvar MyBtn = React.createClass({\n\tdisplayName: \"MyBtn\",\n\n\n\trender: function render() {\n\n\t\tvar data = this.props.data.customData;\n\n\t\tvar items = data.map(function (item) {\n\n\t\t\treturn React.createElement(\n\t\t\t\t\"span\",\n\t\t\t\t{ \"data-index\": item.index },\n\t\t\t\titem.text\n\t\t\t);\n\t\t});\n\n\t\treturn React.createElement(\n\t\t\t\"div\",\n\t\t\t{ onClick: this.onClick, className: \"pageBtn\" },\n\t\t\titems\n\t\t);\n\t},\n\n\tonClick: function onClick(e) {\n\n\t\tvar target = e.target;\n\n\t\tvar index = target.getAttribute(\"data-index\");\n\n\t\tvar handler = this.props.customHandler;\n\n\t\thandler({\n\n\t\t\tdata: index\n\n\t\t});\n\t}\n\n});\n\nexports.default = MyBtn;";
    },
    getData_control18: function (elem) {
      if (elem) {
        var ip = elem.querySelectorAll("input");for (var i = 0; i < ip.length; i++) {
          if (ip[i].checked == true) {
            ip[i].setAttribute("checked", true);
          }
        }var ta = elem.cloneNode(true);ta.innerHTML = ta.innerHTML.replace(/href/g, "option").replace(/\sonclick\="[\s\S]*?"/g, '');return ta.innerHTML;
      }
    },
    doAction_uiControl30: function (data, elem) {
      var index = data.dataCustom.index;var ip = elem.querySelectorAll("input");for (var i = 0; i < ip.length; i++) {
        var ind = ip[i].getAttribute("id");if (index === ind) {
          ip[i].click();
        }
      }
    },
    getTemplate_uiControl30: function () {
      var selfTemplate = "const TaskList = React.createClass({\n      render: function () { \n            var data = this.props.data.customData;\n            return <div className=\"table-a\"><table onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table></div>;  \n      },\n  onClick:function(e){\n     var target=e.target;\n    // function findIp(elem){\n    // \tif(elem.tagName == \"INPUT\"){\n    //   \treturn elem;\n    //   } else {\n    //   \treturn findIp(e.target.querySelector(\"input\"));\n    //   }\n    // }\n    var type = target.tagName;\n    \n     var index=target.getAttribute(\"id\");\n    var all = document.querySelectorAll(\".table-a input\");\n    \n    if(type === \"INPUT\"){\n      for(var i=0; i<all.length; i++){\n      \tif(all[i].getAttribute(\"id\") !== index){\n    \t\t\tall[i].checked = false;\n    \t}\n    }\n  }\n    var handler = this.props.customHandler;\n    if (handler) {\n        handler({\n            data:{\n                \"index\": index,\n            }\n        });\n    }\n  }\n \n  });\nexport default TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"table-a\" },\n      React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    // function findIp(elem){\n    // \tif(elem.tagName == \"INPUT\"){\n    //   \treturn elem;\n    //   } else {\n    //   \treturn findIp(e.target.querySelector(\"input\"));\n    //   }\n    // }\n    var type = target.tagName;\n\n    var index = target.getAttribute(\"id\");\n    var all = document.querySelectorAll(\".table-a input\");\n\n    if (type === \"INPUT\") {\n      for (var i = 0; i < all.length; i++) {\n        if (all[i].getAttribute(\"id\") !== index) {\n          all[i].checked = false;\n        }\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"index\": index\n        }\n      });\n    }\n  }\n\n});\nexports.default = TaskList;";
    },
    getData_control42: function (elem) {
      var ip = elem.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        if (ip[i].checked == true) {
          ip[i].setAttribute("checked");
        }
      }

      var ta = elem.cloneNode(true);
      ta.innerHTML = ta.innerHTML.replace(/href/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl25: function (data, elem) {
      var index = data.dataCustom.index;
      var ip = elem.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        var ind = ip[i].getAttribute("id");

        if (index === ind) {
          ip[i].click();
        }
      }
    },
    getTemplate_uiControl25: function () {
      var selfTemplate = "const TaskList = React.createClass({\n      render: function () { \n            var data = this.props.data.customData;\n            return <table className=\"table-show\"  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;  \n      },\n  onClick:function(e){\n     var target=e.target;\n    // function findIp(elem){\n    // \tif(elem.tagName == \"INPUT\"){\n    //   \treturn elem;\n    //   } else {\n    //   \treturn findIp(e.target.querySelector(\"input\"));\n    //   }\n    // }\n     var index=target.getAttribute(\"id\");\n    var all = document.querySelectorAll(\".table-show input\");\n    for(var i=0; i<all.length; i++){\n      if(all[i].getAttribute(\"id\") !== index){\n    \tall[i].checked = false;\n    }\n  }\n    var handler = this.props.customHandler;\n    if (handler) {\n        handler({\n            data:{\n                \"index\": index\n            }\n        });\n    }\n  }\n \n  });\nexport default TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"table-show\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    // function findIp(elem){\n    // \tif(elem.tagName == \"INPUT\"){\n    //   \treturn elem;\n    //   } else {\n    //   \treturn findIp(e.target.querySelector(\"input\"));\n    //   }\n    // }\n    var index = target.getAttribute(\"id\");\n    var all = document.querySelectorAll(\".table-show input\");\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].getAttribute(\"id\") !== index) {\n        all[i].checked = false;\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"index\": index\n        }\n      });\n    }\n  }\n\n});\nexports.default = TaskList;";
    },
    getData_control43: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var oPage = {
        "currentPage": aSpan[0].textContent,
        "totalPage": aSpan[1].textContent,
        "totalRecords": aSpan[2].textContent
      };
      return oPage;
    },
    doAction_uiControl58: function (data, elem) {},
    getTemplate_uiControl58: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共{data.totalPage}页</span><span>总共{data.totalRecords}条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        data.totalPage,\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        data.totalRecords,\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control44: function (elem) {
      var info = [{
        "text": "首页",
        "index": "0"
      }, {
        "text": "上一页",
        "index": "1"
      }, {
        "text": "下一页",
        "index": "2"
      }, {
        "text": "末页",
        "index": "3"
      }];
      return info;
    },
    doAction_uiControl60: function (data, elem) {
      var index = parseInt(data.dataCustom);
      elem.querySelectorAll("div")[1].querySelectorAll("input")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl60: function () {
      var selfTemplate = "const MyBtn = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    var items = data.map( function(item) {\n    \treturn <span data-index={item.index}>{item.text}</span>\n    });\n    return <div onClick={this.onClick} className=\"pageBtn\">{items}</div>\n  },\n  onClick: function(e) {\n  \tvar target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n    \tdata: index\n    });\n  }\n});\nexport default MyBtn;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBtn = React.createClass({\n  displayName: \"MyBtn\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        { \"data-index\": item.index },\n        item.text\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { onClick: this.onClick, className: \"pageBtn\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\nexports.default = MyBtn;";
    },
    getData_control45: function (elem) {
      var aSel = [];
      var aLi = elem.querySelectorAll("li");
      var aSpan = elem.querySelectorAll(".x-tab-strip-text");

      if (aSpan.length > 1) {
        for (var i = 0; i < aSpan.length; i++) {
          aSel.push({
            "lab": aSpan[i].textContent,
            "ali": aLi[i].getAttribute("class")
          });
        }
      }

      return aSel;
    },
    doAction_uiControl57: function (data, elem) {
      var index = data.dataCustom;
      var ylEvent = elem.getElementsByTagName("li");

      for (var i = 0; i < ylEvent.length; i++) {
        if (i == index) {
          if (document.createEvent) {
            var evObj = document.createEvent('MouseEvents');
            evObj.initEvent('mousedown', true, false);
            ylEvent[i].dispatchEvent(evObj);
          }
        }
      }
    },
    getTemplate_uiControl57: function () {
      var selfTemplate = "const MySel = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n         var xx = document.getElementsByClassName(\"xuan1\")[0];\n       var yy = document.getElementsByClassName(\"xuan2\")[0];\n    var zz = document.getElementsByClassName(\"xuan3\")[0];\n    var items = data.map( function(item, index) {\n      if(!(item.ali.trim() === \"x-tab-strip-active\")){\n        if(index === 0) {\n        xx.style.display = \"none\";\n        }else if(index === 1){\n        yy.style.display = \"none\";\n        } else {\n        zz.style.display = \"none\";\n        }\n    return <option  value={index}>{item.lab}</option>\n       } else {\n    return <option selected value={index}>{item.lab}</option> \n       }\n\n    });\n    return <select className = \"mySel\" onChange={this.onChange}>{items}</select>\n\n  },\n  onChange: function(e) {\n    var target = e.target;\n    var index = target.value;\n     var xx = document.getElementsByClassName(\"xuan1\")[0];\n       var yy = document.getElementsByClassName(\"xuan2\")[0];\n    var zz = document.getElementsByClassName(\"xuan3\")[0];\n    if(index === \"0\"){\n      xx.style.display = \"block\";\n    yy.style.display = \"none\";\n     zz.style.display = \"none\";\n      }\n      else if(index === \"1\"){\n        xx.style.display = \"none\";\n        yy.style.display = \"block\";\n     \t zz.style.display = \"none\";\n      }\n      else{\n       xx.style.display = \"none\";\n     \t yy.style.display = \"none\";\n        zz.style.display = \"block\";\n      }\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    })\n  }\n});\n\nexport default MySel;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MySel = React.createClass({\n  displayName: \"MySel\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var xx = document.getElementsByClassName(\"xuan1\")[0];\n    var yy = document.getElementsByClassName(\"xuan2\")[0];\n    var zz = document.getElementsByClassName(\"xuan3\")[0];\n    var items = data.map(function (item, index) {\n      if (!(item.ali.trim() === \"x-tab-strip-active\")) {\n        if (index === 0) {\n          xx.style.display = \"none\";\n        } else if (index === 1) {\n          yy.style.display = \"none\";\n        } else {\n          zz.style.display = \"none\";\n        }\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.lab\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { selected: true, value: index },\n          item.lab\n        );\n      }\n    });\n    return React.createElement(\n      \"select\",\n      { className: \"mySel\", onChange: this.onChange },\n      items\n    );\n  },\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var xx = document.getElementsByClassName(\"xuan1\")[0];\n    var yy = document.getElementsByClassName(\"xuan2\")[0];\n    var zz = document.getElementsByClassName(\"xuan3\")[0];\n    if (index === \"0\") {\n      xx.style.display = \"block\";\n      yy.style.display = \"none\";\n      zz.style.display = \"none\";\n    } else if (index === \"1\") {\n      xx.style.display = \"none\";\n      yy.style.display = \"block\";\n      zz.style.display = \"none\";\n    } else {\n      xx.style.display = \"none\";\n      yy.style.display = \"none\";\n      zz.style.display = \"block\";\n    }\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MySel;";
    },
    getData_control52: function (elem) {},
    doAction_uiControl17: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl17: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);