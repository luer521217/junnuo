(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control3: function (elem) {
      var ip = elem.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        if (ip[i].checked == true) {
          ip[i].setAttribute("checked");
        }
      }

      var ta = elem.cloneNode(true);
      ta.innerHTML = ta.innerHTML.replace(/href/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl10: function (data, elem) {
      var index = data.dataCustom.index;
      var ip = elem.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        var ind = ip[i].getAttribute("id");

        if (index === ind) {
          ip[i].click();
        }
      }
    },
    getTemplate_uiControl10: function () {
      var selfTemplate = "const TaskList = React.createClass({\n      render: function () { \n            var data = this.props.data.customData;\n            return <table className=\"table-show\"  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;  \n      },\n  onClick:function(e){\n     var target=e.target;\n    // function findIp(elem){\n    // \tif(elem.tagName == \"INPUT\"){\n    //   \treturn elem;\n    //   } else {\n    //   \treturn findIp(e.target.querySelector(\"input\"));\n    //   }\n    // }\n     var index=target.getAttribute(\"id\");\n    var all = document.querySelectorAll(\".table-show input\");\n    for(var i=0; i<all.length; i++){\n      if(all[i].getAttribute(\"id\") !== index){\n    \tall[i].checked = false;\n    }\n  }\n    var handler = this.props.customHandler;\n    if (handler) {\n        handler({\n            data:{\n                \"index\": index\n            }\n        });\n    }\n  }\n \n  });\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"table-show\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    // function findIp(elem){\n    // \tif(elem.tagName == \"INPUT\"){\n    //   \treturn elem;\n    //   } else {\n    //   \treturn findIp(e.target.querySelector(\"input\"));\n    //   }\n    // }\n    var index = target.getAttribute(\"id\");\n    var all = document.querySelectorAll(\".table-show input\");\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].getAttribute(\"id\") !== index) {\n        all[i].checked = false;\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"index\": index\n        }\n      });\n    }\n  }\n\n});\nexports.default = TaskList;";
    },
    getData_control6: function (elem) {
      if (elem.files.length) {
        return elem.files[0].name;
      }
    },
    doAction_uiControl15: function (data, elem) {},
    getTemplate_uiControl15: function () {
      var selfTemplate = 'module.exports = React.createClass({\n\trender: function(){\n  \treturn <div>{this.props.data.customData}</div>\n  }\n});';
      return '"use strict";\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  render: function render() {\n    return React.createElement(\n      "div",\n      null,\n      this.props.data.customData\n    );\n  }\n});';
    },
    getData_control15: function (elem) {
      var map = Array.prototype.map;
      var content = map.call($(elem).find('tbody').find('tr'), function (tr) {
        return map.call($(tr).find('td'), function (td) {
          return td.textContent;
        });
      });
      console.log(elem);
      return {
        content: content
      };
    },
    doAction_uiControl33: function (data, elem) {
      var index = data.dataCustom.index;
      var input = elem.querySelectorAll("input");

      if (data.dataCustom.eventType === 'click') {
        if (input[index].checked === true) {
          input[index].checked = false;
        } else {
          input[index].checked = true;
        }
      }
    },
    getTemplate_uiControl33: function () {
      var selfTemplate = "// 没用到\nvar Table = require(\"ysp-interior-components\").Table;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.data.customData.content;\n    // 提取表格头\n    var thead = data[0].map(function(item, index){\n      return <th>{item}</th>\n    })\nvar tbody = [];\n\t\tfor(var i=1; i<data.length; i++){\n    var td = data[i].map(function(item, index){\n      \treturn <td>{item}</td>\n      })\n    // i从1开始\n    var tr = <tr onClick={this.handleClick} data-index={i-1}>{td}</tr>;\n    tbody.push(tr);\n    }\n    \n    return (\n      <table>\n        <thead>\n          <tr>{thead}</tr>\n        </thead>\n        <tbody>\n          {tbody}\n        </tbody>\n      </table>\n    )\n  },\n  \n  handleClick: function(e) {\n    var target = findTr(e.target);\n    function findTr(elem) {\n    \tif(elem.tagName === \"TR\") {\n      \treturn elem;\n      } else {\n      \treturn findTr(elem.parentNode);\n      }\n    }\n    // 重复点击问题\n    var input = target.querySelector(\"input\");\n\t\tif(input.checked === true){\n    \tinput.checked = false;\n    } else {\n    \tinput.checked = true;\n    }\n    \n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n      \tdata: {\n          eventType: 'click',  \n          index: index\n        }\n      });\n    }\n  }\n});\n";
      return "\"use strict\";\n\n// 没用到\nvar Table = require(\"ysp-interior-components\").Table;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData.content;\n    // 提取表格头\n    var thead = data[0].map(function (item, index) {\n      return React.createElement(\n        \"th\",\n        null,\n        item\n      );\n    });\n    var tbody = [];\n    for (var i = 1; i < data.length; i++) {\n      var td = data[i].map(function (item, index) {\n        return React.createElement(\n          \"td\",\n          null,\n          item\n        );\n      });\n      // i从1开始\n      var tr = React.createElement(\n        \"tr\",\n        { onClick: this.handleClick, \"data-index\": i - 1 },\n        td\n      );\n      tbody.push(tr);\n    }\n\n    return React.createElement(\n      \"table\",\n      null,\n      React.createElement(\n        \"thead\",\n        null,\n        React.createElement(\n          \"tr\",\n          null,\n          thead\n        )\n      ),\n      React.createElement(\n        \"tbody\",\n        null,\n        tbody\n      )\n    );\n  },\n\n  handleClick: function handleClick(e) {\n    var target = findTr(e.target);\n    function findTr(elem) {\n      if (elem.tagName === \"TR\") {\n        return elem;\n      } else {\n        return findTr(elem.parentNode);\n      }\n    }\n    // 重复点击问题\n    var input = target.querySelector(\"input\");\n    if (input.checked === true) {\n      input.checked = false;\n    } else {\n      input.checked = true;\n    }\n\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          eventType: 'click',\n          index: index\n        }\n      });\n    }\n  }\n});";
    },
    getData_control16: function (elem) {},
    doAction_uiControl21: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close(); //关闭当前页面
    },
    getTemplate_uiControl21: function () {
      var selfTemplate = 'const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name="left-nav" onClick={this.onClick} className="backBtn">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;';
      return '"use strict";\n\nObject.defineProperty(exports, "__esModule", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: "MyBack",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: "left-nav", onClick: this.onClick, className: "backBtn" },\n      "返回"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;';
    }
  });
})(window, ysp);