(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control6: function (elem) {
      return elem.innerHTML.replace(/\&lt;p\&gt;/g, "").replace(/\&lt;\/p\&gt;/g, "");
    },
    doAction_uiControl4: function (data, elem) {},
    getTemplate_uiControl4: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return  <div className = \"content\" dangerouslySetInnerHTML={{__html: data}}></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"content\", dangerouslySetInnerHTML: { __html: data } });\n  }\n});\nexports.default = MyPage;";
    },
    getData_control131: function (elem) {},
    doAction_uiControl218: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl218", "context1");
      elem.click();
    },
    getTemplate_uiControl218: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">\u8FD4\u56DE</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);