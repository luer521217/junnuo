(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control4: function (elem) {
      var aList = [];
      var aTd = elem.querySelectorAll("td");

      for (var i = 0; i < aTd.length; i++) {
        aList.push({
          "title": aTd[i].textContent,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl10: function (data, elem) {
      console.log("lll");
      var index = data.dataCustom;
      elem.querySelectorAll("td")[index].querySelector("a").dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl10: function () {
      var selfTemplate = "const MyTable = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <td data-index={item.index}>{item.title}</td>\n    });\n    return <table className=\"yl_clist\"><tr onClick={this.onClick}>{items}</tr></table>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    if (index == \"1\"){\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });  \n    }\n  }\n});\n\nexport default MyTable;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar MyTable = React.createClass({\n    displayName: \"MyTable\",\n\n    render: function render() {\n        var data = this.props.data.customData;\n        var items = data.map(function (item) {\n            return React.createElement(\n                \"td\",\n                { \"data-index\": item.index },\n                item.title\n            );\n        });\n        return React.createElement(\n            \"table\",\n            { className: \"yl_clist\" },\n            React.createElement(\n                \"tr\",\n                { onClick: this.onClick },\n                items\n            )\n        );\n    },\n    onClick: function onClick(e) {\n        var target = e.target;\n        var index = target.getAttribute(\"data-index\");\n        if (index == \"1\") {\n            var handler = this.props.customHandler;\n            handler({\n                data: index\n            });\n        }\n    }\n});\n\nexports.default = MyTable;";
    },
    getData_control5: function (elem) {
      var aSel = [];
      var aLa = elem.getElementsByTagName("label");

      if (aLa.length > 1) {
        for (var i = 0; i < aLa.length; i++) {
          aSel.push({
            "lab": aLa[i].textContent
          });
        }
      }

      return aSel;
    },
    doAction_uiControl11: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.getElementsByTagName("input")[index];

      if (event.checked) {
        event.checked = false;
      } else {
        event.checked = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "const MySel = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item, index) {\n      return <option value={index}>{item.lab}</option>\n    });\n    return <select onChange={this.onChange}>{items}</select>\n\n  },\n  onChange: function(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MySel;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MySel = React.createClass({\n  displayName: \"MySel\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      return React.createElement(\n        \"option\",\n        { value: index },\n        item.lab\n      );\n    });\n    return React.createElement(\n      \"select\",\n      { onChange: this.onChange },\n      items\n    );\n  },\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MySel;";
    },
    getData_control6: function (elem) {},
    doAction_uiControl12: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);