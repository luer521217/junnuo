(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control16: function (elem) {},
    doAction_uiControl15: function (data, elem) {
      elem.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl15: function () {
      var selfTemplate = "const MyButton = React.createClass({\n  render:function(){\n    var data=this.props.data.customData;\n    return <button className=\"yl_button\" onClick={this.onClick}>查询</button>\n  },\n  onClick:function(e){\n    var handler=this.props.customHandler;\n    handler({\n      \n    });\n  }\n  \n});\nexport default MyButton;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyButton = React.createClass({\n  displayName: \"MyButton\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"yl_button\", onClick: this.onClick },\n      \"查询\"\n    );\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n\n});\nexports.default = MyButton;";
    },
    getData_control17: function (elem) {},
    doAction_uiControl17: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl17: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control18: function (elem) {
      var xx = elem.querySelectorAll("td");
      var yy = xx[xx.length - 1];
      var clone = yy.cloneNode(true);

      var setA = function () {
        var i = 0;

        for (var j = 0; j < clone.childNodes.length; j++) {
          if (clone.childNodes[j].tagName === "A") {
            clone.childNodes[j].setAttribute("data-index", i);
            i++;
          } else if (clone.childNodes[j].tagName === "SPAN") {
            if (clone.childNodes[0].tagName === "SPAN") {
              clone.childNodes[j + 2].setAttribute("class", "next");
              clone.childNodes[j + 2].innerHTML = "下一页";
            }

            try {
              clone.childNodes[j - 2].setAttribute("class", "prev");
              clone.childNodes[j - 2].innerHTML = "上一页";
              clone.childNodes[j + 2].setAttribute("class", "next");
              clone.childNodes[j + 2].innerHTML = "下一页";
            } catch (error) {}
          }
        }

        return clone;
      }();

      var tar = setA.outerHTML.replace(/href=".*?"/g, "").replace(/&nbsp;/g, "");
      return tar;
    },
    doAction_uiControl20: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelectorAll("a")[index];
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl20: function () {
      var selfTemplate = "module.exports = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n     return <div className=\"page\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>;\n  },\n  \n  onClick: function(e){\n  \tvar target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: index\n      })\n    }\n  }\n  \n})";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"page\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n\n});";
    }
  });
})(window, ysp);