(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control129: function (elem) {},
    doAction_uiControl216: function (data, elem) {
      var target = data.dataCustom;

      if (target === 'teacher') {
        elem.querySelector("input[value='教师']").checked = true;
      } else {
        elem.querySelector("input[value='学生']").checked = true;
      }
    },
    getTemplate_uiControl216: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  getInitialState: function() {\n  \treturn {checked: true}\n  },\n  render: function(){\n    return (\n        <div onClick={this.onClick} className='identity-select'>\n        <input type=\"radio\" name=\"Identity\" value=\"teacher\" />\n        <span>\u6559\u5E08</span>\n<input type=\"radio\" name=\"Identity\" value=\"student\" checked={this.state.checked} />\n        <span>\u5B66\u751F</span>\n      </div>\n    )\n  },\n  onClick: function(e){\n  \tvar target = e.target;\n\t\tvar value = target.value;\n    // var all = target.parentNode.children;\n    // for(var i=0; i<all.length; i++) {\n    // \tall[i].checked = false;\n    // }\n    if(target.tagName === \"INPUT\"){\n        this.setState({checked: !this.state.checked});\n    }\n    var\xA0handler\xA0=\xA0this.props.customHandler;\n    if(handler){\n\xA0\xA0\xA0\xA0 handler({\n\xA0\xA0\xA0\xA0\xA0\xA0 data:\xA0value\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  getInitialState: function getInitialState() {\n    return { checked: true };\n  },\n  render: function render() {\n    return React.createElement(\n      'div',\n      { onClick: this.onClick, className: 'identity-select' },\n      React.createElement('input', { type: 'radio', name: 'Identity', value: 'teacher' }),\n      React.createElement(\n        'span',\n        null,\n        '\\u6559\\u5E08'\n      ),\n      React.createElement('input', { type: 'radio', name: 'Identity', value: 'student', checked: this.state.checked }),\n      React.createElement(\n        'span',\n        null,\n        '\\u5B66\\u751F'\n      )\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var value = target.value;\n    // var all = target.parentNode.children;\n    // for(var i=0; i<all.length; i++) {\n    // \tall[i].checked = false;\n    // }\n    if (target.tagName === \"INPUT\") {\n      this.setState({ checked: !this.state.checked });\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: value\n      });\n    }\n  }\n});";
    },
    getData_control133: function (elem) {
      var $img = elem.querySelector('img');
      var canvas = document.createElement('CANVAS');
      var ctx = canvas.getContext('2d');
      var dataUrl;
      canvas.height = $img.height;
      canvas.width = $img.width;
      ctx.drawImage($img, 0, 0);
      dataUrl = canvas.toDataURL('image/png');
      return dataUrl;
    },
    doAction_uiControl222: function (data, elem) {
      elem.querySelector("a").click();
    },
    getTemplate_uiControl222: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <div className=\"imgWrap\">\n    \t<img src={data} onClick={this.onClick} />\n        </div>\n    )\n  },\n  onClick: function(e){\n  \tvar handler = this.props.customHandler;\n    handler({})\n  }\n\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"imgWrap\" },\n      React.createElement(\"img\", { src: data, onClick: this.onClick })\n    );\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n\n});";
    }
  });
})(window, ysp);