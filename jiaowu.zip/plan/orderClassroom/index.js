(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control31: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": getSelect.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl41: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl41: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.sel){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n      return <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled = \"disabled\">{items}</select>\n    }\n    else{\n      return <select onChange={this.onChange}>{items}</select>\n    }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    console.log(index)\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.sel) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    console.log(index);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control32: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[1];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": getSelect.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl42: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[1];
      var event = getSelect.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl42: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.sel){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n      return <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled = \"disabled\">{items}</select>\n    }\n    else{\n      return <select onChange={this.onChange}>{items}</select>\n    }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    console.log(index)\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.sel) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    console.log(index);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control34: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": getSelect.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl44: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl44: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.sel){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n      return <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled = \"disabled\">{items}</select>\n    }\n    else{\n      return <select onChange={this.onChange}>{items}</select>\n    }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    console.log(index)\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.sel) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    console.log(index);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control35: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": getSelect.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl45: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl45: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.sel){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n      return <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled = \"disabled\">{items}</select>\n    }\n    else{\n      return <select onChange={this.onChange}>{items}</select>\n    }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    console.log(index)\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.sel) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    console.log(index);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control36: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": getSelect.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl46: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl46: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.sel){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n      return <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled = \"disabled\">{items}</select>\n    }\n    else{\n      return <select onChange={this.onChange}>{items}</select>\n    }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    console.log(index)\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.sel) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    console.log(index);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    }
  });
})(window, ysp);