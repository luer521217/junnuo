(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control2: function (elem) {
      var aList = [];
      var aTr = elem.querySelectorAll("tr");

      if (aTr.length > 1) {
        for (var i = 1; i < aTr.length; i++) {
          var aTd = aTr[i].querySelectorAll("td");
          aList.push({
            "title": aTd[0].textContent,
            "date": aTd[2].textContent.substr(0, 10),
            "index": i
          });
        }
      }

      return aList;
    },
    doAction_uiControl3: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl3", "context0");
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index - 1].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl3: function () {
      var selfTemplate = "const MyList = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return (\n        <section data-index={item.index}>\n          <span>{item.title}</span>\n          <span>{item.date}</span>\n        </section>\n      )\n    });\n    return <div onClick={this.onClick} className=\"list-a\">{items}</div>\n  },\n  onClick: function(e) {\n    var target = findLi(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n    function findLi(elem) {\n      if (elem.tagName == \"SECTION\") {\n        return elem;\n      } else {\n        return findLi(elem.parentNode);\n      }\n    }\n  }\n});\n\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"section\",\n        { \"data-index\": item.index },\n        React.createElement(\n          \"span\",\n          null,\n          item.title\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          item.date\n        )\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { onClick: this.onClick, className: \"list-a\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = findLi(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n    function findLi(elem) {\n      if (elem.tagName == \"SECTION\") {\n        return elem;\n      } else {\n        return findLi(elem.parentNode);\n      }\n    }\n  }\n});\n\nexports.default = MyList;";
    },
    getData_control3: function (elem) {
      var aList = [];
      var aA = elem.querySelectorAll("a");

      for (var i = 1; i < aA.length; i++) {
        aList.push({
          "title": aA[i].textContent,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl5: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl5", "context0");
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl5: function () {
      var selfTemplate = "const MyMenu = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <li data-index={item.index}>{item.title}</li>\n    });\n    return <ul onClick={this.onClick} className=\"list-b\">{items}</ul>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyMenu;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyMenu = React.createClass({\n  displayName: \"MyMenu\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"li\",\n        { \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { onClick: this.onClick, className: \"list-b\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyMenu;";
    },
    getData_control4: function (elem) {
      var aList = [];
      var aA = elem.querySelectorAll("a");

      for (var i = 1; i < aA.length; i++) {
        aList.push({
          "title": aA[i].textContent,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl7: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl7", "context0");
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "const MyMenu = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <li data-index={item.index}>{item.title}</li>\n    });\n    return <ul onClick={this.onClick} className=\"list-b\">{items}</ul>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyMenu;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyMenu = React.createClass({\n  displayName: \"MyMenu\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"li\",\n        { \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { onClick: this.onClick, className: \"list-b\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyMenu;";
    },
    getData_control5: function (elem) {
      var aList = [];
      var aA = elem.querySelectorAll("a");

      for (var i = 1; i < aA.length; i++) {
        aList.push({
          "title": aA[i].textContent,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl9: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl9", "context0");
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl9: function () {
      var selfTemplate = "const MyMenu = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <li data-index={item.index}>{item.title}</li>\n    });\n    return <ul onClick={this.onClick} className=\"list-b\">{items}</ul>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyMenu;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyMenu = React.createClass({\n  displayName: \"MyMenu\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"li\",\n        { \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { onClick: this.onClick, className: \"list-b\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyMenu;";
    },
    getData_control6: function (elem) {
      var aList = [];
      var aA = elem.querySelectorAll("a");

      for (var i = 1; i < aA.length; i++) {
        aList.push({
          "title": aA[i].textContent,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl11: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl11", "context0");
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "const MyMenu = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <li data-index={item.index}>{item.title}</li>\n    });\n    return <ul onClick={this.onClick} className=\"list-b\">{items}</ul>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyMenu;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyMenu = React.createClass({\n  displayName: \"MyMenu\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"li\",\n        { \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { onClick: this.onClick, className: \"list-b\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyMenu;";
    }
  });
})(window, ysp);