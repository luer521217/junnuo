(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control5: function (elem) {
      var aTr = elem.getElementsByTagName("tr");
      var aA = elem.getElementsByTagName("font");
      var list = [];

      try {
        if (aA.length == 0) {
          list.push({
            "tips": "当前记录为空"
          });
        } else {
          for (var i = 1; i < aA.length + 1; i++) {
            var aTd = aTr[i].getElementsByTagName("td");
            list.push({
              "checked": aTr[i].getElementsByTagName("input")[0].checked,
              "aa": aTd[0].innerText,
              "bb": aTd[1].innerText,
              "cc": aTd[2].innerText,
              "dd": aTd[3].innerText
            });
          }
        }
      } catch (e) {}

      return list;
    },
    doAction_uiControl11: function (data, elem) {
      var type = data.dataCustom.type;
      var index = data.dataCustom.index;
      var aTd = elem.getElementsByTagName("tr")[index * 1 + 1].getElementsByTagName("td");
      var aIp = elem.getElementsByTagName("input")[index];
      ysp.helper.chooseReturnvalue = aTd[1].textContent + "|" + aTd[0].textContent;
      aIp.click();
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick: function(e) {\n    var target = findLi(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n    function findLi(elem) {\n      if ( elem.nodeName === \"LI\" ) {\n        return elem;\n      } else {\n        return findLi(elem.parentNode);\n      }\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData;    //getDate中返回的数据\n    var items = data.map( function(item, index) {\n             console.log(item.checked);\n      if( item.tips ){\n         return (\n        <li className=\"lv_info\">{item.tips}</li>\n      );\n      }else{\n         return (\n        <li className=\"lv_grxx_li\" data-index={index}>\n             <div className=\"lv_grxx_ip\"> <input type=\"checkbox\" checked={item.checked}/> </div>\n             <div>\n                  <font><b>教师职工号：</b>{item.aa}</font>\n             \t\t \t<span><b>姓名：</b>{item.bb}</span>\n               \t\t<span><b>部门：</b>{item.cc}</span>\n               <span><b>教研室：</b>{item.dd}</span>\n             </div>\n        </li>\n      );\n      }\n     \n    });\n    return <ul className=\"lv_grxx_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findLi(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n    function findLi(elem) {\n      if (elem.nodeName === \"LI\") {\n        return elem;\n      } else {\n        return findLi(elem.parentNode);\n      }\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData; //getDate中返回的数据\n    var items = data.map(function (item, index) {\n      console.log(item.checked);\n      if (item.tips) {\n        return React.createElement(\n          \"li\",\n          { className: \"lv_info\" },\n          item.tips\n        );\n      } else {\n        return React.createElement(\n          \"li\",\n          { className: \"lv_grxx_li\", \"data-index\": index },\n          React.createElement(\n            \"div\",\n            { className: \"lv_grxx_ip\" },\n            \" \",\n            React.createElement(\"input\", { type: \"checkbox\", checked: item.checked }),\n            \" \"\n          ),\n          React.createElement(\n            \"div\",\n            null,\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"教师职工号：\"\n              ),\n              item.aa\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"姓名：\"\n              ),\n              item.bb\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"部门：\"\n              ),\n              item.cc\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"教研室：\"\n              ),\n              item.dd\n            )\n          )\n        );\n      }\n    });\n    return React.createElement(\n      \"ul\",\n      { className: \"lv_grxx_ul\", onClick: this.onClick },\n      items\n    );\n  }\n});\nexports.default = TaskList;";
    },
    getData_control6: function (elem) {
      var xx = elem.querySelectorAll("td");
      var yy = xx[xx.length - 1];
      var clone = yy.childNodes[0].cloneNode(true);

      var setA = function () {
        var i = 0;

        for (var j = 0; j < clone.childNodes.length; j++) {
          if (clone.childNodes[j].tagName === "A") {
            clone.childNodes[j].setAttribute("data-index", i);
            i++;
          } else if (clone.childNodes[j].tagName === "SPAN") {
            if (clone.childNodes[0].tagName === "SPAN") {
              clone.childNodes[j + 2].setAttribute("class", "next");
              clone.childNodes[j + 2].innerHTML = "下一页";
            }

            try {
              clone.childNodes[j - 2].setAttribute("class", "prev");
              clone.childNodes[j - 2].innerHTML = "上一页";
              clone.childNodes[j + 2].setAttribute("class", "next");
              clone.childNodes[j + 2].innerHTML = "下一页";
            } catch (error) {}
          }
        }

        return clone;
      }();

      var tar = setA.outerHTML.replace(/href=".*?"/g, "").replace(/&nbsp;/g, "");
      return tar;
    },
    doAction_uiControl14: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelectorAll("a")[index];
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl14: function () {
      var selfTemplate = "module.exports = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n     return <div className=\"page\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>;\n  },\n  \n  onClick: function(e){\n  \tvar target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: index\n      })\n    }\n  }\n  \n})\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"page\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n\n});";
    },
    getData_control9: function (elem) {
      return elem.value;
    },
    doAction_uiControl12: function (data, elem) {
      ysp.helper.chooseReturnStatus = true;
      elem.click();
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"btn btn-success btn-block waves-effecttt flow-sure\" onClick={this.onClick} >{data}</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"btn btn-success btn-block waves-effecttt flow-sure\", onClick: this.onClick },\n      data\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    }
  });
})(window, ysp);