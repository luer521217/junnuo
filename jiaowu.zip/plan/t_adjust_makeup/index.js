(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control119: function (elem) {},
    doAction_uiControl54: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl54", "context0");
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl54: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control120: function (elem) {
      if (ysp.helper.chooseReturnvalue&&ysp.helper.chooseReturnStatus==true) {
        elem.value = ysp.helper.chooseReturnvalue;
        ysp.helper.chooseReturnStatus=false;
      }

      return elem.value;
    },
    doAction_uiControl44: function (data, elem) {},
    getTemplate_uiControl44: function () {
      var selfTemplate = "module.exports = React.createClass({\n\n\n  render: function(){\n\n    var data = this.props.data.customData;\n    return (\n\n      <input className=\"lv_shortIp\" type=\"text\" value={data}/> \n\n    );\n\n  }\n\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    return React.createElement(\"input\", { className: \"lv_shortIp\", type: \"text\", value: data });\n  }\n\n});";
    }
  });
})(window, ysp);
