(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control39: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];
      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].value,
          "disabled": getSelect.getAttribute("disabled"),
          "selected": getOption[i].getAttribute("selected")
        });
      }
      return list;
    },
    doAction_uiControl28: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];
      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl28: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n    \t      if(item.selected){\n    \t\treturn <option value={index} selected=\"selected\">{item.index}</option>\n      } else {\n      \treturn <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].disabled){\n    \treturn <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n    } else {\n    \treturn <select onChange={this.onChange}>{items}</select>\n    }\n    \n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.selected) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].disabled) {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control40: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];
      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "disabled": getSelect.getAttribute("disabled"),
          "selected": getOption[i].getAttribute("selected")
        });
      }
      return list;
    },
    doAction_uiControl69: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];
      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl69: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.selected){\n    \t\treturn <option value={index} selected=\"selected\">{item.index}</option>\n      } else {\n      \treturn <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].disabled){\n    \treturn <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n    } else {\n    \treturn <select onChange={this.onChange}>{items}</select>\n    }\n    \n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.selected) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].disabled) {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },

    getData_control42: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];
      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].value,
          "disabled": getSelect.getAttribute("disabled"),
          "selected": getOption[i].getAttribute("selected")
        });
      }
      return list;
    },
    doAction_uiControl83: function (data, elem) {
      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];
      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl83: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n    \tif(item.selected){\n    \t\treturn <option value={index} selected=\"selected\">{item.index}</option>\n      } else {\n      \treturn <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].disabled){\n    \treturn <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n    } else {\n    \treturn <select onChange={this.onChange}>{items}</select>\n    }\n    \n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.selected) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].disabled) {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control83: function (elem) {
      var getSelect = elem.getElementsByTagName("select")[0];
      var getOption = getSelect.getElementsByTagName("option");
      var list = [];
      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].value,
          "disabled": getSelect.getAttribute("disabled"),
          "selected": getOption[i].getAttribute("selected")
        });
      }
      return list;
    },
    doAction_uiControl89: function (data, elem) {

      var index = data.dataCustom;
      var getSelect = elem.getElementsByTagName("select")[0];
      var event = getSelect.getElementsByTagName("option")[index];
      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl89: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n    \tif(item.selected){\n    \t\treturn <option value={index} selected=\"selected\">{item.index}</option>\n      } else {\n      \treturn <option value={index}>{item.index}</option>\n      }\n    })\n    if(data[0].disabled){\n    \treturn <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n    } else {\n    \treturn <select onChange={this.onChange}>{items}</select>\n    }\n    \n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.selected) {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].disabled) {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },

    getData_control113: function (elem) {
      if (ysp.helper.chooseReturnvalue&&ysp.helper.chooseReturnStatus==true) {
        elem.value = ysp.helper.chooseReturnvalue;
        ysp.helper.chooseReturnStatus=false;
      }

      return elem.value;
    },
    doAction_uiControl45: function (data, elem) {},
    getTemplate_uiControl45: function () {
      var selfTemplate = "module.exports = React.createClass({\n\n\n  render: function(){\n\n    var data = this.props.data.customData;\n    return (\n\n      <input className=\"lv_shortIp\" type=\"text\" value={data}/> \n\n    );\n\n  }\n\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    return React.createElement(\"input\", { className: \"lv_shortIp\", type: \"text\", value: data });\n  }\n\n});";
    }
  });
})(window, ysp);
