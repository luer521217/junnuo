(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control15: function (elem) {
      var aSel = [];
      var aOp = elem.getElementsByTagName("option");
      if (aOp.length > 1) {
        for (var i = 0; i < aOp.length; i++) {
          aSel.push({
            "opt": aOp[i].value,
            "index": i
          });
        }
      }
      return aSel;
    },
    doAction_uiControl21: function (data, elem) {},
    getTemplate_uiControl21: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    var items = data.map( function(item) {\n    \treturn <span data-index={item.index}>{item.opt}</span>\n    });\n    return <div className=\"pageSel\">{items}</div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        { \"data-index\": item.index },\n        item.opt\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { className: \"pageSel\" },\n      items\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control16: function (elem) {
      
    },
    doAction_uiControl23: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close(); 
    },
    getTemplate_uiControl23: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);