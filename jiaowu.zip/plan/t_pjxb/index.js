(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control154: function (elem) {},
    doAction_uiControl267: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl267: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">\u8FD4\u56DE</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control160: function (elem) {
      for (var i = 0; i < elem.querySelectorAll("input").length; i++) {
        elem.querySelectorAll("input")[i].setAttribute("data-input", i);
      }

      for (var j = 0; j < elem.querySelectorAll("select").length; j++) {
        elem.querySelectorAll("select")[j].setAttribute("data-select", j);
      }

      for (var k = 0; k < elem.querySelectorAll("a").length; k++) {
        elem.querySelectorAll("a")[k].setAttribute("data-a", k);
      }

      return elem.outerHTML;
    },
    doAction_uiControl278: function (data, elem) {
      var type = data.dataCustom.type;
      var index = data.dataCustom.index;
      var value = data.dataCustom.value;

      if (type === "INPUT") {
        elem.querySelectorAll("input")[index].value = value;
      } else if (type === "SELECT") {
        elem.querySelectorAll("select")[index].value = value;
      } else if (type === "A") {
        elem.querySelectorAll("a")[index].click();
      }
    },
    getTemplate_uiControl278: function () {
      var selfTemplate = "\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <div onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"table-a\"></div>\n    )\n  },\n  onClick:function(e){\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if(tag === \"INPUT\"){\n      idx = target.getAttribute(\"data-input\");\n      val = target.value;\n    } else if (tag === \"SELECT\"){\n    \tidx = target.getAttribute(\"data-select\");\n      val = target.value;\n    } else if (tag === \"a\"){\n    \tidx = target.getAttribute(\"data-a\");\n      val = \"\";\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n      \t\ttype: tag,\n          index: idx,\n          value: val\n      \t}\n      })\n    }\n  }\n});\n";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data }, className: \"table-a\" });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if (tag === \"INPUT\") {\n      idx = target.getAttribute(\"data-input\");\n      val = target.value;\n    } else if (tag === \"SELECT\") {\n      idx = target.getAttribute(\"data-select\");\n      val = target.value;\n    } else if (tag === \"a\") {\n      idx = target.getAttribute(\"data-a\");\n      val = \"\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          type: tag,\n          index: idx,\n          value: val\n        }\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);