(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control11: function (elem) {
      var dom = elem.cloneNode(true);
      var aA = dom.querySelectorAll("a");

      for (var i = 0; i < aA.length; i++) {
        var td = aA[i].parentNode;
        td.textContent = aA[i].textContent;
        td.setAttribute("data-index", i);
      }

      var res = dom.outerHTML;
      return res;
    },
    doAction_uiControl26: function (data, elem) {
      var index = data.dataCustom;
      console.log(index);
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl26: function () {
      var selfTemplate = "const MyList = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"table-a\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}} />\n  },\n  onClick: function(e) {\n  \tvar target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    if (index) {\n      var handler = this.props.customHandler;\n      handler({\n      \tdata: index\n      });\n    }\n  }\n});\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"table-a\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    if (index) {\n      var handler = this.props.customHandler;\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = MyList;";
    },
    getData_control12: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var oPage = {
        "currentPage": aSpan[0].textContent,
        "totalPage": aSpan[1].textContent,
        "totalRecords": aSpan[2].textContent
      };
      return oPage;
    },
    doAction_uiControl27: function (data, elem) {},
    getTemplate_uiControl27: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共{data.totalPage}页</span><span>总共{data.totalRecords}条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        data.totalPage,\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        data.totalRecords,\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control13: function (elem) {
      var info = [{
        "text": "首页",
        "index": "0"
      }, {
        "text": "上一页",
        "index": "1"
      }, {
        "text": "下一页",
        "index": "2"
      }, {
        "text": "末页",
        "index": "3"
      }];
      return info;
    },
    doAction_uiControl28: function (data, elem) {
      var index = parseInt(data.dataCustom);
      elem.querySelectorAll("input")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl28: function () {
      var selfTemplate = "const MyBtn = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    var items = data.map( function(item) {\n    \treturn <span data-index={item.index}>{item.text}</span>\n    });\n    return <div onClick={this.onClick} className=\"pageBtn\">{items}</div>\n  },\n  onClick: function(e) {\n  \tvar target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n    \tdata: index\n    });\n  }\n});\nexport default MyBtn;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBtn = React.createClass({\n  displayName: \"MyBtn\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        { \"data-index\": item.index },\n        item.text\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { onClick: this.onClick, className: \"pageBtn\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\nexports.default = MyBtn;";
    },
    getData_control16: function (elem) {
      var list = [];
      var getOption = elem.getElementsByTagName("option");

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": elem.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl4: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl4: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    console.log(data);\n    var items = data.map(function(item, index){\n      if(item.sel === \"selected\"){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n        return <option value={index}>{item.index}</option>\n      }\n    })\n   if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n   }\n    else{\n       return <select onChange={this.onChange}>{items}</select>\n   }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    console.log(data);\n    var items = data.map(function (item, index) {\n      if (item.sel === \"selected\") {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control17: function (elem) {
      var list = [];
      var getOption = elem.getElementsByTagName("option");

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": elem.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl35: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl35: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    console.log(data);\n    var items = data.map(function(item, index){\n      if(item.sel === \"selected\"){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n        return <option value={index}>{item.index}</option>\n      }\n    })\n   if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n   }\n    else{\n       return <select onChange={this.onChange}>{items}</select>\n   }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    console.log(data);\n    var items = data.map(function (item, index) {\n      if (item.sel === \"selected\") {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control18: function (elem) {
      var list = [];
      var getOption = elem.getElementsByTagName("option");

      for (var i = 0; i < getOption.length; i++) {
        list.push({
          "index": getOption[i].textContent,
          "dis": elem.getAttribute("disabled"),
          "sel": getOption[i].getAttribute("selected")
        });
      }

      return list;
    },
    doAction_uiControl36: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.getElementsByTagName("option")[index];

      if (event.checked) {
        event.selected = false;
      } else {
        event.selected = true;
      }

      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl36: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    console.log(data);\n    var items = data.map(function(item, index){\n      if(item.sel === \"selected\"){\n    \treturn <option value={index} selected = \"selected\">{item.index}</option>\n      }\n      else{\n        return <option value={index}>{item.index}</option>\n      }\n    })\n   if(data[0].dis === \"disabled\"){\n    return <select onChange={this.onChange} disabled=\"disabled\">{items}</select>\n   }\n    else{\n       return <select onChange={this.onChange}>{items}</select>\n   }\n  },\n  \n  onChange: function(e) {\n  \tvar target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if(handler){\n    \thandler({\n      \t\"data\": index\n      })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    console.log(data);\n    var items = data.map(function (item, index) {\n      if (item.sel === \"selected\") {\n        return React.createElement(\n          \"option\",\n          { value: index, selected: \"selected\" },\n          item.index\n        );\n      } else {\n        return React.createElement(\n          \"option\",\n          { value: index },\n          item.index\n        );\n      }\n    });\n    if (data[0].dis === \"disabled\") {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange, disabled: \"disabled\" },\n        items\n      );\n    } else {\n      return React.createElement(\n        \"select\",\n        { onChange: this.onChange },\n        items\n      );\n    }\n  },\n\n  onChange: function onChange(e) {\n    var target = e.target;\n    var index = target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"data\": index\n      });\n    }\n  }\n});\nexports.default = Data;";
    }
  });
})(window, ysp);