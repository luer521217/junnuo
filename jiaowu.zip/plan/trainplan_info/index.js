(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control39: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control40: function (elem) {
      var aList = [];
      var aTr = elem.querySelectorAll("tr");

      if (aTr.length > 1) {
        for (var i = 0; i < 13; i++) {
          var aTd = aTr[i].querySelectorAll("td");
          aList.push({
            "title": aTd[0].textContent,
            "date": aTd[1].textContent,
            "index": i
          });
        }
      }

      return aList;
    },
    doAction_uiControl2: function (data, elem) {},
    getTemplate_uiControl2: function () {
      var selfTemplate = "const MyList = React.createClass({\n\trender: function() {\n     var data = this.props.data.customData;\n    var items = data.map( function(item) {\n     return( <span data-index={item.index}>{item.title}：{item.date}</span>)\n    });\n    return <div className=\"info\">{items}</div>\n  }\n});\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        { \"data-index\": item.index },\n        item.title,\n        \"：\",\n        item.date\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { className: \"info\" },\n      items\n    );\n  }\n});\nexports.default = MyList;";
    }
  });
})(window, ysp);