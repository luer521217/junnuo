(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control70: function (elem) {
      if (elem.files.length) {
        return elem.files[0].name;
      }
    },
    doAction_uiControl188: function (data, elem) {},
    getTemplate_uiControl188: function () {
      var selfTemplate = "module.exports = React.createClass({\n\trender: function(){\n  \treturn <div>{this.props.data.customData}</div>\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      this.props.data.customData\n    );\n  }\n});";
    },
    getData_control164_TqJsUE: function (elem) {
      var $img = elem;var canvas = document.createElement('CANVAS');var ctx = canvas.getContext('2d');var dataUrl;canvas.height = 192;canvas.width = 144;ctx.drawImage($img, 18, 24);dataUrl = canvas.toDataURL('image/png');return dataUrl;
    },
    doAction_uiControl283_plfLKr: function (data, elem) {},
    getTemplate_uiControl283_plfLKr: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <div className=\"imgWrap\">\n    \t<img src={data}/>\n        </div>\n    )\n  },\n  onClick: function(e){\n  \tvar handler = this.props.customHandler;\n    handler({})\n  }\n\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"imgWrap\" },\n      React.createElement(\"img\", { src: data })\n    );\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n\n});";
    }
  });
})(window, ysp);