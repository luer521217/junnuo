(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control21: function (elem) {},
    doAction_uiControl14: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl14: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control22: function (elem) {
      return elem.value;
    },
    doAction_uiControl7: function (data, elem) {
      elem.value = data.dataCustom;
      elem.dispatchEvent(new Event('keyup'));
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "module.exports = React.createClass({\n\n  onChange:function(e) {                   \n    var handler= this.props.customHandler; \n    if(e.target.value && e.target.value != \"\") {\n      document.getElementsByClassName(\"yl_mmqd\")[0].style = \"display: block;\";     \n    } else {\n      document.getElementsByClassName(\"yl_mmqd\")[0].style = \"display: none;\";\n    }\n    if(handler) {\n\n      handler({                            \n        data: e.target.value,\n\n        eventType:'change'\n\n      })\n\n    }\n\n  },\n\n  render: function(){\n    var data = this.props.data.customData;   \n    return (\n      <input type=\"password\" className=\"yl_right\" value={data} onChange={this.onChange}/> \n\n    );\n\n  }\n\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  onChange: function onChange(e) {\n    var handler = this.props.customHandler;\n    if (e.target.value && e.target.value != \"\") {\n      document.getElementsByClassName(\"yl_mmqd\")[0].style = \"display: block;\";\n    } else {\n      document.getElementsByClassName(\"yl_mmqd\")[0].style = \"display: none;\";\n    }\n    if (handler) {\n\n      handler({\n        data: e.target.value,\n\n        eventType: 'change'\n\n      });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"input\", { type: \"password\", className: \"yl_right\", value: data, onChange: this.onChange });\n  }\n\n});";
    }
  });
})(window, ysp);