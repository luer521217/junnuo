(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control13: function (elem) {
      var aList = [];
      var aSpan = elem.querySelectorAll("span");

      for (var i = 0; i < aSpan.length; i++) {
        aList.push({
          "title": aSpan[i].textContent,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl17: function (data, elem) {
      elem.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl17: function () {
      var selfTemplate = "const MyInfo = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <span className=\"yl_span\" data-index={item.index}>{item.title}</span>\n    });\n    return <div className=\"yl_div\" onClick={this.onClick}>{items}</div>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyInfo;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyInfo = React.createClass({\n  displayName: \"MyInfo\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        { className: \"yl_span\", \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { className: \"yl_div\", onClick: this.onClick },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyInfo;";
    },
    getData_control14: function (elem) {},
    doAction_uiControl8: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl8: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name=\"left-nav\" onClick={this.onClick} className=\"backBtn\">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: \"left-nav\", onClick: this.onClick, className: \"backBtn\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);