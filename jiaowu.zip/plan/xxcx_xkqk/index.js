(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {
      var map = Array.prototype.map;
      var content = map.call($(elem).find('tbody').find('tr'), function (tr) {
        return map.call($(tr).find('td'), function (td) {
          return td.textContent;
        });
      });
      return {
        content: content
      };
    },
    doAction_uiControl15: function (data, elem) {},
    getTemplate_uiControl15: function () {
      var selfTemplate = "// 没用到\nvar Table = require(\"ysp-interior-components\").Table;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.data.customData.content;\n    // 提取表格头\n    var thead = data[0].map(function(item, index){\n      return <th>{item}</th>\n    })\nvar tbody = [];\n\t\tfor(var i=1; i<data.length; i++){\n    var td = data[i].map(function(item, index){\n      \treturn <td>{item}</td>\n      })\n    // i从1开始\n    var tr = <tr onClick={this.handleClick} data-index={i-1}>{td}</tr>;\n    tbody.push(tr);\n    }\n    \n    return (\n      <table>\n        <thead>\n          <tr>{thead}</tr>\n        </thead>\n        <tbody>\n          {tbody}\n        </tbody>\n      </table>\n    )\n  }\n});\n";
      return "\"use strict\";\n\n// 没用到\nvar Table = require(\"ysp-interior-components\").Table;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData.content;\n    // 提取表格头\n    var thead = data[0].map(function (item, index) {\n      return React.createElement(\n        \"th\",\n        null,\n        item\n      );\n    });\n    var tbody = [];\n    for (var i = 1; i < data.length; i++) {\n      var td = data[i].map(function (item, index) {\n        return React.createElement(\n          \"td\",\n          null,\n          item\n        );\n      });\n      // i从1开始\n      var tr = React.createElement(\n        \"tr\",\n        { onClick: this.handleClick, \"data-index\": i - 1 },\n        td\n      );\n      tbody.push(tr);\n    }\n\n    return React.createElement(\n      \"table\",\n      null,\n      React.createElement(\n        \"thead\",\n        null,\n        React.createElement(\n          \"tr\",\n          null,\n          thead\n        )\n      ),\n      React.createElement(\n        \"tbody\",\n        null,\n        tbody\n      )\n    );\n  }\n});";
    },
    getData_control7: function (elem) {},
    doAction_uiControl11: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = 'const MyBack = React.createClass({\n  render: function() {\n    return <AMUI.Icon name="left-nav" onClick={this.onClick} className="backBtn">返回</AMUI.Icon>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;';
      return '"use strict";\n\nObject.defineProperty(exports, "__esModule", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: "MyBack",\n\n  render: function render() {\n    return React.createElement(\n      AMUI.Icon,\n      { name: "left-nav", onClick: this.onClick, className: "backBtn" },\n      "返回"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;';
    }
  });
})(window, ysp);