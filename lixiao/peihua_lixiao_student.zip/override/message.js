/*
 * 本次更新内容
 * 放弃ymPrompt弹出层（有弹出层无法关闭bug）
 * 使用lhgdialog弹出层
 * 放弃 window.alert = showAlertDivLayer 浏览器alert不能占用
 * @user:943
 * @date:2013-9-10 12:00:00
 */


/**初始化参数*/

var config = {
		// 注意，此配置参数只能在这里使用全局配置，在调用窗口的传参数使用无效
		lock : true,
		fixed : true,
		max : false,
		min :false
};
/* 扩展窗口外部方法 */
var notice = function( options )
{
    var opts = options || {},
        api, aConfig, hide, wrap, top,
        duration = opts.duration || 800;

    var config = {
        id: 'Notice',
        left: '100%',
        top: '100%',
        fixed: true,
        drag: false,
        resize: false,
        max : false,
		min :false,
        init: function(here){
            api = this;
            aConfig = api.config;
            wrap = api.DOM.wrap;
            top = parseInt(wrap[0].style.top);
            hide = top + wrap[0].offsetHeight;

            wrap.css('top', hide + 'px')
            .animate({top: top + 'px'}, duration, function(){
                opts.init && opts.init.call(api, here);
            });
        },
        close: function(here){
            wrap.animate({top: hide + 'px'}, duration, function(){
                opts.close && opts.close.call(this, here);
                aConfig.close = $.noop;
                api.close();
            });

            return false;
        }
    };

    for(var i in opts)
    {
        if( config[i] === undefined ) config[i] = opts[i];
    }

    return jQuery.dialog( config );
};


/**
 * 在弹出iframe窗口中刷新父页面，并关闭窗口
 */
function refershParent(){
	if(frameElement && frameElement.api){
		var api = frameElement.api,W = api.opener;
		W.jQuery('#search_go').click();
		closeDialog();
	}
}

/**
 * 关闭模态窗口
 */
function closeDialog(dialogId){
	var api = frameElement.api;
	if(dialogId && api.get(dialogId)){
		api.get(dialogId,1).close();
	}else{
		api.close();
	}
	api.zindex();
}
/**
 * 关闭所有窗口
 */
function closeAllDialog(){
	if(frameElement && frameElement.api){
		var api = frameElement.api,W = api.opener;
		var list = W.lhgdialog.list;
		for( var i in list ){
		    list[i].close();
		}
	}

}
/**弹出窗口
 * @param message 消息内容
 * @param width 宽度
 * @param height 高度
 * @param urls URL
 * @param other 其它参数 json 格式
 * @return
 */
function showDialog(message,width,height,url,other){
	var params={
		title: message,
		content: "url:"+url,
		width: getAdapterWidth(width),
		height: getAdapterHeight(height)
	}
	params = jQuery.extend(params, config);
	if(frameElement&& frameElement.api){
		var api = frameElement.api, W = api.opener;
		var childDialog = api.get("childDialog");
		if(childDialog!=null){
			params["id"]="childDialog2";
			params["parent"]=api;
			params = jQuery.extend(params, other);
			return W.jQuery.dialog(params);
		}
		params["id"]="childDialog";
		params["parent"]=api;
		params = jQuery.extend(params, other);
		return W.jQuery.dialog(params);
	}else{
		params["id"]="parentDialog";
		params["parent"]=window;
		params = jQuery.extend(params, other);
		return jQuery.dialog(params);
	}


}


//获取父类窗口window对象
function getParentDialogWin(){
	if(frameElement && frameElement.api){
		var api = frameElement.api, Win = api.content;
		if(api.get("childDialog2") != null && api.get("childDialog2") != Win){
			return api.get("childDialog2");
		}else if(api.get("childDialog") != null && api.get("childDialog") != Win){
			return api.get("childDialog");
		}else if(api.get("parentDialog") != null && api.get("parentDialog") != Win){
			return api.get("parentDialog");
		}else{
			return api.opener;
		}
	}else{
		return window.parent;
	}
}

/**消息弹出层
 * @param message 内容
 * @param width 宽度
 * @param height 高度
 * @param title 标题
 * @param other 其它参数 支持json
 * @return
 */
function alertDialog(message,width,height,title,other){
	var params={
		title: title,
		content: message,
		width: width,
		height: height
	}
	params = jQuery.extend(params, config);
	params = jQuery.extend(params, other);
	if(frameElement&& frameElement.api){
		var api = frameElement.api, W = api.opener;
		params["parent"]=api;
		return W.jQuery.dialog(params);
	}else{
		params["parent"]=window;
		return jQuery.dialog(params);
	}
}
/**保存结果提示框
 * @param message
 * @param callback
 * @param title
 * @return
 */
function alertMessage(message,callback,title){
	if(message!=null && message.length>0){
		var index_cg= message.indexOf('成功');
		var index_sb= message.indexOf('失败');
		if(index_cg>0){
			alertSuccess(message, callback, title);
		}else if (index_sb>0){
			alertFail(message, callback, title);
		}
	}
	alertInfo(message, callback, title);
}
/**警告弹出层
 * @param message 消息内容
 * @param title 标题
 * @param callback 回调
 * @return
 */

window.onload = function(){
	alertMessages = "";
	alertWrap = document.createElement("div");
	alertWrap.setAttribute("id", "alertDiv");
	alertWrap.innerHTML = "";
	if(document.getElementsByClassName("mybutton").length > 0){
		alertParent = document.getElementsByClassName("mybutton")[0];
		alertParent.appendChild(alertWrap);
	} else if(document.getElementsByClassName("change_pswd").length > 0){
		alertParent = document.getElementsByClassName("change_pswd")[0];
		alertParent.appendChild(alertWrap);
	}
};

function alertInfo(message,callback,title,other){
	/**系统管理  alert('${result}', '', { 'clkFun' : function() { 	refershParent(); } }); 无耻的方法做下兼容 ******/
	if(title!=null && title!=""){
		if(title.clkFun!=null && title.clkFun!=""){
			title=null;
			callback=function(){
				this.close();
				var api = frameElement.api, W = api.opener;
				W.jQuery("#search_go").click();
				api.close();
			}
		}
	}
	/*****************************end************************************************************/
	// var param={icon:'alert.gif',id:'alertDialog',ok:default_callback(callback)}
	// alertDialog(message,220,100,default_title(title),jQuery.extend(param,other));

  if(message === "原密码和新密码不能为空！"){
    alertMessages = "原密码和新密码不能为空！";
  } else if (message === "两次密码输入不一致！"){
  	alertMessages = "两次密码输入不一致！";
  } else if (message === "密码强度过弱，请输入字母、数字、下划线组合！"){
  	alertMessages = "密码强度过弱，请输入字母、数字、下划线组合！";
} else if (message === "截图成功！") {
	alertMessages = "上传成功，请返回！";
}

  alertWrap.innerHTML = alertMessages;

}
/**失败弹出层
 * @param message 消息内容
 * @param title 标题
 * @param callback 回调
 * @return
 */
function alertFail(message,callback,title,other){
	var param={icon:'error.gif',id:'alertDialog',ok:default_callback(callback)}
	alertDialog(message,220,100,default_title(title),jQuery.extend(param,other));
}
/**成功弹出层
 * @param message 消息内容
 * @param title 标题
 * @param callback 回调
 * @return
 */
function alertSuccess(message,callback,title,other){
	var param={icon:'success.gif',id:'alertDialog',ok:default_callback(callback)};
	alertDialog(message,220,100,default_title(title),jQuery.extend(param,other));
}
/**确认弹出
 * @param message 消息内容
 * @param title 标题
 * @param callback 回调
 * @return
 */
function alertConfirm(message,yes,cancle,title){
	alertDialog(message,220,100,default_title(title),{icon:'prompt.gif',id:'alertDialogConfirm',ok:default_callback(yes),cancelVal:'取消',cancel:true});
}
function default_title(title){
	if(title==null||title.length==0){
		return "温馨提示";
	}
	return title;
}
function default_callback(callback){
	if(callback==null){
		return function(){
			if(frameElement&& frameElement.api){
				var api = frameElement.api;
				api.zindex();
			}
			this.close();
			return false;
		};
	}else if(callback==false){
		return null;
	}
	return callback;
}
/**右下脚弹出提示
 * @param message 提示消息
 * @param time 显示时长
 * @param title 标题
 * @param other 其它参数
 * @return
 */
function alertNotice(message,time,title,other){
	var param = {
		    title: default_title(title),
		    width: 220,  /*必须指定一个像素宽度值或者百分比，否则浏览器窗口改变可能导致lhgDialog收缩 */
		    height:100,
		    content: message,
		    time: time
		};
	notice(jQuery.extend(param,other));
}
/**输入文本框
 * @param message 消息内容
 * @param callback 回调
 * @param title 标题
 * @param defval 默认值
 * @param other 其它参数
 * @return
 */
function alertPrompt(message,callback,title,defval,other){
	var params={
		title: title,
		content:"<span style='font-weight:bold;'>" + message + "</span><input type='text' id='alertPrompt_text' style='margin-top:10px;width:250px;height:30px;' value='"+defval+"'>",
		width: 300,
		//icon:"prompt.gif",
		height: 100,
		ok:function (){
				callback(frameElement.api.opener.jQuery("#alertPrompt_text").val());
			},
		cancelVal: '关闭',
        cancel: true /*为true等价于function(){}*/
	}
	params = jQuery.extend(params, config);
	params = jQuery.extend(params, other);
	if(frameElement&& frameElement.api){
		var api = frameElement.api, W = api.opener;
		params["parent"]=api;
		return W.jQuery.dialog(params);
	}else{
		params["parent"]=window;
		return jQuery.dialog(params);
	}


}

/**延迟加载加载
 * @param time 多长时间关闭
 * @param callback 回调
 * @param message 消息内容 默认 数据加载中
 * @param other 其它参数
 * @return
//  */
function alertTips(time,callback,message){
	if(!message){
		message='数据加载中...';
	}
	var params={
		id: 'alertTips',
		title: false,
		content:message,
		width: 150,
		height: 50,
		icon: 'loading.gif',
		callback:callback
	}
	var rr ;
	params = jQuery.extend(params, config);
	if(frameElement&& frameElement.api){
		var api = frameElement.api, W = api.opener;
		params["parent"]=api;
		rr =  W.jQuery.dialog(params);
	}else{
		params["parent"]=window;
		rr = jQuery.dialog(params);
	}
	rr.time(time);
	return rr;
}
