(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control12: function (elem) {
      return elem;

    },
    doAction_uiControl13: function (data, elem) {
      
    },
    getTemplate_uiControl13: function () {
      var selfTemplate = "// const Data = React.createClass({\n// \trender: function(){\n//   \tvar data = this.props.data.customData;\n//     return {data}\n//   }\n// })\n// export default Data;";
      return "// const Data = React.createClass({\n// \trender: function(){\n//   \tvar data = this.props.data.customData;\n//     return {data}\n//   }\n// })\n// export default Data;\n\"use strict\";";
    }
  });
})(window, ysp);