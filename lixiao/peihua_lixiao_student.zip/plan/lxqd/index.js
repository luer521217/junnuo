(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control38: function (elem) {
      var clone = elem.cloneNode(true);
      var list = [];
      var getTd = clone.querySelectorAll("td");
      for (var i = 0; i < getTd.length; i++) {
        if (getTd[i].innerHTML !== "") {
          list.push({
            title: getTd[i].querySelector("dt").innerText,
            date: getTd[i].querySelector("span").innerText,
            class: getTd[i].getAttribute("class")
          });
        }
      }
      return list;
    },
    doAction_uiControl61: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl61", "context0");
      var index = data.dataCustom;
      var event = elem.getElementsByTagName("dl")[index];
      event.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl61: function () {
      var selfTemplate = "const Data = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    var items = data.map(function(item, index){\n      if(item.class === \"tip1\"){\n        return <div className=\"tip1\" data-index={index}><h3>{item.title}</h3><span>{item.date}</span></div>\n      } else if (item.class === \"tip2\"){\n\t\t\t\treturn <div className=\"tip2\" data-index={index}><h3>{item.title}</h3><span>{item.date}</span></div>\n      } else if (item.class === \"tip3\"){\n\t\t\t\treturn <div className=\"tip3\" data-index={index}><h3>{item.title}</h3><span>{item.date}</span></div>\n      } else {\n        return <div className=\"wrap\"><div><h3>{item.title}</h3><span>{item.date}</span></div></div>\n      }\n    });\n    return <section onClick={this.onClick}>{items}</section>\n  },\n  \n  onClick: function(e){\n  \tvar target  = findDiv(e.target);\n          function findDiv(elem){\n      \tif(elem.tagName == \"DIV\"){\n        \treturn elem;\n        } else {\n        \treturn findDiv(elem.parentNode);\n        }\n      }\n    var index = target.getAttribute(\"data-index\");\n       var handler = this.props.customHandler;\n    if(handler) {\n    handler({\n    \tdata: index\n    })\n    }\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      if (item.class === \"tip1\") {\n        return React.createElement(\n          \"div\",\n          { className: \"tip1\", \"data-index\": index },\n          React.createElement(\n            \"h3\",\n            null,\n            item.title\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            item.date\n          )\n        );\n      } else if (item.class === \"tip2\") {\n        return React.createElement(\n          \"div\",\n          { className: \"tip2\", \"data-index\": index },\n          React.createElement(\n            \"h3\",\n            null,\n            item.title\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            item.date\n          )\n        );\n      } else if (item.class === \"tip3\") {\n        return React.createElement(\n          \"div\",\n          { className: \"tip3\", \"data-index\": index },\n          React.createElement(\n            \"h3\",\n            null,\n            item.title\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            item.date\n          )\n        );\n      } else {\n        return React.createElement(\n          \"div\",\n          { className: \"wrap\" },\n          React.createElement(\n            \"div\",\n            null,\n            React.createElement(\n              \"h3\",\n              null,\n              item.title\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              item.date\n            )\n          )\n        );\n      }\n    });\n    return React.createElement(\n      \"section\",\n      { onClick: this.onClick },\n      items\n    );\n  },\n\n  onClick: function onClick(e) {\n    var target = findDiv(e.target);\n    function findDiv(elem) {\n      if (elem.tagName == \"DIV\") {\n        return elem;\n      } else {\n        return findDiv(elem.parentNode);\n      }\n    }\n    var index = target.getAttribute(\"data-index\");\n     var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = Data;";
    },
    getData_control40: function (elem) {
      var getImg = elem.querySelector("img").src;
      return getImg;
    },
    doAction_uiControl63: function (data, elem) {},
    getTemplate_uiControl63: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n   \treturn <img src={data} />\n  }\n})\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"img\", { src: data });\n  }\n});\n\nexports.default = Data;";
    },
    getData_control45: function (elem) {
      var getSrc = elem.querySelector("img").src;
      return getSrc;
    },
    doAction_uiControl8: function (data, elem) {},
    getTemplate_uiControl8: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    return <img src={data} />\n  }\n})\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"img\", { src: data });\n  }\n});\n\nexports.default = Data;";
    },
    getData_control49: function (elem) {

    },
    doAction_uiControl59: function (data, elem) {
      ysp.source.postMessage({
  resultType: "EAPI:back"
});
    },
    getTemplate_uiControl59: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"back-up-level\" onClick={this.onClick} ></button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"button\", { className: \"back-up-level\", onClick: this.onClick });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = Data;";
    }
  });
})(window, ysp);
