(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1: function (elem) {
      var aList = [];
      var aLi = elem.querySelectorAll("li");
      for (var i = 0; i < aLi.length; i++) {
        aList.push({
          "title": aLi[i].getElementsByTagName("a")[0].innerText,
          "date": aLi[i].getElementsByTagName("span")[0].innerText,
          "index": i
        });
      }
      return aList;
    },
    doAction_uiControl3: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl3", "context0");
      var index = parseInt(data.dataCustom);
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl3: function () {
      var selfTemplate = "const MyList = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return (\n        <li data-index={item.index}>\n          <a>{item.title}</a>\n          <span>{item.date}</span>\n        </li>\n      )\n    });\n    return <ul onClick={this.onClick} className=\"list-a\">{items}</ul>\n  },\n  onClick: function(e) {\n    var target = findLi(e.target);\n    var index = target.getAttribute(\"data-index\");\n        var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n    function findLi(elem) {\n      if (elem.nodeName == \"LI\") {\n        return elem;\n      } else {\n        return findLi(elem.parentNode);\n      }\n    }\n  }\n});\n\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"li\",\n        { \"data-index\": item.index },\n        React.createElement(\n          \"a\",\n          null,\n          item.title\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          item.date\n        )\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { onClick: this.onClick, className: \"list-a\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = findLi(e.target);\n    var index = target.getAttribute(\"data-index\");\n      var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n    function findLi(elem) {\n      if (elem.nodeName == \"LI\") {\n        return elem;\n      } else {\n        return findLi(elem.parentNode);\n      }\n    }\n  }\n});\n\nexports.default = MyList;";
    }
  });
})(window, ysp);
