(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    // getData_control7: function (elem) {
    //   var aList = [];
    //   var aA = elem.querySelectorAll("a");
    //   for (var i = 0; i < aA.length; i++) {
    //     aList.push({
    //       "title": aA[i].innerText,
    //       "index": i
    //     });
    //   }
    //   return aList;
    // },
    // doAction_uiControl15: function (data, elem) {
    //   ysp.runtime.Flow.setLastFlow("uiControl15", "context0");
    //   var index = data.dataCustom;
    //   elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    // },
    // getTemplate_uiControl15: function () {
    //   var selfTemplate = "const MyList = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <a data-index={item.index}>{item.title}</a>\n    });\n    return <div onClick={this.onClick} className=\"list-a\">{items}</div>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyList;";
    //   return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"a\",\n        { \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { onClick: this.onClick, className: \"list-a\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyList;";
    // },

    //     getData_control22: function (elem) {
    //       var aList = [];
    // var aRoot = elem.querySelectorAll(".rt > div");
    // console.log(aRoot);
    // for (var i = 1; i < aRoot.length; i++) {
    //   var aDl = aRoot[i].getElementsByTagName("dl");
    //   aList.push({
    //     "title": aDl[i].querySelectorAll("dt")[1].innerText,
    //     "date": aDl[i].querySelectorAll("dd")[0].innerText,
    //     "class": aDl[i].getAttribute("class"),
    //     "index": i
    //   });
    // }
    // return aList;
    //     },
    //     doAction_uiControl25: function (data, elem) {},
    //     getTemplate_uiControl25: function () {
    //       var selfTemplate = "";
    //       return "\"use strict\";";
    //     },
    getData_control22: function (elem) {
      var aList = [];
      var aRoot = elem.querySelectorAll(".rt > div");
      for (var i = 1; i < aRoot.length; i++) {
        var aDl = aRoot[i].getElementsByTagName("dl")[0];
        aList.push({
          "img": aDl.querySelectorAll("dt")[0].querySelector("img").src,
          "title": aDl.querySelectorAll("dt")[1].getAttribute("title"),
          "date": aDl.querySelectorAll("dd")[0].innerText,
          "class": aDl.getAttribute("class"),
          "index": i
        });
      }
      return aList;
    },
    doAction_uiControl12: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl12", "context0");
      var index = parseInt(data.dataCustom);
      elem.querySelectorAll(".rt > div")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "const MyList = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item,index) {\n      var loadImg;\n      if(item.class === \"dl01 dl01_check01\"){\n         loadImg = <div className=\"img01\"></div>\n      }\n      else if(item.class === \"dl02 dl01_check02\"){\n         loadImg = <div className=\"img02\"></div>\n      }\n      else if(item.class === \"dl03 dl01_check03\"){\n         loadImg = <div className=\"img03\"></div>\n      }\n      else{\n         loadImg = <div src = \"\"></div>\n      }\n      return (\n       <div data-index={item.index}>\n          <img className=\"img\" src={item.img} />\n          <h5>{item.title}</h5>\n          {loadImg}\n          <span>{item.date}</span>\n       </div>\n      )\n    });\n    return  <section className = \"root\" onClick={this.onClick}>{items}</section>\n  },\n  onClick: function(e) {\n    var target = findDiv(e.target);\n          function findDiv(elem){\n      \tif(elem.tagName == \"DIV\"){\n        \treturn elem;\n        } else {\n        \treturn findDiv(elem.parentNode);\n        }\n      }\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n      handler({\n      data: index\n    });\n  }\n});\n\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      var loadImg;\n      if (item.class === \"dl01 dl01_check01\") {\n        loadImg = React.createElement(\"div\", { className: \"img01\" });\n      } else if (item.class === \"dl02 dl01_check02\") {\n        loadImg = React.createElement(\"div\", { className: \"img02\" });\n      } else if (item.class === \"dl03 dl01_check03\") {\n        loadImg = React.createElement(\"div\", { className: \"img03\" });\n      } else {\n        loadImg = React.createElement(\"div\", { src: \"\" });\n      }\n      return React.createElement(\n        \"div\",\n        { \"data-index\": item.index },\n        React.createElement(\"img\", { className: \"img\", src: item.img }),\n        React.createElement(\n          \"h5\",\n          null,\n          item.title\n        ),\n        loadImg,\n        React.createElement(\n          \"span\",\n          null,\n          item.date\n        )\n      );\n    });\n    return React.createElement(\n      \"section\",\n      { className: \"root\", onClick: this.onClick },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = findDiv(e.target);\n    function findDiv(elem) {\n      if (elem.tagName == \"DIV\") {\n        return elem;\n      } else {\n        return findDiv(elem.parentNode);\n      }\n    }\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n     handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyList;";
    },
    getData_control7: function (elem) {
      var aList = [];
      var aA = elem.querySelectorAll("a");
      for (var i = 0; i < aA.length; i++) {
        aList.push({
          "title": aA[i].innerText,
          "index": i
        });
      }
      return aList;
    },
    doAction_uiControl15: function (data, elem) {
      ysp.runtime.Flow.setLastFlow("uiControl15", "context0");
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl15: function () {
      var selfTemplate = "const MyList = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <a data-index={item.index}>{item.title}</a>\n    });\n    return <div onClick={this.onClick} className=\"list-a\">{items}</div>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"a\",\n        { \"data-index\": item.index },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"div\",\n      { onClick: this.onClick, className: \"list-a\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyList;";
    },
    getData_control26: function (elem) {

    },
    doAction_uiControl13: function (data, elem) {
      ysp.source.postMessage({
  resultType: "EAPI:back"
});

    },
    getTemplate_uiControl13: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"back-up-level\" onClick={this.onClick} ></button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"button\", { className: \"back-up-level\", onClick: this.onClick });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = Data;";
    }
  });
})(window, ysp);
