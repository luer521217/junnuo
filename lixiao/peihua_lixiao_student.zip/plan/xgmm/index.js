(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control14: function (elem) {},
    doAction_uiControl8: function (data, elem) {
      elem.dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl8: function () {
      var selfTemplate = "const Button = React.createClass({\n\trender: function(){\n  \treturn <button onClick={this.onClick}>确定</button>\n  },\n  onClick: function(e){\n  \tvar handler = this.props.customHandler;\n    handler({\n    })\n  }\n})\nexport default Button;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Button = React.createClass({\n  displayName: \"Button\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick },\n      \"确定\"\n    );\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = Button;";
    },
    getData_control19: function (elem) {
      return elem.value;

    },
    doAction_uiControl14: function (data, elem) {
      elem.value = data.dataCustom;
elem.dispatchEvent(new Event('keyup'));

    },
    getTemplate_uiControl14: function () {
      var selfTemplate = "module.exports = React.createClass({\n\tonChange: function(e) {\n  \tvar handler = this.props.customHandler;\n    if(handler){\n      \thandler({\n        \tdata: e.target.value,\n          eventType: 'change'\n        })\n    }\n  },\n    render:function(){\n    \tvar data = this.props.data.customData;\n      return(\n        <div className=\"new-pwd\">\n        <span class=\"field-label\">新密码：</span>\n      \t<input type=\"password\" value={data} onChange={this.onChange} />\n          </div>\n      )\n    }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  onChange: function onChange(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: e.target.value,\n        eventType: 'change'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"new-pwd\" },\n      React.createElement(\n        \"span\",\n        { \"class\": \"field-label\" },\n        \"新密码：\"\n      ),\n      React.createElement(\"input\", { type: \"password\", value: data, onChange: this.onChange })\n    );\n  }\n});";
    }
  });
})(window, ysp);
