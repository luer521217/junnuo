(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {
      if (elem.querySelector("#btn_fh")) {
        return "return";
      }
    },
    doAction_uiControl1: function (data, elem) {
    	if (data.dataCustom == "xg_back") {
        ysp.source.postMessage({
          resultType: "EAPI:back"
        });
      } else if (data.dataCustom == "lv_back xg_back") {
        elem.querySelector("#btn_fh").click();
      }
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    if(data){\n    return <button className=\"lv_back xg_back\" onClick={this.onClick} >返回</button>;  \n    }else{\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;\n    }\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data) {\n      return React.createElement(\n        \"button\",\n        { className: \"lv_back xg_back\", onClick: this.onClick },\n        \"返回\"\n      );\n    } else {\n      return React.createElement(\n        \"button\",\n        { className: \"xg_back\", onClick: this.onClick },\n        \"返回\"\n      );\n    }\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control1: function (elem) {
      var ta = elem.cloneNode(true);
      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option").replace(/href/g, "option").replace(/&nbsp;+/g, "");
      return ta.innerHTML;
    },
    doAction_uiControl3: function (data, elem) {
    	var index = data.dataCustom.index;
      var ad = elem.getElementsByTagName("a");

      for (var i = 0; i < ad.length; i++) {
        var ki = ad[i].getAttribute("href");

        if (ki == index) {
          ad[i].dispatchEvent(new Event("click"));
        }
      }
    },
    getTemplate_uiControl3: function () {
      var selfTemplate = "const Data = React.createClass({ \n      render: function () { \n        var data = this.props.data.customData;\n        return <div className=\"lv_ack_disContent   lv_ack_q \"  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>;  \n      },\n      onClick: function(e) {\n            var target =findR(e.target);\n        \t\tvar index=target.querySelector(\"a\").getAttribute(\"option\");\n          function findR(elem) {\n              if (elem.tagName === \"LI\") {\n                    return elem;\n              } else {\n                \t\treturn findR(elem.parentNode);\n              }\n          }\n\n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:{\n                        \"index\": index\n                    }\n                });\n            }\n      }\n  \n  });\t\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar Data = React.createClass({\n    displayName: \"Data\",\n\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { className: \"lv_ack_disContent   lv_ack_q \", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    },\n    onClick: function onClick(e) {\n        var target = findR(e.target);\n        var index = target.querySelector(\"a\").getAttribute(\"option\");\n        function findR(elem) {\n            if (elem.tagName === \"LI\") {\n                return elem;\n            } else {\n                return findR(elem.parentNode);\n            }\n        }\n\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: {\n                    \"index\": index\n                }\n            });\n        }\n    }\n\n});\n\nexports.default = Data;";
    }
  });
})(window, ysp);