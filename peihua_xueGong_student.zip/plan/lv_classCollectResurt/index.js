(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control2: function (elem) {
      var inTr = elem.getElementsByTagName("tbody")[0].getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td");
        oDiv.push({
          no: inTd[0].innerText,
          name: inTd[1].innerText,
          sex: inTd[2].innerText,
          id: inTd[3].innerText,
          nation: inTd[4].innerText,
          party: inTd[5].innerText,
          tell: inTd[6].innerText
        });
      }

      return oDiv;
    },
    doAction_uiControl9: function (data, elem) {},
    getTemplate_uiControl9: function () {
      var selfTemplate = "\nconst Data = React.createClass({ \n\n  render: function () { \n    var data = this.props.data.customData;\n    //console.log(data)\n\t\tvar items = data.map(function(item, index){\n            if ( data[index].error == undefined ) {\n              return (\n                <li className=\"lv_grc_li\" data-index={index}>\n                <span><b>学号：</b>{item.no}</span>\n             <span><font><b>姓名：</b>{item.name}</font>\n             <font><b>民族：</b>{item.nation}</font></span>\n            <span> <font><b>性别：</b>{item.sex}</font>\n             <font><b>电话：</b>{item.tell}</font></span>\n             <span><b>政治面貌：</b>{item.party}</span>\n             <span><b>身份证号：</b>{item.id}</span>\n               \n                </li>\n              )\n            }\n          });\n    //console.log(items.innerHTML)\n    return <ul className=\"lv_grc_ul\" >{items}</ul>; \n  }\n\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data)\n    var items = data.map(function (item, index) {\n      if (data[index].error == undefined) {\n        return React.createElement(\n          \"li\",\n          { className: \"lv_grc_li\", \"data-index\": index },\n          React.createElement(\n            \"span\",\n            null,\n            React.createElement(\n              \"b\",\n              null,\n              \"学号：\"\n            ),\n            item.no\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"姓名：\"\n              ),\n              item.name\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"民族：\"\n              ),\n              item.nation\n            )\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            \" \",\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"性别：\"\n              ),\n              item.sex\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"电话：\"\n              ),\n              item.tell\n            )\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            React.createElement(\n              \"b\",\n              null,\n              \"政治面貌：\"\n            ),\n            item.party\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            React.createElement(\n              \"b\",\n              null,\n              \"身份证号：\"\n            ),\n            item.id\n          )\n        );\n      }\n    });\n    //console.log(items.innerHTML)\n    return React.createElement(\n      \"ul\",\n      { className: \"lv_grc_ul\" },\n      items\n    );\n  }\n\n});\n\nexports.default = Data;";
    },
    getData_control3: function (elem) {
      var aSpan = elem.querySelector("#max_page");
      var aSpano = elem.querySelector("#max_record");
      var aInput = elem.querySelector(".pagenum").querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan.textContent,
        "totalRecords": aSpano.textContent
      };
      return oPage;
    },
    doAction_uiControl10: function (data, elem) {},
    getTemplate_uiControl10: function () {
      var selfTemplate = "const MyPage = React.createClass({\nrender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    }
  });
})(window, ysp);