(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control3: function (elem) {
      if (elem.querySelector("input")) {
        var inIpt = elem.getElementsByTagName("input")[0];
        return {
          val: inIpt.value,
          name: inIpt.getAttribute("name"),
          type: inIpt.getAttribute("type")
        };
      } else if (elem.querySelector("a")) {
        var aA = elem.getElementsByTagName("a")[0];
        return {
          con: aA.innerText
        };
      }
    },
    doAction_uiControl6: function (data, elem) {
      elem.querySelector("a").click();
    },
    getTemplate_uiControl6: function () {
      var selfTemplate = "const Data = React.createClass({\n  \trender: function() {\n  \tvar data = this.props.data.customData;\n    if(data.type===\"text\"){\n    return (\n    \t<span>\n        <input value={data.val} name={data.name} type={data.type}/>\n      </span>\n    );\n      }\n    else if(data.type===\"hidden\"){\n      return(   \n        <span>\n          <input value={data.val} name={data.name} type={data.type}/>\n          <span>{data.val}</span>\n        </span>\n      )\n        }\n      else{\n      return (\n        <span className = \"y_aA\" onClick={this.onClick}>{data.con}</span>\n        )\n      } \n  },\n  onClick: function(e) {\n    var handler = this.props.customHandler;\n    handler({\n    });\n  }\n});\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data.type === \"text\") {\n      return React.createElement(\n        \"span\",\n        null,\n        React.createElement(\"input\", { value: data.val, name: data.name, type: data.type })\n      );\n    } else if (data.type === \"hidden\") {\n      return React.createElement(\n        \"span\",\n        null,\n        React.createElement(\"input\", { value: data.val, name: data.name, type: data.type }),\n        React.createElement(\n          \"span\",\n          null,\n          data.val\n        )\n      );\n    } else {\n      return React.createElement(\n        \"span\",\n        { className: \"y_aA\", onClick: this.onClick },\n        data.con\n      );\n    }\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = Data;";
    },
    getData_control14: function (elem) {
      if (elem) {
        var ta = elem.cloneNode(true);
        var ip = ta.querySelectorAll("input");

        if (ip.length == 2) {
          ip[0].className = "xg_two_btn";
          ip[1].className = "xg_two_btn1";
        } else if (ip.length == 1) {
          ip[0].className = "xg_one_btn";
        }

        ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
        return ta.innerHTML;
      }
    },
    doAction_uiControl22: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl22: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control522: function (elem) {
      if (elem && elem.querySelector("select")) {
        var sel = elem.querySelectorAll("select");
        var oP = {
          aP: [],
          aP1: [],
          aP2: [],
          aP3: [],
          aP4: [],
          aP5: []
        };
        var option = sel[0].querySelectorAll("option");

        for (var i = 0; i < option.length; i++) {
          oP.aP.push({
            "title": option[i].textContent,
            "value": option[i].value,
            "selected": option[i].selected
          });
        }

        var option1 = sel[1].querySelectorAll("option");

        for (var i = 0; i < option.length; i++) {
          oP.aP1.push({
            "title": option1[i].textContent,
            "value": option1[i].value,
            "selected": option1[i].selected
          });
        }

        var option2 = sel[2].querySelectorAll("option");

        for (var i = 0; i < option.length; i++) {
          oP.aP2.push({
            "title": option2[i].textContent,
            "value": option2[i].value,
            "selected": option2[i].selected
          });
        }

        var option3 = sel[3].querySelectorAll("option");

        for (var i = 0; i < option.length; i++) {
          oP.aP3.push({
            "title": option3[i].textContent,
            "value": option3[i].value,
            "selected": option3[i].selected
          });
        }

        var option4 = sel[4].querySelectorAll("option");

        for (var i = 0; i < option.length; i++) {
          oP.aP4.push({
            "title": option4[i].textContent,
            "value": option4[i].value,
            "selected": option4[i].selected
          });
        }

        var option5 = sel[5].querySelectorAll("option");

        for (var i = 0; i < option.length; i++) {
          oP.aP5.push({
            "title": option5[i].textContent,
            "value": option5[i].value,
            "selected": option5[i].selected
          });
        }

        return oP;
      }
    },
    doAction_uiControl544: function (data, elem) {
      var ind = data.dataCustom.index;
      var val = data.dataCustom.value;
      var tar = elem.querySelectorAll("select")[ind].querySelectorAll("option");

      for (var i = 0; i < tar.length; i++) {
        if (tar[i].value == val) {
          tar[i].selected = true;
        }
      }
    },
    getTemplate_uiControl544: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n\t\tvar items = data.aP.map(function (item) {\n\t\t\t\t\t\t\treturn (\n\t\t\t\t\t\t\t\t\t<option value={item.value} selected={item.selected}>{item.title}</option>\n\t\t\t\t\t\t\t);\n\t\t\t\t\t\t});\n    var items1 = data.aP1.map(function (item) {\n\t\t\t\t\t\t\treturn (\n\t\t\t\t\t\t\t\t\t<option value={item.value} selected={item.selected}>{item.title}</option>\n\t\t\t\t\t\t\t);\n\t\t\t\t\t\t});\n    var items2 = data.aP2.map(function (item) {\n\t\t\t\t\t\t\treturn (\n\t\t\t\t\t\t\t\t\t<option value={item.value} selected={item.selected}>{item.title}</option>\n\t\t\t\t\t\t\t);\n\t\t\t\t\t\t});\n    var items3 = data.aP3.map(function (item) {\n\t\t\t\t\t\t\treturn (\n\t\t\t\t\t\t\t\t\t<option value={item.value} selected={item.selected}>{item.title}</option>\n\t\t\t\t\t\t\t);\n\t\t\t\t\t\t});\n    var items4 = data.aP4.map(function (item) {\n\t\t\t\t\t\t\treturn (\n\t\t\t\t\t\t\t\t\t<option  value={item.value} selected={item.selected}>{item.title}</option>\n\t\t\t\t\t\t\t);\n\t\t\t\t\t\t});\n    var items5 = data.aP5.map(function (item) {\n\t\t\t\t\t\t\treturn (\n\t\t\t\t\t\t\t\t\t<option value={item.value} selected={item.selected}>{item.title}</option>\n\t\t\t\t\t\t\t);\n\t\t\t\t\t\t});\n\t\t\t\t\t\treturn (\n              <div>\n              <select data-index=\"0\" onChange={this.onChange}>{items}</select>\n              <select data-index=\"1\" onChange={this.onChange}>{items1}</select>\n              <select data-index=\"2\" onChange={this.onChange}>{items2}</select>\n              <select data-index=\"3\" onChange={this.onChange}>{items3}</select>\n              <select data-index=\"4\" onChange={this.onChange}>{items4}</select>\n              <select data-index=\"5\" onChange={this.onChange}>{items5}</select>\n              </div>\n\t\t\t\t\t\t);\n     },\n  onChange:function(e){\n    var val=e.target.value;\n    var ind=e.target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n         data:{ \n           \"index\": ind,\n           \"value\":val\n              }\n      });   \n    }\n  }\n  \n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.aP.map(function (item) {\n      return React.createElement(\n        \"option\",\n        { value: item.value, selected: item.selected },\n        item.title\n      );\n    });\n    var items1 = data.aP1.map(function (item) {\n      return React.createElement(\n        \"option\",\n        { value: item.value, selected: item.selected },\n        item.title\n      );\n    });\n    var items2 = data.aP2.map(function (item) {\n      return React.createElement(\n        \"option\",\n        { value: item.value, selected: item.selected },\n        item.title\n      );\n    });\n    var items3 = data.aP3.map(function (item) {\n      return React.createElement(\n        \"option\",\n        { value: item.value, selected: item.selected },\n        item.title\n      );\n    });\n    var items4 = data.aP4.map(function (item) {\n      return React.createElement(\n        \"option\",\n        { value: item.value, selected: item.selected },\n        item.title\n      );\n    });\n    var items5 = data.aP5.map(function (item) {\n      return React.createElement(\n        \"option\",\n        { value: item.value, selected: item.selected },\n        item.title\n      );\n    });\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"select\",\n        { \"data-index\": \"0\", onChange: this.onChange },\n        items\n      ),\n      React.createElement(\n        \"select\",\n        { \"data-index\": \"1\", onChange: this.onChange },\n        items1\n      ),\n      React.createElement(\n        \"select\",\n        { \"data-index\": \"2\", onChange: this.onChange },\n        items2\n      ),\n      React.createElement(\n        \"select\",\n        { \"data-index\": \"3\", onChange: this.onChange },\n        items3\n      ),\n      React.createElement(\n        \"select\",\n        { \"data-index\": \"4\", onChange: this.onChange },\n        items4\n      ),\n      React.createElement(\n        \"select\",\n        { \"data-index\": \"5\", onChange: this.onChange },\n        items5\n      )\n    );\n  },\n  onChange: function onChange(e) {\n    var val = e.target.value;\n    var ind = e.target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"index\": ind,\n          \"value\": val\n        }\n      });\n    }\n  }\n\n});";
    }
  });
})(window, ysp);