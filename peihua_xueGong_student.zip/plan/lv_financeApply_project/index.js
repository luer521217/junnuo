(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control5: function (elem) {
      var inIpt = elem.getElementsByTagName("input")[0];
      var inBtn = elem.getElementsByTagName("button")[0];

      if (inBtn) {
        return {
          val: inIpt.value,
          name: inIpt.getAttribute("name")
        };
      } else {
        return {
          val: inIpt.value
        };
      }
    },
    doAction_uiControl51: function (data, elem) {
      elem.getElementsByTagName("input")[0].value = data.dataCustom;
      elem.getElementsByTagName("input")[0].dispatchEvent(new Event('keyup'));
    },
    getTemplate_uiControl51: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onChange:function(e) {                 \n    var handler= this.props.customHandler; \n    if(handler) {\n      handler({                           \n        data: e.target.value,\n        eventType:'change'\n      })\n    }\n  },\n  render: function(){\n    var data = this.props.data.customData;    \n    if(data.name){\n    \treturn (\n        <input type=\"text\" value={data.val} onChange={this.onChange}/> \n      );\n    }else{\n    \treturn (\n        <input type=\"text\" value={data.val} className=\"lv_noAllborder\" onChange={this.onChange} /> \n      );\n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  onChange: function onChange(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: e.target.value,\n        eventType: 'change'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data.name) {\n      return React.createElement(\"input\", { type: \"text\", value: data.val, onChange: this.onChange });\n    } else {\n      return React.createElement(\"input\", { type: \"text\", value: data.val, className: \"lv_noAllborder\", onChange: this.onChange });\n    }\n  }\n});";
    },
    getData_control18: function (elem) {
      var wholeHTML = elem.cloneNode(true);
      var iSpan = wholeHTML.querySelector("#tips");
      var iDiv = wholeHTML.querySelector("#commonfileupload-list");
      var iBtn = iDiv.querySelectorAll("a");

      if (iBtn) {
        for (var i = 0; i < iBtn.length; i++) {
          iBtn[i].setAttribute("data-index", i);
        }
      }

      return {
        tips: iSpan.outerHTML,
        file: iDiv.outerHTML.replace(/href/g, "option")
      };
    },
    doAction_uiControl13: function (data, elem) {
      var index = data.dataCustom;
      var iDiv = elem.querySelector("#commonfileupload-list");
      var iBtn = iDiv.querySelectorAll("a");

      if (iBtn) {
        for (var i = 0; i < iBtn.length; i++) {
          if (i == index) {
            iBtn[i].click();
          }
        }
      }
    },
    getTemplate_uiControl13: function () {
      var selfTemplate = "const Data = React.createClass({\n\n  render: function() {\n  \tvar data = this.props.data.customData;\n    //console.log(data)\n    \n    return (\n    \t<div onClick={this.onclick} className=\"w_jxsq_fjxxTips\">\n      \t<div dangerouslySetInnerHTML={{__html:data.tips}}></div>\n      \t<div dangerouslySetInnerHTML={{__html:data.file}} ></div>\n      </div>\n    );\n  },\n  onclick: function(e) {\n  \n    var target = e.target;\n    if ( target.tagName == \"A\" ) {\n    \n      var index = target.getAttribute(\"data-index\");\n      var handler = this.props.customHandler;\n      if (handler) {\n      \thandler({\n        \tdata: index\n        })\n      }\n    \n    }\n  \n  }\n\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data)\n\n    return React.createElement(\n      \"div\",\n      { onClick: this.onclick, className: \"w_jxsq_fjxxTips\" },\n      React.createElement(\"div\", { dangerouslySetInnerHTML: { __html: data.tips } }),\n      React.createElement(\"div\", { dangerouslySetInnerHTML: { __html: data.file } })\n    );\n  },\n  onclick: function onclick(e) {\n\n    var target = e.target;\n    if (target.tagName == \"A\") {\n\n      var index = target.getAttribute(\"data-index\");\n      var handler = this.props.customHandler;\n      if (handler) {\n        handler({\n          data: index\n        });\n      }\n    }\n  }\n\n});\n\nexports.default = Data;";
    },
    getData_control27: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl21: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl21: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);