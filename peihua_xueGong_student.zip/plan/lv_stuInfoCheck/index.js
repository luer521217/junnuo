(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control5: function (elem) {
      if (elem) {
        var ta = elem.cloneNode(true);
        var ip = ta.querySelectorAll("input");

        if (ip.length == 2) {
          ip[0].className = "xg_two_btn";
          ip[1].className = "xg_two_btn1";
        } else if (ip.length == 1) {
          ip[0].className = "xg_one_btn";
        }

        ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
        return ta.innerHTML;
      }
    },
    doAction_uiControl7: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control6: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl9: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl9: function () {
      var selfTemplate = "\n\nvar Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\n\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control7: function (elem) {
      if (elem && elem.getElementsByTagName("tr")) {
        var inTr = elem.getElementsByTagName("tr"),
            trLen = inTr.length,
            oDiv = [];
        var i;

        for (i = 0; i < trLen; i++) {
          inTd = inTr[i].getElementsByTagName("td");
          tdLen = inTd.length;

          if (tdLen > 0) {
            inSpan = inTd[0].getElementsByTagName("input")[0];

            if (inSpan == undefined) {
              oDiv.push({
                error: inTd[0].innerText
              });
            } else {
              oDiv.push({
                selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
                s_id: inTd[2].innerText,
                name: inTd[3].innerText,
                college: inTd[4].innerText,
                sex: inTd[5].innerText,
                Movetype: inTd[6].innerText,
                Checkout: inTd[7].innerText,
                Inbed: inTd[13].innerText
              });
            }
          }
        }

        return oDiv;
      }
    },
    doAction_uiControl10: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var aLi = elem.getElementsByTagName("a")[index];
      var aip = elem.getElementsByTagName("tr")[index];

      if (type == "input") {
        aip.dispatchEvent(new Event("click"));
      } else {
        aLi.dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl10: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else if(data[0].name){\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>\u5B66\u53F7\uFF1A</b>\n                <a>{item.s_id}</a></span>\n              <font>\n                <b>\u59D3\u540D\uFF1A</b>\n                {item.name}</font>\n              <font>\n                <b>\u6027\u522B\uFF1A</b>\n                {item.college}</font>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.sex}</span> \n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.Movetype}</span>\n              <span>\n                <b>\u7533\u8BF7\u65F6\u95F4\uFF1A</b>\n                {item.Checkout}</span>\n              <span>\n                <b>\u5BA1\u6838\u72B6\u6001\uFF1A</b>\n                {item.Inbed}</span>\n               </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>\u5B66\u53F7\uFF1A</b>\n                <a>{item.s_id}</a></span>\n              <font>\n                <b>\u59D3\u540D\uFF1A</b>\n                {item.name}</font>\n              <font>\n                <b>\u6027\u522B\uFF1A</b>\n                {item.college}</font>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.sex}</span> \n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.Movetype}</span>\n              <span>\n                <b>\u7533\u8BF7\u65F6\u95F4\uFF1A</b>\n                {item.Checkout}</span>\n              <span>\n                <b>\u5BA1\u6838\u72B6\u6001\uFF1A</b>\n                {item.Inbed}</span>\n               </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else if (data[0].name) {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u53F7\\uFF1A\"\n                ),\n                React.createElement(\n                  \"a\",\n                  null,\n                  item.s_id\n                )\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u59D3\\u540D\\uFF1A\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u6027\\u522B\\uFF1A\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.sex\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.Movetype\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u65F6\\u95F4\\uFF1A\"\n                ),\n                item.Checkout\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5BA1\\u6838\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.Inbed\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u53F7\\uFF1A\"\n                ),\n                React.createElement(\n                  \"a\",\n                  null,\n                  item.s_id\n                )\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u59D3\\u540D\\uFF1A\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u6027\\u522B\\uFF1A\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.sex\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.Movetype\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u65F6\\u95F4\\uFF1A\"\n                ),\n                item.Checkout\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5BA1\\u6838\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.Inbed\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control11: function (elem) {
      var WholeHtml = elem.cloneNode(true);
      var a = WholeHtml.getElementsByTagName("a");

      for (var i = 0; i < a.length; i++) {
        a[i].removeAttribute("onclick");
      }

      return WholeHtml.innerHTML;
    },
    doAction_uiControl15: function (data, elem) {
      var myId = data.dataCustom;
      var inLi = elem.getElementsByTagName("li"),
          i;

      for (i = 0; i < inLi.length; i++) {
        var inId = inLi[i].innerText;

        if (myId == inId) {
          inLi[i].getElementsByTagName("a")[0].dispatchEvent(new Event("click"));
        }

        ;
      }
    },
    getTemplate_uiControl15: function () {
      var selfTemplate = "\nconst Data = React.createClass({\n  render: function render() {\n  \n    var data = this.props.data.customData;\n  \treturn <div className=\"xg_nav lv_tab_two\" onClick={this.onclick} dangerouslySetInnerHTML={{__html: data}}></div>; \n    \n  },\n  onclick: function onclick(e){\n    var target = findLi(e.target)\n    var tarId = target.innerText;\n    function findLi (et) {\n    \tif ( et.tagName == \"SPAN\" ) {\n      \treturn findLi(et.parentNode);\n      }else if ( et.tagName == \"A\" ) {\n      \treturn findLi(et.parentNode);\n      }else if ( et.tagName == \"LI\" ){\n      \treturn et;\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n    \t handler({\n         data : tarId\n       })\n    }\n\t}\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"xg_nav lv_tab_two\", onClick: this.onclick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onclick: function onclick(e) {\n    var target = findLi(e.target);\n    var tarId = target.innerText;\n    function findLi(et) {\n      if (et.tagName == \"SPAN\") {\n        return findLi(et.parentNode);\n      } else if (et.tagName == \"A\") {\n        return findLi(et.parentNode);\n      } else if (et.tagName == \"LI\") {\n        return et;\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: tarId\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control12: function (elem) {
      if (elem && elem.querySelectorAll("span")) {
        var aSpan = elem.querySelectorAll("span");
        var aInput = elem.querySelectorAll("input");
        var oPage = {
          "currentPage": aInput[0].value,
          "totalPage": aSpan[0].textContent,
          "totalRecords": aSpan[1].textContent
        };
        return oPage;
      }
    },
    doAction_uiControl16: function (data, elem) {},
    getTemplate_uiControl16: function () {
      var selfTemplate = "const MyPage = React.createClass({\nrender: function() {\n  \tvar data = this.props.data.customData;\n  if(data==\"\"){\n    return (<div></div>);\n  }else{\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data == \"\") {\n      return React.createElement(\"div\", null);\n    } else {\n      return React.createElement(\n        \"div\",\n        { className: \"pagenation\" },\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u7B2C\",\n          data.currentPage,\n          \"\\u9875/\\u5171\",\n          React.createElement(\n            \"p\",\n            { className: \"red\" },\n            data.totalPage\n          ),\n          \"\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u603B\\u5171\",\n          React.createElement(\n            \"p\",\n            { className: \"red\" },\n            data.totalRecords\n          ),\n          \"\\u6761\\u8BB0\\u5F55\"\n        )\n      );\n    }\n  }\n});\nexports.default = MyPage;";
    },
    getData_control22: function (elem) {
      if (elem) {
        var ta = elem.cloneNode(true);
        var ip = ta.querySelectorAll("input");

        if (ip.length == 2) {
          ip[0].className = "xg_two_btn";
          ip[1].className = "xg_two_btn1";
        } else if (ip.length == 1) {
          ip[0].className = "xg_one_btn";
        }

        ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
        return ta.innerHTML;
      }
    },
    doAction_uiControl25: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl25: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);