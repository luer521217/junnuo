(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control774: function (elem) {
      var map = Array.prototype.map;
      var content = map.call($(elem).find('tr'), function (tr) {
        return map.call($(tr).find('td'), function (td) {
          return td.textContent;
        });
      });
      return content;
    },
    doAction_uiControl877: function (data, elem) {
      elem.querySelectorAll('a')[data.dataCustom - 1].click();
    },
    getTemplate_uiControl877: function () {
      var selfTemplate = '\nvar React = require(\'react\');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    var items = data.map(function(item, idx){\n      return <li><a data-idx={idx}>{item[0]}</a><span>{item[1]}</span></li>\n    })\n    return <ul onClick={this.onClick}>{items}</ul>\n  },\n  \n  onClick: function(e){\n  \tvar target = e.target;\n    var tag = target.tagName;\n    var idx;\n    if(tag === "A"){\n    \tidx = target.getAttribute("data-idx");\n    }\n    console.log(tag, idx);\n    var handler = this.props.customHandler;\n    if(handler){\n\xA0\xA0\xA0\xA0\thandler({\n\xA0\xA0\xA0\xA0\xA0\xA0 \tdata:\xA0idx\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n  }\n});\n';
      return '"use strict";\n\nvar React = require(\'react\');\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, idx) {\n      return React.createElement(\n        "li",\n        null,\n        React.createElement(\n          "a",\n          { "data-idx": idx },\n          item[0]\n        ),\n        React.createElement(\n          "span",\n          null,\n          item[1]\n        )\n      );\n    });\n    return React.createElement(\n      "ul",\n      { onClick: this.onClick },\n      items\n    );\n  },\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    var tag = target.tagName;\n    var idx;\n    if (tag === "A") {\n      idx = target.getAttribute("data-idx");\n    }\n    console.log(tag, idx);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: idx\n      });\n    }\n  }\n});';
    },
    getData_control775: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl862: function (data, elem) {},
    getTemplate_uiControl862: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control786: function (elem) {},
    doAction_uiControl892: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl892: function () {
      var selfTemplate = 'const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className="xg_back">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;';
      return '"use strict";\n\nObject.defineProperty(exports, "__esModule", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: "MyBack",\n\n  render: function render() {\n    return React.createElement(\n      "button",\n      { onClick: this.onClick, className: "xg_back" },\n      "\\u8FD4\\u56DE"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;';
    }
  });
})(window, ysp);