(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control43: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl57: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl57: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control47: function (elem) {
      var section = elem.querySelectorAll("dd");
      var list = [];

      for (let i = 0; i < section.length; i++) {
        list.push(section[i].innerText);
      }

      return list;
    },
    doAction_uiControl62: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelectorAll("dd");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].querySelector("a").click();
        }
      }
    },
    getTemplate_uiControl62: function () {
      var selfTemplate = "\nvar Condition = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <span>{item}</span>\n    });\n\t\treturn <section onClick={this.handleClick}>\n      <label>\u5DF2\u9009\u6761\u4EF6\uFF1A</label>\n      {items}\n    </section>\n  },\n  handleClick: function(event){\n  \tvar text = event.target.innerText;\n    console.log(text);\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n})\nexport default Condition;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Condition = React.createClass({\n  displayName: \"Condition\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      { onClick: this.handleClick },\n      React.createElement(\n        \"label\",\n        null,\n        \"\\u5DF2\\u9009\\u6761\\u4EF6\\uFF1A\"\n      ),\n      items\n    );\n  },\n  handleClick: function handleClick(event) {\n    var text = event.target.innerText;\n    console.log(text);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Condition;";
    },
    getData_control48: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = function () {
        var trs = elem.querySelectorAll("tr");

        for (var i = 0; i < trs.length; i++) {
          if (trs[i].querySelector("td").innerHTML == "&nbsp;") {
            return i;
          }
        }

        return trs.length;
      }(),
          oDiv = [];

      var i;

      for (i = 1; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: inTd[0].innerText
          });
        } else {
          oDiv.push({
            selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
            id: inTd[1].innerText,
            name: inTd[2].innerText,
            gender: inTd[3].innerText,
            where: inTd[4].innerText,
            date: inTd[5].innerText,
            class: inTd[6].innerText,
            result: inTd[7].innerText,
            status: inTd[8].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl64: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var row = elem.querySelector("tbody").getElementsByTagName("tr")[index];
      var inp = elem.querySelector("tbody").getElementsByTagName("input")[index];

      if (type == "input") {
        inp.click();
      } else {
        row.ondblclick();
      }
    },
    getTemplate_uiControl64: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n       return(\n        <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\"/> </div>\n  <div className=\"lv_dbsy_rest\">\n              <span>\n            <b>\u5B66\u53F7\uFF1A</b>\n              {item.id}</span>\n            <font>\n              <b>\u59D3\u540D\uFF1A</b>\n              {item.name}</font>\n            <font>\n              <b>\u6027\u522B\uFF1A</b>\n              {item.gender}</font>\n            <span>\n              <b>\u4F4F\u5BBF\u5BDD\u5BA4\uFF1A</b>\n              {item.where}</span> \n            <span>\n              <b>\u8FDD\u7EAA\u65F6\u95F4\uFF1A</b>\n              {item.date}</span>\n            <span>\n              <b>\u7EAA\u5F8B\u7C7B\u522B\uFF1A</b>\n              {item.class}</span>\n            <span>\n              <b>\u5904\u7406\u7ED3\u679C\uFF1A</b>\n              {item.result}</span>\n            <span>\n              <b>\u5BA1\u6838\u72B6\u6001\uFF1A</b>\n              {item.status}</span>\n             </div>\n          </li>\n        ); \n      })\n    return <ul className=\"lv_dbsy_ul\" onClick={this.onClick}>{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        return React.createElement(\n          \"li\",\n          { \"data-index\": index, className: \"lv_dbsy_li\" },\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_ip\" },\n            \" \",\n            React.createElement(\"input\", { type: \"checkbox\" }),\n            \" \"\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_rest\" },\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5B66\\u53F7\\uFF1A\"\n              ),\n              item.id\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u59D3\\u540D\\uFF1A\"\n              ),\n              item.name\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u6027\\u522B\\uFF1A\"\n              ),\n              item.gender\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u4F4F\\u5BBF\\u5BDD\\u5BA4\\uFF1A\"\n              ),\n              item.where\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u8FDD\\u7EAA\\u65F6\\u95F4\\uFF1A\"\n              ),\n              item.date\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u7EAA\\u5F8B\\u7C7B\\u522B\\uFF1A\"\n              ),\n              item.class\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5904\\u7406\\u7ED3\\u679C\\uFF1A\"\n              ),\n              item.result\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5BA1\\u6838\\u72B6\\u6001\\uFF1A\"\n              ),\n              item.status\n            )\n          )\n        );\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control49: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl66: function (data, elem) {},
    getTemplate_uiControl66: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control73: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl95: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl95: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);