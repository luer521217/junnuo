(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control264: function (elem) {
      var target1 = elem.querySelector("textarea");
      target1.placeholder = "限制在500字内";
      target1.parentNode.parentNode.classList.add("textarea-wrap");
      var target2 = elem.querySelector("select");
      target2.parentNode.parentNode.classList.add("select-wrap");
      return elem.outerHTML.replace(/width/ig, "data-width");
    },
    doAction_uiControl304: function (data, elem) {
      var value = data.dataCustom.value;
      var type = data.dataCustom.type;

      if (type === "SELECT") {
        elem.querySelector("select").value = value;
      } else if (type === "TEXTAREA") {
        elem.querySelector("textarea").value = value;
      }
    },
    getTemplate_uiControl304: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table className=\"y_info y_info2\" dangerouslySetInnerHTML={{__html:\xA0data}} onBlur={this.onClick}></table>\n    )\n  },\n  onClick: function(e){\n    console.log(\"in\");\n  \tvar target = e.target;\n    var tar = target.tagName,\n        val;\n    if(tar === \"SELECT\"){\n      val = target.value;\n    } else if (tar === \"TEXTAREA\"){\n    \tval = target.value;\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n        \tvalue: val,\n          type: tar\n        }\n      })\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"y_info y_info2\", dangerouslySetInnerHTML: { __html: data }, onBlur: this.onClick });\n  },\n  onClick: function onClick(e) {\n    console.log(\"in\");\n    var target = e.target;\n    var tar = target.tagName,\n        val;\n    if (tar === \"SELECT\") {\n      val = target.value;\n    } else if (tar === \"TEXTAREA\") {\n      val = target.value;\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          value: val,\n          type: tar\n        }\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);