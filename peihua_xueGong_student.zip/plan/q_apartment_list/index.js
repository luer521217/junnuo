(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl5: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl5: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control5: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 1; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: inTd[0].innerText
          });
        } else {
          oDiv.push({
            selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
            id: inTd[1].innerText,
            name: inTd[2].innerText,
            grade: inTd[3].innerText,
            college: inTd[4].innerText,
            class: inTd[5].innerText,
            gender: inTd[6].innerText,
            apart: inTd[7].innerText,
            rome: inTd[8].innerText,
            bed: inTd[9].innerText,
            teacher: inTd[10].innerText,
            boss: inTd[11].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl10: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var aLi = elem.querySelectorAll("tbody a")[index];
      var aip = elem.querySelectorAll("tbody input")[index];

      if (type == "input") {
        aip.click();
      } else {
        aLi.click();
      }
    },
    getTemplate_uiControl10: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n       return(\n        <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" /> </div>\n<div className=\"lv_dbsy_rest\"><span>\n                <b>学号：</b>\n                {item.id}</span>\n              <font>\n                <b>姓名：</b>\n                {item.name}</font>\n              <font>\n                <b>年级：</b>\n                {item.grade}</font>\n              <span>\n                <b>学院：</b>\n                {item.college}</span> \n              <span>\n                <b>班级：</b>\n                {item.class}</span>\n              <span>\n                <b>性别：</b>\n                {item.gender}</span>\n              <span>\n                <b>楼栋名称：</b>\n                {item.apart}</span>\n                              <span>\n                <b>寝室号：</b>\n                {item.rome}</span>\n                              <span>\n                <b>床位号：</b>\n                {item.bed}</span>\n                              <span>\n                <b>辅导员：</b>\n                {item.teacher}</span>\n                              <span>\n                <b>班主任：</b>\n                {item.boss}</span>\n               </div>\n          </li>\n\n\n        ); \n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        return React.createElement(\n          \"li\",\n          { \"data-index\": index, className: \"lv_dbsy_li\" },\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_ip\" },\n            \" \",\n            React.createElement(\"input\", { type: \"checkbox\" }),\n            \" \"\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_rest\" },\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"学号：\"\n              ),\n              item.id\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"姓名：\"\n              ),\n              item.name\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"年级：\"\n              ),\n              item.grade\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"学院：\"\n              ),\n              item.college\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"班级：\"\n              ),\n              item.class\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"性别：\"\n              ),\n              item.gender\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"楼栋名称：\"\n              ),\n              item.apart\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"寝室号：\"\n              ),\n              item.rome\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"床位号：\"\n              ),\n              item.bed\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"辅导员：\"\n              ),\n              item.teacher\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"班主任：\"\n              ),\n              item.boss\n            )\n          )\n        );\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control6: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl12: function (data, elem) {},
    getTemplate_uiControl12: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control14: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl3: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl3: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control270: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl307: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl307: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);