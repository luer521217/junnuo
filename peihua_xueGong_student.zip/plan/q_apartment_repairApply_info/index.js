(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control280: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl370: function (data, elem) {},
    getTemplate_uiControl370: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table \xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info\">\n      </table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info\" });\n  }\n});";
    },
    getData_control281: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl371: function (data, elem) {},
    getTemplate_uiControl371: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table \xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info clxx\">\n      </table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info clxx\" });\n  }\n});";
    },
    getData_control282: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl372: function (data, elem) {},
    getTemplate_uiControl372: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table \xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info\">\n      </table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info\" });\n  }\n});";
    },
    getData_control283: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl373: function (data, elem) {},
    getTemplate_uiControl373: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table \xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info fwpj\">\n      </table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info fwpj\" });\n  }\n});";
    }
  });
})(window, ysp);