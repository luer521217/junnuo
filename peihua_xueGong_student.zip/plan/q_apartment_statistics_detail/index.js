(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control5: function (elem) {
      return elem.innerHTML;
    },
    doAction_uiControl15: function (data, elem) {},
    getTemplate_uiControl15: function () {
      var selfTemplate = "var Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    return <div className=\"popup-detail y_table_aa\"><table dangerouslySetInnerHTML={{__html: data}}></table></div>\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"popup-detail y_table_aa\" },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  }\n});\nexports.default = Data;";
    },
    getData_control2: function (elem) {
      var xx = elem.querySelectorAll("a");

      for (let i = 0; i < xx.length; i++) {
        xx[i].setAttribute("data-index", i);
      }

      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl11: function (data, elem) {
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].click();
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "const TaskList1 = React.createClass({\n  render: function () {\n    var data = this.props.data.customData;    \n    return <table className=\"table-show1\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;\n  },\n  onClick: function(e){\n    var target = e.target;\n    if(target.tagName == \"FONT\"){\n      var index = target.parentNode.getAttribute(\"data-index\");\n    }\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        data: index\n      })\n    }\n  }\n});\nexport default TaskList1;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList1 = React.createClass({\n  displayName: \"TaskList1\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"table-show1\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"FONT\") {\n      var index = target.parentNode.getAttribute(\"data-index\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = TaskList1;";
    },
    getData_control3: function (elem) {
      var xx = elem.querySelectorAll("a");

      for (let i = 0; i < xx.length; i++) {
        xx[i].setAttribute("data-index", i);
      }

      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl13: function (data, elem) {
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].click();
    },
    getTemplate_uiControl13: function () {
      var selfTemplate = "const TaskList2 = React.createClass({\n  render: function () {\n    var data = this.props.data.customData;    \n    return <table className=\"table-show2\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;\n  },\n  onClick: function(e){\n    var target = e.target;\n    if(target.tagName == \"FONT\"){\n      var index = target.parentNode.getAttribute(\"data-index\");\n    }\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        data: index\n      })\n    }\n  }\n});\nexport default TaskList2;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList2 = React.createClass({\n  displayName: \"TaskList2\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"table-show2\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"FONT\") {\n      var index = target.parentNode.getAttribute(\"data-index\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = TaskList2;";
    }
  });
})(window, ysp);