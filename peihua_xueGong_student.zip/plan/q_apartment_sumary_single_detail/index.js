(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {
      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl2: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelectorAll("input");

      for (let i = 0; i < event.length; i++) {
        if (event[i].value == index) {
          event[i].click();
        }
      }
    },
    getTemplate_uiControl2: function () {
      var selfTemplate = "const\xA0TaskList\xA0=\xA0React.createClass({\n\xA0\xA0render:\xA0function\xA0()\xA0{\n\xA0\xA0\xA0\xA0 var\xA0data\xA0=\xA0this.props.data.customData;\n\xA0\xA0\xA0\xA0 return\xA0<table onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}}></table>;\xA0\xA0\n\xA0\xA0\xA0\xA0\xA0\xA0},\n\xA0\xA0onClick:\xA0function(e){\n\xA0\xA0 var\xA0target\xA0=\xA0e.target;\n\xA0\xA0\xA0\xA0if(target.tagName\xA0==\xA0\"INPUT\"){\n\xA0\xA0\xA0\xA0 var\xA0index\xA0=\xA0target.value;\n      target.parentNode.parentNode.classList.toggle(\"current\");\n\xA0\xA0\xA0\xA0}\n\xA0\xA0\xA0\xA0var\xA0handler\xA0=\xA0this.props.customHandler;\nif(handler){\n\xA0\xA0\xA0\xA0 handler({\n\xA0\xA0\xA0\xA0\xA0\xA0 data:\xA0index\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n\xA0\xA0}\n\xA0\xA0});\nexport\xA0default\xA0TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n      value: true\n});\nvar TaskList = React.createClass({\n      displayName: \"TaskList\",\n\n      render: function render() {\n            var data = this.props.data.customData;\n            return React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n      },\n      onClick: function onClick(e) {\n            var target = e.target;\n            if (target.tagName == \"INPUT\") {\n                  var index = target.value;\n                  target.parentNode.parentNode.classList.toggle(\"current\");\n            }\n            var handler = this.props.customHandler;\n            if (handler) {\n                  handler({\n                        data: index\n                  });\n            }\n      }\n});\nexports.default = TaskList;";
    },
    getData_control1: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl4: function (data, elem) {},
    getTemplate_uiControl4: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control7: function (elem) {},
    doAction_uiControl10: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl10: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">返回</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);