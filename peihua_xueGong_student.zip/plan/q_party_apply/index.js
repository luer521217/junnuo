(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control2: function (elem) {
      return elem.querySelector("#xh").value;
    },
    doAction_uiControl34: function (data, elem) {},
    getTemplate_uiControl34: function () {
      var selfTemplate = "var Input = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    return <span className=\"party-xh-bd\">{data}</span>\n  }\n})\nexport default Input;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Input = React.createClass({\n  displayName: \"Input\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"span\",\n      { className: \"party-xh-bd\" },\n      data\n    );\n  }\n});\nexports.default = Input;";
    },
    getData_control12: function (elem) {
      var list = [];
      var counts = elem.querySelectorAll("th").length;

      for (let i = 0; i < counts; i++) {
        list.push({
          th: elem.querySelectorAll("th")[i].innerText,
          td: elem.querySelectorAll("td")[i].innerText
        });
      }

      return list;
    },
    doAction_uiControl46: function (data, elem) {},
    getTemplate_uiControl46: function () {
      var selfTemplate = "var Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item, index){\n    \treturn (\n      \t<section>\n          <span className=\"th\">{item.th}：</span>\n          <span className=\"td\">{item.td}</span>\n        </section>\n      )\n    })\n    return <div>{items}</div>\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n      return React.createElement(\n        \"section\",\n        null,\n        React.createElement(\n          \"span\",\n          { className: \"th\" },\n          item.th,\n          \"：\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"td\" },\n          item.td\n        )\n      );\n    });\n    return React.createElement(\n      \"div\",\n      null,\n      items\n    );\n  }\n});\nexports.default = Data;";
    }
  });
})(window, ysp);