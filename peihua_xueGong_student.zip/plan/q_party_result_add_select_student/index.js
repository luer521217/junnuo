(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control297: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl387: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl387: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control301: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td");
        oDiv.push({
          id: inTd[0].innerText,
          name: inTd[1].innerText,
          gender: inTd[2].innerText,
          college: inTd[3].innerText,
          skill: inTd[4].innerText,
          class: inTd[5].innerText,
          btn: inTd[6].innerHTML.replace(/onclick/ig, "data-oldEvent")
        });
      }

      return oDiv;
    },
    doAction_uiControl392: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelectorAll("label");

      for (let i = 0; i < event.length; i++) {
        if (event[i].getAttribute("onclick") == index) {
          event[i].click();
        }
      }
    },
    getTemplate_uiControl392: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=e.target;\n    if(target.tagName == \"LABEL\"){\n    \tvar index = target.getAttribute(\"data-oldEvent\");\n    }\n    var\xA0handler\xA0=\xA0this.props.customHandler;\n    if(handler){\n\xA0\xA0\xA0\xA0 handler({\n\xA0\xA0\xA0\xA0\xA0\xA0 data:\xA0index\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>\u5B66\u53F7\uFF1A</b>\n                {item.id}</span>\n              <font>\n                <b>\u59D3\u540D\uFF1A</b>\n                {item.name}</font>\n              <font>\n                <b>\u6027\u522B\uFF1A</b>\n                {item.gender}</font>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.college}</span> \n              <span>\n                <b>\u4E13\u4E1A\uFF1A</b>\n                {item.skill}</span>\n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.class}</span>\n              \n                <span className=\"select-btn\"><b>\u64CD\u4F5C\uFF1A</b>\n                <section dangerouslySetInnerHTML={{__html:\xA0item.btn}}></section></span>\n               </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>\u5B66\u53F7\uFF1A</b>\n                {item.id}</span>\n              <font>\n                <b>\u59D3\u540D\uFF1A</b>\n                {item.name}</font>\n              <font>\n                <b>\u6027\u522B\uFF1A</b>\n                {item.gender}</font>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.college}</span> \n              <span>\n                <b>\u4E13\u4E1A\uFF1A</b>\n                {item.skill}</span>\n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.class}</span>\n              \n                <span className=\"select-btn\"><b>\u64CD\u4F5C\uFF1A</b>\n                <section dangerouslySetInnerHTML={{__html:\xA0item.btn}}></section></span>\n               </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\" onClick={this.onClick}>{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"LABEL\") {\n      var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u53F7\\uFF1A\"\n                ),\n                item.id\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u59D3\\u540D\\uFF1A\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u6027\\u522B\\uFF1A\"\n                ),\n                item.gender\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u4E13\\u4E1A\\uFF1A\"\n                ),\n                item.skill\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.class\n              ),\n              React.createElement(\n                \"span\",\n                { className: \"select-btn\" },\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u64CD\\u4F5C\\uFF1A\"\n                ),\n                React.createElement(\"section\", { dangerouslySetInnerHTML: { __html: item.btn } })\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u53F7\\uFF1A\"\n                ),\n                item.id\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u59D3\\u540D\\uFF1A\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u6027\\u522B\\uFF1A\"\n                ),\n                item.gender\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u4E13\\u4E1A\\uFF1A\"\n                ),\n                item.skill\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.class\n              ),\n              React.createElement(\n                \"span\",\n                { className: \"select-btn\" },\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u64CD\\u4F5C\\uFF1A\"\n                ),\n                React.createElement(\"section\", { dangerouslySetInnerHTML: { __html: item.btn } })\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control302: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].textContent,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl394: function (data, elem) {},
    getTemplate_uiControl394: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control307: function (elem) {},
    doAction_uiControl400: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl400: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);