(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1: function (elem) {
      var odiv = elem.cloneNode(true);
      var aa = odiv.getElementsByTagName("a"),
          i = 0;

      for (; i < aa.length; i++) {
        aa[i].removeAttribute("onclick");
      }

      return odiv.innerHTML;
    },
    doAction_uiControl4: function (data, elem) {
      var myId = data.dataCustom;
      var inLi = elem.getElementsByTagName("li"),
          i;

      for (i = 0; i < inLi.length; i++) {
        var inId = inLi[i].innerText;

        if (myId == inId) {
          inLi[i].getElementsByTagName("a")[0].dispatchEvent(new Event("click"));
        }

        ;
      }
    },
    getTemplate_uiControl4: function () {
      var selfTemplate = "\nconst Data = React.createClass({\n  render: function render() {\n  \n    var data = this.props.data.customData;\n    //console.log(data)\n  \treturn <div onClick={this.onclick} dangerouslySetInnerHTML={{__html: data}}></div>; \n    \n  },\n  onclick: function onclick(e){\n    var target = findLi(e.target)\n\t\t//console.log(target)\n    var tarId = target.innerText;\n    //console.log(tarId+\" 222\")\n    function findLi (et) {\n    \tif ( et.tagName == \"SPAN\" ) {\n      \treturn findLi(et.parentNode);\n      }else if ( et.tagName == \"A\" ) {\n      \treturn findLi(et.parentNode);\n      }else if ( et.tagName == \"LI\" ){\n      \treturn et;\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n    \t handler({\n         data : tarId\n       })\n    }\n\t}\n});\n\nexport default Data;\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    //console.log(data)\n    return React.createElement(\"div\", { onClick: this.onclick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onclick: function onclick(e) {\n    var target = findLi(e.target);\n    //console.log(target)\n    var tarId = target.innerText;\n    //console.log(tarId+\" 222\")\n    function findLi(et) {\n      if (et.tagName == \"SPAN\") {\n        return findLi(et.parentNode);\n      } else if (et.tagName == \"A\") {\n        return findLi(et.parentNode);\n      } else if (et.tagName == \"LI\") {\n        return et;\n      }\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: tarId\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control2: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: "未找到任何记录！"
          });
        } else {
          oDiv.push("");
        }
      }

      return oDiv;
    },
    doAction_uiControl5: function (data, elem) {},
    getTemplate_uiControl5: function () {
      var selfTemplate = "\nconst Data = React.createClass({ \n\n  render: function () { \n    var data = this.props.data.customData;\n    //console.log(data)\n\t\tif ( data[0].error == undefined ){\n    \t\tvar items = \"\";\n    }else{\n      \tvar items2 = data[0].error;\n    }\n    //console.log(items.innerHTML)\n    return <div className=\"w_jxsb_table\"  onClick={this.onclick}><h2>{items2}</h2>{items}</div>; \n  }\n\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data)\n    if (data[0].error == undefined) {\n      var items = \"\";\n    } else {\n      var items2 = data[0].error;\n    }\n    //console.log(items.innerHTML)\n    return React.createElement(\n      \"div\",\n      { className: \"w_jxsb_table\", onClick: this.onclick },\n      React.createElement(\n        \"h2\",\n        null,\n        items2\n      ),\n      items\n    );\n  }\n\n});\n\nexports.default = Data;";
    },
    getData_control6: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl9: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl9: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control8: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl11: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);