(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl2: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl2: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },

    getData_control11: function (elem) {
      if (elem) {
        var section = elem.querySelectorAll("dd");
        var list = [];

        for (let i = 0; i < section.length; i++) {
          list.push(section[i].innerText);
        }

        return list;
      }
    },
    doAction_uiControl17: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelectorAll("dd");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].querySelector("a").click();
        }
      }
    },
    getTemplate_uiControl17: function () {
      var selfTemplate = "\nvar Condition = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <span>{item}</span>\n    });\n\t\treturn <section onClick={this.handleClick}>\n      <label>已选条件：</label>\n      {items}\n    </section>\n  },\n  handleClick: function(event){\n  \tvar text = event.target.innerText;\n    //console.log(text);\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n})\nexport default Condition;\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Condition = React.createClass({\n  displayName: \"Condition\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      { onClick: this.handleClick },\n      React.createElement(\n        \"label\",\n        null,\n        \"\\u5DF2\\u9009\\u6761\\u4EF6\\uFF1A\"\n      ),\n      items\n    );\n  },\n  handleClick: function handleClick(event) {\n    var text = event.target.innerText;\n    //console.log(text);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Condition;";
    },
    getData_control12: function (elem) {
      if (elem) {
        var inTr = elem.getElementsByTagName("tr"),
            trLen = inTr.length,
            oDiv = [];
        var i;

        for (i = 0; i < trLen; i++) {
          inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("span")[0];

          if (inSpan == undefined) {
            oDiv.push({
              error: inTd[0].innerText
            });
          } else {
            oDiv.push({
              selectBoxId: inTd[0].getElementsByTagName("input")[0].getAttribute("id"),
              grade: inTd[1].innerText,
              college: inTd[2].innerText,
              major: inTd[3].innerText,
              class: inTd[4].innerText,
              stuSum: inTd[5].innerText
            });
          }
        }

        return oDiv;
      }
    },
    doAction_uiControl18: function (data, elem) {},
    getTemplate_uiControl18: function () {
      var selfTemplate = "\nconst Data = React.createClass({ \n\n  render: function () { \n    var data = this.props.data.customData;\n    //console.log(data)\n\t\tif ( data[0].error == undefined ){\n    \t\t var items = data.map(function(item, index){\n            if ( data[index].error == undefined ) {\n              return (\n                <div className=\"w_tableMain\" data-index={index}>\n                    <ul className=\"main1\">\n                      <li className=\"w_li\" data-index=\"0\" >\n                        <input type=\"checkbox\" name=\"checkname\" id={item.selectBoxId}/>\n                      </li>\n                      <li className=\"w_li\" data-index=\"1\" >\n                        <span>年级：</span>\n                        {item.grade}</li>\n                      <li className=\"w_li\" data-index=\"2\" >\n                        <span>学院：</span>\n                        {item.college}</li>\n                      <li className=\"w_li\" data-index=\"5\" >\n                        <span>专业：</span>\n                        {item.major}</li>\n                      <li className=\"w_li\" data-index=\"4\" >\n                        <span>班级：</span>\n                        {item.class}</li> \n                    </ul>\n                    <ul className=\"main2\">\n                      <li className=\"w_li\" data-index=\"3\" >\n                        <span>班级总人数：</span>\n                        {item.stuSum}</li>\n                    </ul>\n                </div>\n              )\n            }\n          });\n    }else{\n      \tvar items2 = data[0].error;\n    }\n    //console.log(items.innerHTML)\n    return <div className=\"w_jxsb_table\"  onClick={this.onclick}><h2>{items2}</h2>{items}</div>; \n  },\n  onclick: function (e) {\n  \n    var target = e.target;\n  \t//console.log(target)\n    \n    if ( target.tagName == \"INPUT\" ) {\n    \n      \tvar value = target.getAttribute(\"id\");\n    \n    }else if ( target.tagName == \"LI\" ) {\n    \n      \tvar ulIndex = target.parentNode.parentNode.getAttribute(\"data-index\");\n    \t\tvar liIndex = target.getAttribute(\"data-index\");\n    }\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      \thandler({\n          data: {\n              inputId: value,\n              trIndex: ulIndex,\n              tdIndex: liIndex\n          }\n        })\n    }\n  }\n\n}); \n\nexport default Data;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data)\n    if (data[0].error == undefined) {\n      var items = data.map(function (item, index) {\n        if (data[index].error == undefined) {\n          return React.createElement(\n            \"div\",\n            { className: \"w_tableMain\", \"data-index\": index },\n            React.createElement(\n              \"ul\",\n              { className: \"main1\" },\n              React.createElement(\n                \"li\",\n                { className: \"w_li\", \"data-index\": \"0\" },\n                React.createElement(\"input\", { type: \"checkbox\", name: \"checkname\", id: item.selectBoxId })\n              ),\n              React.createElement(\n                \"li\",\n                { className: \"w_li\", \"data-index\": \"1\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  \"\\u5E74\\u7EA7\\uFF1A\"\n                ),\n                item.grade\n              ),\n              React.createElement(\n                \"li\",\n                { className: \"w_li\", \"data-index\": \"2\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"li\",\n                { className: \"w_li\", \"data-index\": \"5\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  \"\\u4E13\\u4E1A\\uFF1A\"\n                ),\n                item.major\n              ),\n              React.createElement(\n                \"li\",\n                { className: \"w_li\", \"data-index\": \"4\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.class\n              )\n            ),\n            React.createElement(\n              \"ul\",\n              { className: \"main2\" },\n              React.createElement(\n                \"li\",\n                { className: \"w_li\", \"data-index\": \"3\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  \"\\u73ED\\u7EA7\\u603B\\u4EBA\\u6570\\uFF1A\"\n                ),\n                item.stuSum\n              )\n            )\n          );\n        }\n      });\n    } else {\n      var items2 = data[0].error;\n    }\n    //console.log(items.innerHTML)\n    return React.createElement(\n      \"div\",\n      { className: \"w_jxsb_table\", onClick: this.onclick },\n      React.createElement(\n        \"h2\",\n        null,\n        items2\n      ),\n      items\n    );\n  },\n  onclick: function onclick(e) {\n\n    var target = e.target;\n    //console.log(target)\n\n    if (target.tagName == \"INPUT\") {\n\n      var value = target.getAttribute(\"id\");\n    } else if (target.tagName == \"LI\") {\n\n      var ulIndex = target.parentNode.parentNode.getAttribute(\"data-index\");\n      var liIndex = target.getAttribute(\"data-index\");\n    }\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          inputId: value,\n          trIndex: ulIndex,\n          tdIndex: liIndex\n        }\n      });\n    }\n  }\n\n});\n\nexports.default = Data;";
    },
    getData_control13: function (elem) {
      if (elem) {
        var aSpan = elem.querySelectorAll("span");
        var aInput = elem.querySelectorAll("input");
        var oPage = {
          "currentPage": aInput[0].value,
          "totalPage": aSpan[0].innerText,
          "totalRecords": aSpan[1].textContent
        };
        return oPage;
      }
    },
    doAction_uiControl19: function (data, elem) {},
    getTemplate_uiControl19: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control19: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl27: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl27: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control20: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl11: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "\nvar Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control24: function (elem) {
      if (elem) {
        var ta = elem.cloneNode(true);
        var ip = ta.querySelectorAll("input");

        for (var i = 0; i < ip.length; i++) {
          ip[i].removeAttribute("onclick");
        }

        if (ip.length == 2) {
          ip[0].className = "xg_two_btn";
          ip[1].className = "xg_two_btn1";
        } else if (ip.length == 1) {
          ip[0].className = "xg_one_btn";
        }

        return ta.innerHTML;
      }
    },
    doAction_uiControl25: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl25: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);