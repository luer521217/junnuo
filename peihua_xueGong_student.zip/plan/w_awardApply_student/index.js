(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control104: function (elem) {
      var odiv = elem.cloneNode(true);
      var aa = odiv.getElementsByTagName("a"),
          i = 0;

      for (; i < aa.length; i++) {
        aa[i].removeAttribute("onclick");
      }

      return odiv.innerHTML;
    },
    doAction_uiControl187: function (data, elem) {
      var target = data.dataCustom;
      var text = elem.getElementsByTagName("span");

      for (i = 0; i < text.length; i++) {
        if (target == text[i].innerText) {
          text[i].click();
        }
      }
    },
    getTemplate_uiControl187: function () {
      var selfTemplate = "\nconst Data = React.createClass({\n  render: function render() {\n  \n    var data = this.props.data.customData;\n    //console.log(data)\n  \treturn <div onClick={this.onclick} dangerouslySetInnerHTML={{__html: data}}></div>; \n    \n  },\n  onclick: function onclick(e){\n    var tagLi = findLi(e.target);\n    function findLi(ele){\n    \tif(ele.tagName == \"LI\"){\n      \treturn ele;\n      } else {\n      \treturn findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav li\");\n    for(let i=0; i<all.length; i++){\n    \tall[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n    \t handler({\n         data : target\n       })\n    }\n\t}\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    //console.log(data)\n    return React.createElement(\"div\", { onClick: this.onclick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onclick: function onclick(e) {\n    var tagLi = findLi(e.target);\n    function findLi(ele) {\n      if (ele.tagName == \"LI\") {\n        return ele;\n      } else {\n        return findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav li\");\n    for (var i = 0; i < all.length; i++) {\n      all[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control105: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 1; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: inTd[0].innerText
          });
        } else {
          oDiv.push({
            selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
            mc: inTd[1].innerText,
            lb: inTd[2].innerText,
            je: inTd[3].innerText,
            xz: inTd[4].innerText,
            kg: inTd[5].innerText,
            sq: inTd[6].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl189: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var aLi = elem.querySelector("tbody").getElementsByTagName("a")[index];
      var aip = elem.querySelector("tbody").getElementsByTagName("tr")[index];

      if (type == "input") {
        aip.dispatchEvent(new Event("click"));
      } else {
        aLi.dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl189: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n<div className=\"lv_dbsy_rest\"><span>\n              <b>\u9879\u76EE\u540D\u79F0\uFF1A</b>\n              {item.mc}</span>\n            <font>\n              <b>\u9879\u76EE\u7C7B\u522B\uFF1A</b>\n              {item.lb}</font>\n            <font>\n              <b>\u91D1\u989D\uFF1A</b>\n              {item.je}</font>\n            <span>\n              <b>\u9650\u5236\u6761\u4EF6\uFF1A</b>\n              {item.xz}</span> \n            <span>\n              <b>\u5F00\u5173\u72B6\u6001\uFF1A</b>\n              {item.kg}</span>\n            <span>\n              <b>\u7533\u8BF7\u72B6\u6001\uFF1A</b>\n              {item.sq}</span>\n             </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n<div className=\"lv_dbsy_rest\"><span>\n              <b>\u9879\u76EE\u540D\u79F0\uFF1A</b>\n              {item.mc}</span>\n            <font>\n              <b>\u9879\u76EE\u7C7B\u522B\uFF1A</b>\n              {item.lb}</font>\n            <font>\n              <b>\u91D1\u989D\uFF1A</b>\n              {item.je}</font>\n            <span>\n              <b>\u9650\u5236\u6761\u4EF6\uFF1A</b>\n              {item.xz}</span> \n            <span>\n              <b>\u5F00\u5173\u72B6\u6001\uFF1A</b>\n              {item.kg}</span>\n            <span>\n              <b>\u7533\u8BF7\u72B6\u6001\uFF1A</b>\n              {item.sq}</span>\n             </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u9879\\u76EE\\u540D\\u79F0\\uFF1A\"\n                ),\n                item.mc\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u9879\\u76EE\\u7C7B\\u522B\\uFF1A\"\n                ),\n                item.lb\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u91D1\\u989D\\uFF1A\"\n                ),\n                item.je\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u9650\\u5236\\u6761\\u4EF6\\uFF1A\"\n                ),\n                item.xz\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5F00\\u5173\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.kg\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.sq\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u9879\\u76EE\\u540D\\u79F0\\uFF1A\"\n                ),\n                item.mc\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u9879\\u76EE\\u7C7B\\u522B\\uFF1A\"\n                ),\n                item.lb\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u91D1\\u989D\\uFF1A\"\n                ),\n                item.je\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u9650\\u5236\\u6761\\u4EF6\\uFF1A\"\n                ),\n                item.xz\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5F00\\u5173\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.kg\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.sq\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control106: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].textContent,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl191: function (data, elem) {},
    getTemplate_uiControl191: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },

    getData_control115: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl201: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl201: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control506: function (elem) {},
    doAction_uiControl529: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl529: function () {
      var selfTemplate = "const MyBack = React.createClass({\n\xA0 render: function() {\n\xA0 \xA0 return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n\xA0 },\n\xA0 onClick: function() {\n\xA0 \xA0 var handler = this.props.customHandler;\n\xA0 \xA0 handler({});\n\xA0 }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);