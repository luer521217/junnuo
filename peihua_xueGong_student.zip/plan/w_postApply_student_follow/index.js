(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control740: function (elem) {},
    doAction_uiControl836: function (data, elem) {
      elem.querySelector('.ui_close').click();
    },
    getTemplate_uiControl836: function () {
      var selfTemplate = "const MyBack = React.createClass({\n\xA0 render: function() {\n\xA0 \xA0 return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n\xA0 },\n\xA0 onClick: function() {\n\xA0 \xA0 var handler = this.props.customHandler;\n\xA0 \xA0 handler({});\n\xA0 }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);