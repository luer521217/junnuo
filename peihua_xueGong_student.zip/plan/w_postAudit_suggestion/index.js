(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control5: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl5: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl5: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control1: function (elem) {
      var wholeHtml = elem.cloneNode(true);
      var iTable = wholeHtml.querySelector("table"),
          iIpt = iTable.querySelectorAll("input");
      var oDiv = [];

      for (var i = 0; i < iIpt.length; i++) {
        oDiv.push({
          iIpt: iIpt[i].getAttribute("name"),
          iIptVal: iIpt[i].value
        });
      }

      return oDiv;
    },
    doAction_uiControl1: function (data, elem) {
      var myVal = data.dataCustom.val,
          myIndex = data.dataCustom.index;
      var iIpt = elem.querySelectorAll("input")[myIndex];
      iIpt.value = myVal;
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({\n  \n  onchange: function(e) {\n  \tvar target = e.target;\n    var val = target.value;\n    //console.log(val)\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n          data: {\n          \tval: val,\n            index: target.getAttribute(\"data-index\")\n          }\n      });   \n    }\n    \n  },\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    //console.log(data);\n    \n    var items = data.map(function(item,index){\n    \treturn(\n      \t<input type=\"text\" name={item.iIpt} data-index={index} value={item.iIptVal}/>\n      );\n    });\n    \n    return (\n    \t<div  onChange={this.onchange}>{items}</div>\n    );\n  }\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n\n  onchange: function onchange(e) {\n    var target = e.target;\n    var val = target.value;\n    //console.log(val)\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          val: val,\n          index: target.getAttribute(\"data-index\")\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data);\n\n    var items = data.map(function (item, index) {\n      return React.createElement(\"input\", { type: \"text\", name: item.iIpt, \"data-index\": index, value: item.iIptVal });\n    });\n\n    return React.createElement(\n      \"div\",\n      { onChange: this.onchange },\n      items\n    );\n  }\n});\n\nexports.default = Data;";
    }
  });
})(window, ysp);