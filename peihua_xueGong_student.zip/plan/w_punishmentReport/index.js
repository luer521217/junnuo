(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control5: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl11: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "\nvar Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control9: function (elem) {
      var section = elem.querySelectorAll("dd");
      var list = [];

      for (let i = 0; i < section.length; i++) {
        list.push(section[i].innerText);
      }

      return list;
    },
    doAction_uiControl15: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelectorAll("dd");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].querySelector("a").click();
        }
      }
    },
    getTemplate_uiControl15: function () {
      var selfTemplate = "\nvar Condition = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <span>{item}</span>\n    });\n\t\treturn <section onClick={this.handleClick}>\n      <label>已选条件：</label>\n      {items}\n    </section>\n  },\n  handleClick: function(event){\n  \tvar text = event.target.innerText;\n    //console.log(text);\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n})\nexport default Condition;\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Condition = React.createClass({\n  displayName: \"Condition\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      { onClick: this.handleClick },\n      React.createElement(\n        \"label\",\n        null,\n        \"已选条件：\"\n      ),\n      items\n    );\n  },\n  handleClick: function handleClick(event) {\n    var text = event.target.innerText;\n    //console.log(text);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Condition;";
    },
    getData_control11: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].innerText,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl17: function (data, elem) {},
    getTemplate_uiControl17: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control10: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: inTd[0].innerText
          });
        } else {
          oDiv.push({
            selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
            s_id: inTd[4].innerText,
            name: inTd[5].innerText,
            college: inTd[6].innerText,
            sex: inTd[7].innerText,
            Movetype: inTd[8].innerText,
            Checkout: inTd[9].innerText,
            Inbed: inTd[10].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl16: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var aLi = elem.getElementsByTagName("a")[index];
      var aip = elem.getElementsByTagName("tr")[index];

      if (type == "input") {
        aip.dispatchEvent(new Event("click"));
      } else {
        aLi.dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl16: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\">\n                \t<span>\n                <b>学号：</b>\n                {item.s_id}\n                </span>\n              <span>\n                <b>姓名：</b>\n                {item.name}\n              </span>\n              <span>\n                <b>学年：</b>\n                {item.college}\n              </span>\n              <font>\n                <b>学期：</b>\n                {item.sex}</font> \n              <font>\n                <b>处分类别：</b>\n                {item.Checkout}</font>\n              <span>\n                <b>处分原因：</b>\n                {item.Movetype}</span>\n              <span>\n                <b>审核状态：</b>\n                {item.Inbed}</span>\n               </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\">\n               \t<span>\n                <b>学号：</b>\n                {item.s_id}\n                </span>\n              <span>\n                <b>姓名：</b>\n                {item.name}\n              </span>\n              <span>\n                <b>学年：</b>\n                {item.college}\n              </span>\n              <font>\n                <b>学期：</b>\n                {item.sex}</font> \n              <font>\n                <b>处分类别：</b>\n                {item.Checkout}</font>\n              <span>\n                <b>处分原因：</b>\n                {item.Movetype}</span>\n              <span>\n                <b>审核状态：</b>\n                {item.Inbed}</span>\n               </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学号：\"\n                ),\n                item.s_id\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"姓名：\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学年：\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学期：\"\n                ),\n                item.sex\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"处分类别：\"\n                ),\n                item.Checkout\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"处分原因：\"\n                ),\n                item.Movetype\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"审核状态：\"\n                ),\n                item.Inbed\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学号：\"\n                ),\n                item.s_id\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"姓名：\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学年：\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学期：\"\n                ),\n                item.sex\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"处分类别：\"\n                ),\n                item.Checkout\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"处分原因：\"\n                ),\n                item.Movetype\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"审核状态：\"\n                ),\n                item.Inbed\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control17: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl23: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl23: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);