(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl2: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl2: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control2: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl8: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl8: function () {
      var selfTemplate = "\nvar Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control6: function (elem) {
      var section = elem.querySelectorAll("dd");
      var list = [];

      for (let i = 0; i < section.length; i++) {
        list.push(section[i].innerText);
      }

      return list;
    },
    doAction_uiControl12: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelectorAll("dd");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].querySelector("a").click();
        }
      }
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "\nvar Condition = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <span>{item}</span>\n    });\n\t\treturn <section onClick={this.handleClick}>\n      <label>已选条件：</label>\n      {items}\n    </section>\n  },\n  handleClick: function(event){\n  \tvar text = event.target.innerText;\n    //console.log(text);\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n})\nexport default Condition;\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Condition = React.createClass({\n  displayName: \"Condition\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      { onClick: this.handleClick },\n      React.createElement(\n        \"label\",\n        null,\n        \"已选条件：\"\n      ),\n      items\n    );\n  },\n  handleClick: function handleClick(event) {\n    var text = event.target.innerText;\n    //console.log(text);\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Condition;";
    },
    getData_control7: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: "未找到任何记录！"
          });
        } else {
          oDiv.push("");
        }
      }

      return oDiv;
    },
    doAction_uiControl13: function (data, elem) {},
    getTemplate_uiControl13: function () {
      var selfTemplate = "\nconst Data = React.createClass({ \n\n  render: function () { \n    var data = this.props.data.customData;\n    //console.log(data)\n\t\tif ( data[0].error == undefined ){\n    \t\tvar items = \"\";\n    }else{\n      \tvar items2 = data[0].error;\n    }\n    //console.log(items.innerHTML)\n    return <div className=\"w_jxsb_table\"  onClick={this.onclick}><h2>{items2}</h2>{items}</div>; \n  }\n\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data)\n    if (data[0].error == undefined) {\n      var items = \"\";\n    } else {\n      var items2 = data[0].error;\n    }\n    //console.log(items.innerHTML)\n    return React.createElement(\n      \"div\",\n      { className: \"w_jxsb_table\", onClick: this.onclick },\n      React.createElement(\n        \"h2\",\n        null,\n        items2\n      ),\n      items\n    );\n  }\n\n});\n\nexports.default = Data;";
    },
    getData_control8: function (elem) {
      var ap = elem.getElementsByTagName("p")[0];
      var aSpan = ap.querySelectorAll("span");
      var aInput = ap.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[1].innerText,
        "totalRecords": aSpan[2].textContent
      };
      return oPage;
    },
    doAction_uiControl14: function (data, elem) {},
    getTemplate_uiControl14: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control14: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl20: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl20: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);