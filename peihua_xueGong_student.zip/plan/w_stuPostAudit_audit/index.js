(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control67: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl123: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl123: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n    return (\n      <div  className=\"w_xsgwsh_table\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_table\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control71: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl127: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl127: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n     return (\n      <div  className=\"w_xsgwsh_table\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_table\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control73: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl129: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl129: function () {
      var selfTemplate = "\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n     return (\n      <div  className=\"w_xsgwsh_table\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_table\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control75: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl131: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl131: function () {
      var selfTemplate = "\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n     return (\n      <div  className=\"w_xsgwsh_tableLong\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_tableLong\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control85: function (elem) {
      if (elem) {
        var ta = elem.cloneNode(true);
        var ip = ta.querySelectorAll("input");

        for (var i = 0; i < ip.length; i++) {
          ip[i].removeAttribute("onclick");
        }

        if (ip.length == 2) {
          ip[0].className = "xg_two_btn";
          ip[1].className = "xg_two_btn1";
        } else if (ip.length == 1) {
          ip[0].className = "xg_one_btn";
        }

        return ta.innerHTML;
      }
    },
    doAction_uiControl143: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl143: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);