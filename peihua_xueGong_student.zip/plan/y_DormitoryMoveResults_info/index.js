(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control3: function (elem) {
      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl14: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelector("a");

      if (event.getAttribute("onclick") == index) {
        event.click();
      }
    },
    getTemplate_uiControl14: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  render: function () {\n      var data = this.props.data.customData;\n    \treturn <table className=\"y_info y_info2\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;\n      },\n  onClick: function(e){\n  \tvar target = e.target;\n    if(target.tagName == \"A\"){\n    var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: index\n      })\n    }\n  }\n  });\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"y_info y_info2\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"A\") {\n      var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control4: function (elem) {
      elem.querySelectorAll("img")[0].src = "http://42.247.16.108/xgxt/images/ssyd/to.gif";
      elem.querySelectorAll("img")[0].parentNode.parentNode.setAttribute("class", "y_bbb");
      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent").replace(/width/ig, "data-width").replace(/colspan/ig, "data-colspan");
    },
    doAction_uiControl15: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelector("a");

      if (event.getAttribute("onclick") == index) {
        event.click();
      }
    },
    getTemplate_uiControl15: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  render: function () {\n      var data = this.props.data.customData;\n    \treturn <table className=\"y_info y_info2\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;\n      },\n  onClick: function(e){\n  \tvar target = e.target;\n    if(target.tagName == \"A\"){\n    var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: index\n      })\n    }\n  }\n  });\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"y_info y_info2\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"A\") {\n      var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control9: function (elem) {
      elem.querySelectorAll("img")[0].src = "http://42.247.16.108/xgxt/images/ssyd/to.gif";
      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl37: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelector("a");

      if (event.getAttribute("onclick") == index) {
        event.click();
      }
    },
    getTemplate_uiControl37: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  render: function () {\n      var data = this.props.data.customData;\n    \treturn <table className=\"y_info y_info2\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;\n      },\n  onClick: function(e){\n  \tvar target = e.target;\n    if(target.tagName == \"A\"){\n    var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: index\n      })\n    }\n  }\n  });\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"y_info y_info2\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"A\") {\n      var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = TaskList;";
    }
  });
})(window, ysp);