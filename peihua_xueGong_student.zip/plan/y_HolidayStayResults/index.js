(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const MyBack = React.createClass({\n\xA0 render: function() {\n\xA0 \xA0 return <button onClick={this.onClick}  className=\"xg_back\">\u8FD4\u56DE</button>\n\n\xA0 },\n\xA0 onClick: function() {\n\xA0 \xA0 var handler = this.props.customHandler;\n\xA0 \xA0 handler({});\n\xA0 }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control8: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl12: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control12: function (elem) {
      var section = elem.querySelectorAll("dd");
      var list = [];

      for (let i = 0; i < section.length; i++) {
        list.push(section[i].innerText);
      }

      return list;
    },
    doAction_uiControl17: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelectorAll("dd");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].querySelector("a").click();
        }
      }
    },
    getTemplate_uiControl17: function () {
      var selfTemplate = "var Condition = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <span>{item}</span>\n    });\n\t\treturn <section onClick={this.handleClick}>\n      <label>已选条件：</label>\n      {items}\n    </section>\n  },\n  handleClick: function(event){\n  \tvar text = event.target.innerText;\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n})\nexport default Condition;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Condition = React.createClass({\n  displayName: \"Condition\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"span\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      { onClick: this.handleClick },\n      React.createElement(\n        \"label\",\n        null,\n        \"已选条件：\"\n      ),\n      items\n    );\n  },\n  handleClick: function handleClick(event) {\n    var text = event.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Condition;";
    },
    getData_control13: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

        if (inSpan == undefined) {
          oDiv.push({
            error: inTd[0].innerText
          });
        } else {
          oDiv.push({
            selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
            a: inTd[3].innerText,
            b: inTd[4].innerText,
            c: inTd[5].innerText,
            d: inTd[6].innerText,
            e: inTd[7].innerText,
            f: inTd[8].innerText,
            g: inTd[9].innerText,
            h: inTd[10].innerText,
            i: inTd[11].innerText,
            j: inTd[12].innerText,
            k: inTd[13].innerText,
            l: inTd[14].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl18: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var val = data.dataCustom.val;
      var aip = elem.getElementsByTagName("tr")[index];

      if (type == "input") {
        aip.dispatchEvent(new Event("click"));
      } else {
        aip.getElementsByTagName("a")[val].dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl18: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var val;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } else if(nName===\"A\"){\n    \tval=e.target.getAttribute(\"class\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index,\n            \"val\":val\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>学号：</b>\n                <a className=\"0\">{item.a}</a></span>\n              <font>\n                <b>姓名：</b>\n                {item.b}</font>\n              <font>\n                <b>性别：</b>\n                {item.c}</font>\n              <span>\n                <b>民族：</b>\n                {item.d}</span> \n              <span>\n                <b>班级：</b>\n                {item.e}</span>\n              <span>\n                <b>学年：</b>\n                {item.f}</span>\n              <span>\n                <b>学期：</b>\n                {item.g}</span>\n                <span>\n                <b>留校开始时间：</b>\n                {item.h}</span>\n              <span>\n                <b>留校截止时间：</b>\n                {item.i}</span>\n              <span>\n                <b>楼栋名称：</b>\n                {item.j}</span>\n              <span>\n                <b>寝室号：</b>\n                {item.k}</span>\n              <span>\n                <b>床位号：</b>\n                {item.l}</span>\n               </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>学号：</b>\n                <a className=\"0\">{item.a}</a></span>\n              <font>\n                <b>姓名：</b>\n                {item.b}</font>\n              <font>\n                <b>性别：</b>\n                {item.c}</font>\n              <span>\n                <b>民族：</b>\n                {item.d}</span> \n              <span>\n                <b>班级：</b>\n                {item.e}</span>\n              <span>\n                <b>学年：</b>\n                {item.f}</span>\n              <span>\n                <b>学期：</b>\n                {item.g}</span>\n                <span>\n                <b>留校开始时间：</b>\n                {item.h}</span>\n              <span>\n                <b>留校截止时间：</b>\n                {item.i}</span>\n              <span>\n                <b>楼栋名称：</b>\n                {item.j}</span>\n              <span>\n                <b>寝室号：</b>\n                {item.k}</span>\n              <span>\n                <b>床位号：</b>\n                {item.l}</span>\n               </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var val;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    } else if (nName === \"A\") {\n      val = e.target.getAttribute(\"class\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index,\n          \"val\": val\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学号：\"\n                ),\n                React.createElement(\n                  \"a\",\n                  { className: \"0\" },\n                  item.a\n                )\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"姓名：\"\n                ),\n                item.b\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"性别：\"\n                ),\n                item.c\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"民族：\"\n                ),\n                item.d\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"班级：\"\n                ),\n                item.e\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学年：\"\n                ),\n                item.f\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学期：\"\n                ),\n                item.g\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"留校开始时间：\"\n                ),\n                item.h\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"留校截止时间：\"\n                ),\n                item.i\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"楼栋名称：\"\n                ),\n                item.j\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"寝室号：\"\n                ),\n                item.k\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"床位号：\"\n                ),\n                item.l\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学号：\"\n                ),\n                React.createElement(\n                  \"a\",\n                  { className: \"0\" },\n                  item.a\n                )\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"姓名：\"\n                ),\n                item.b\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"性别：\"\n                ),\n                item.c\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"民族：\"\n                ),\n                item.d\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"班级：\"\n                ),\n                item.e\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学年：\"\n                ),\n                item.f\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学期：\"\n                ),\n                item.g\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"留校开始时间：\"\n                ),\n                item.h\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"留校截止时间：\"\n                ),\n                item.i\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"楼栋名称：\"\n                ),\n                item.j\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"寝室号：\"\n                ),\n                item.k\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"床位号：\"\n                ),\n                item.l\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control14: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].textContent,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl19: function (data, elem) {},
    getTemplate_uiControl19: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control20: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl26: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl26: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control22: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl7: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control153: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl183: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl183: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);