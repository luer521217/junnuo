(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control364: function (elem) {
      for (var i = 0; i < elem.querySelectorAll("input").length; i++) {
        var val = elem.querySelectorAll("input")[i].value;
        elem.querySelectorAll("input")[i].setAttribute("data-input", i);
        elem.querySelectorAll("input")[i].setAttribute("value", val);
      }

      for (var j = 0; j < elem.querySelectorAll("select").length; j++) {
        if (elem.querySelectorAll("select")[j].selectedIndex) {
          var ind = elem.querySelectorAll("select")[j].selectedIndex;
          elem.querySelectorAll("select")[j].children[ind].setAttribute("selected", true);
        }

        elem.querySelectorAll("select")[j].setAttribute("data-select", j);
      }

      for (var k = 0; k < elem.querySelectorAll("a").length; k++) {
        elem.querySelectorAll("a")[k].setAttribute("data-a", k);
      }

      return elem.outerHTML.replace(/onclick/ig, "data-oldEvent").replace(/onchange/ig, "data-oldEvent");
    },
    doAction_uiControl493: function (data, elem) {
      var type = data.dataCustom.type;
      var index = data.dataCustom.index;
      var value = data.dataCustom.value;

      if (type === "INPUT") {
        console.log("input in");
        elem.querySelectorAll("input")[index].value = value;
      } else if (type === "SELECT") {
        console.log("select in");
        elem.querySelectorAll("select")[index].value = value;
      } else if (type === "A") {
        console.log("a in");
        elem.querySelectorAll("a")[index].click();
      }
    },
    getTemplate_uiControl493: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n       <div className = \"y_overflow\" onKeyUp={this.onClick}\xA0onClick={this.onClick} dangerouslySetInnerHTML={{__html:\xA0data}}></div>\n    )\n  },\n  onClick:function(e){\n    console.log(\"changein\");\n  \tvar target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if(tag === \"INPUT\"){\n      idx = target.getAttribute(\"data-input\");\n      val = target.value;\n    } else if (tag === \"SELECT\"){\n    \tidx = target.getAttribute(\"data-select\");\n      val = target.value;\n    } else if (tag === \"A\"){\n    \tidx = target.getAttribute(\"data-a\");\n      val = \"\";\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n      \t\ttype: tag,\n          index: idx,\n          value: val\n      \t}\n      })\n    }\n  }\n});\n";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"y_overflow\", onKeyUp: this.onClick, onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    console.log(\"changein\");\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if (tag === \"INPUT\") {\n      idx = target.getAttribute(\"data-input\");\n      val = target.value;\n    } else if (tag === \"SELECT\") {\n      idx = target.getAttribute(\"data-select\");\n      val = target.value;\n    } else if (tag === \"A\") {\n      idx = target.getAttribute(\"data-a\");\n      val = \"\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          type: tag,\n          index: idx,\n          value: val\n        }\n      });\n    }\n  }\n});";
    },
    getData_control501: function (elem) {},
    doAction_uiControl524: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl524: function () {
      var selfTemplate = "const MyBack = React.createClass({\n\xA0 render: function() {\n\xA0 \xA0 return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n\xA0 },\n\xA0 onClick: function() {\n\xA0 \xA0 var handler = this.props.customHandler;\n\xA0 \xA0 handler({});\n\xA0 }\n});\nexport default MyBack;\n\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);