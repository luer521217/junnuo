(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control391: function (elem) {
      var aList = [];
      var aA = elem.querySelectorAll("a");

      for (var i = 0; i < aA.length; i++) {
        aList.push({
          "title": aA[i].innerHTML,
          "index": i
        });
      }

      return aList;
    },
    doAction_uiControl851: function (data, elem) {
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl851: function () {
      var selfTemplate = "const MyMenu = React.createClass({\n  render: function() {\n    var data = this.props.data.customData;\n    var items = data.map( function(item) {\n      return <li data-index={item.index} dangerouslySetInnerHTML = {{__html: item.title}}></li>\n    });\n    return <ul onClick={this.onClick} className=\"list-b\">{items}</ul>\n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexport default MyMenu;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyMenu = React.createClass({\n  displayName: \"MyMenu\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\"li\", { \"data-index\": item.index, dangerouslySetInnerHTML: { __html: item.title } });\n    });\n    return React.createElement(\n      \"ul\",\n      { onClick: this.onClick, className: \"list-b\" },\n      items\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    handler({\n      data: index\n    });\n  }\n});\n\nexports.default = MyMenu;";
    },

    getData_control757: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[1].textContent,
        "totalRecords": aSpan[2].textContent
      };
      return oPage;
    },
    doAction_uiControl853: function (data, elem) {},
    getTemplate_uiControl853: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control762: function (elem) {},
    doAction_uiControl859: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl859: function () {
      var selfTemplate = "const MyBack = React.createClass({\n\xA0 render: function() {\n\xA0 \xA0 return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n\xA0 },\n\xA0 onClick: function() {\n\xA0 \xA0 var handler = this.props.customHandler;\n\xA0 \xA0 handler({});\n\xA0 }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);