(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control495: function (elem) {
      var odiv = elem.cloneNode(true);
      var aa = odiv.getElementsByTagName("a"),
          i = 0;

      for (; i < aa.length; i++) {
        aa[i].removeAttribute("onclick");
      }

      return odiv.innerHTML;
    },
    doAction_uiControl350: function (data, elem) {
      var target = data.dataCustom;
      var text = elem.getElementsByTagName("span");

      for (i = 0; i < text.length; i++) {
        if (target == text[i].innerText) {
          text[i].click();
        }
      }
    },
    getTemplate_uiControl350: function () {
      var selfTemplate = "const\xA0Data\xA0=\xA0React.createClass({\n\xA0\xA0render:\xA0function\xA0render()\xA0{\n\xA0\xA0\n\xA0\xA0\xA0\xA0var\xA0data\xA0=\xA0this.props.data.customData;\n\xA0\xA0\xA0\xA0//console.log(data)\n\xA0\xA0 return\xA0<div\xA0onClick={this.onclick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}}></div>;\xA0\n\xA0\xA0\xA0\xA0\n\xA0\xA0},\n\xA0\xA0onclick:\xA0function\xA0onclick(e){\n\xA0\xA0\xA0\xA0var\xA0tagLi\xA0=\xA0findLi(e.target);\n\xA0\xA0\xA0\xA0function\xA0findLi(ele){\n\xA0\xA0\xA0\xA0 if(ele.tagName\xA0==\xA0\"LI\"){\n\xA0\xA0\xA0\xA0\xA0\xA0 return\xA0ele;\n\xA0\xA0\xA0\xA0\xA0\xA0}\xA0else\xA0{\n\xA0\xA0\xA0\xA0\xA0\xA0 return\xA0findLi(ele.parentNode);\n\xA0\xA0\xA0\xA0\xA0\xA0}\n\xA0\xA0\xA0\xA0}\n\xA0\xA0\xA0\xA0var\xA0all\xA0=\xA0document.querySelectorAll(\".xg_nav\xA0ul\xA0li\");\n\xA0\xA0\xA0\xA0for(let\xA0i=0;\xA0i<all.length;\xA0i++){\n\xA0\xA0\xA0\xA0 all[i].removeAttribute(\"class\");\n\xA0\xA0\xA0\xA0}\n\xA0\xA0\xA0\xA0tagLi.setAttribute(\"class\",\xA0\"ha\");\n\xA0\xA0\xA0\xA0var\xA0target\xA0=\xA0e.target.innerText;\n\xA0\xA0\xA0\xA0var\xA0handler\xA0=\xA0this.props.customHandler;\n\xA0\xA0\xA0\xA0if\xA0(handler)\xA0{\n\xA0\xA0\xA0\xA0 \xA0handler({\n\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0\xA0data\xA0:\xA0target\n\xA0\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n}\n});\n\nexport\xA0default\xA0Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    //console.log(data)\n    return React.createElement(\"div\", { onClick: this.onclick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onclick: function onclick(e) {\n    var tagLi = findLi(e.target);\n    function findLi(ele) {\n      if (ele.tagName == \"LI\") {\n        return ele;\n      } else {\n        return findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav\xA0ul\xA0li\");\n    for (var i = 0; i < all.length; i++) {\n      all[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control494: function (elem) {
      if (elem) {
        var elems = elem.cloneNode(true);var ip = elem.querySelectorAll("input");for (var i = 0; i < ip.length; i++) {
          if (ip[i].type == "checkbox" && ip[i].checked) {
            ip[i].setAttribute("checked", true);
          }
        }return elem.innerHTML.replace("onclick", "option");
      }
    },
    doAction_uiControl1051: function (data, elem) {
      var ip = elem.querySelectorAll("input");for (var i = 0; i < ip.length; i++) {
        var oc = ip[i].getAttribute("value");if (oc == data.dataCustom && ip[i].type == "checkbox") {
          ip[i].click();
        }
      }
    },
    getTemplate_uiControl1051: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return <div className=\"y_table_aa   y_lll lc_margin\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>;  \n  },\n  onClick: function(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:e.target.value\n      });\n    } \n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"y_table_aa   y_lll lc_margin\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: e.target.value\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);