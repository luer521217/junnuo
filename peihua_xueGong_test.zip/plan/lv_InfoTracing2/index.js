(function(win, ysp) {
  ysp.runtime.Model.extendLoadingModel({

  });
})(window, ysp);
