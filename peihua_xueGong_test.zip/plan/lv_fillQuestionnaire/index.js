(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;\n\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control3: function (elem) {
      var inIpt = elem.getElementsByTagName("input")[0];
      return {
        val: inIpt.value,
        name: inIpt.getAttribute("name")
      };
    },
    doAction_uiControl6: function (data, elem) {
      elem.getElementsByTagName("input")[0].value = data.dataCustom;
      elem.getElementsByTagName("input")[0].dispatchEvent(new Event('keyup'));
    },
    getTemplate_uiControl6: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onChange:function(e) {                 \n    var handler= this.props.customHandler; \n    if(handler) {\n      handler({                           \n        data: e.target.value,\n        eventType:'change'\n      })\n    }\n  },\n  render: function(){\n    var data = this.props.data.customData;    \n    return (\n      <input type=\"text\" value={data.val} onChange={this.onChange}/> \n    );\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  onChange: function onChange(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: e.target.value,\n        eventType: 'change'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"input\", { type: \"text\", value: data.val, onChange: this.onChange });\n  }\n});";
    },
    getData_control14: function (elem) {
      if (elem) {
        var ta = elem.cloneNode(true);
        var ip = ta.querySelectorAll("input");

        if (ip.length == 2) {
          ip[0].className = "xg_two_btn";
          ip[1].className = "xg_two_btn1";
        } else if (ip.length == 1) {
          ip[0].className = "xg_one_btn";
        }

        ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
        return ta.innerHTML;
      }
    },
    doAction_uiControl22: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl22: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);