(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control982: function (elem) {
      var odiv = elem.cloneNode(true);
      var aa = odiv.getElementsByTagName("a"),
          i = 0;

      for (; i < aa.length; i++) {
        aa[i].removeAttribute("onclick");
      }

      return odiv.innerHTML;
    },
    doAction_uiControl1154: function (data, elem) {
      var target = data.dataCustom;
      var text = elem.getElementsByTagName("span");

      for (i = 0; i < text.length; i++) {
        if (target == text[i].innerText) {
          text[i].click();
        }
      }
    },
    getTemplate_uiControl1154: function () {
      var selfTemplate = "\nconst Data = React.createClass({\n  render: function render() {\n  \n    var data = this.props.data.customData;\n    //console.log(data)\n  \treturn <div onClick={this.onclick} dangerouslySetInnerHTML={{__html: data}}></div>; \n    \n  },\n  onclick: function onclick(e){\n    var tagLi = findLi(e.target);\n    function findLi(ele){\n    \tif(ele.tagName == \"LI\"){\n      \treturn ele;\n      } else {\n      \treturn findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav ul li\");\n    for(let i=0; i<all.length; i++){\n    \tall[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n    \t handler({\n         data : target\n       })\n    }\n\t}\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    //console.log(data)\n    return React.createElement(\"div\", { onClick: this.onclick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onclick: function onclick(e) {\n    var tagLi = findLi(e.target);\n    function findLi(ele) {\n      if (ele.tagName == \"LI\") {\n        return ele;\n      } else {\n        return findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav ul li\");\n    for (var i = 0; i < all.length; i++) {\n      all[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },

    getData_control984: function (elem) {
      for (var i = 0; i < elem.querySelectorAll("font").length; i++) {
        elem.querySelectorAll("font")[i].setAttribute("data-font", i);
      }

      return elem.outerHTML;
    },
    doAction_uiControl1156: function (data, elem) {
      var type = data.dataCustom.type;
      var index = data.dataCustom.index;

      if (type === "FONT") {
        elem.querySelectorAll("font")[index].click();
      }
    },
    getTemplate_uiControl1156: function () {
      var selfTemplate = '\nvar React = require(\'react\');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <div className="y_table_aa" onClick={this.onClick}><table dangerouslySetInnerHTML={{__html:\xA0data}}></table></div>\n    )\n  },\n  onClick:function(e){\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if(tag === "FONT"){\n      idx = target.getAttribute("data-font");\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n      \t\ttype: tag,\n          index: idx\n      \t}\n      })\n    }\n  }\n});\n';
      return '"use strict";\n\nvar React = require(\'react\');\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      "div",\n      { className: "y_table_aa", onClick: this.onClick },\n      React.createElement("table", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if (tag === "FONT") {\n      idx = target.getAttribute("data-font");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          type: tag,\n          index: idx\n        }\n      });\n    }\n  }\n});';
    },
    getData_control1129: function (elem) {},
    doAction_uiControl1150: function (data, elem) {
      elem.querySelector('a.ui_close').click();
    },
    getTemplate_uiControl1150: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);