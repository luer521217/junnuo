(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control811: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl933: function (data, elem) {},
    getTemplate_uiControl933: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table dangerouslySetInnerHTML={{__html:\xA0data}} className='y_info y_info2 xsxx'></table>\n    )\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement('table', { dangerouslySetInnerHTML: { __html: data }, className: 'y_info y_info2 xsxx' });\n  }\n});";
    },
    getData_control814: function (elem) {
      for (var i = 0; i < elem.querySelectorAll("input").length; i++) {
        elem.querySelectorAll("input")[i].setAttribute("data-input", i);
      }

      for (var j = 0; j < elem.querySelectorAll("select").length; j++) {
        elem.querySelectorAll("select")[j].setAttribute("data-select", j);
      }

      for (var k = 0; k < elem.querySelectorAll("a").length; k++) {
        elem.querySelectorAll("a")[k].setAttribute("data-a", k);
      }

      for (var m = 0; m < elem.querySelectorAll("textarea").length; m++) {
        elem.querySelectorAll("textarea")[m].setAttribute("data-textarea", m);
      }

      return elem.outerHTML.replace(/onclick/ig, 'data-onclick');
    },
    doAction_uiControl936: function (data, elem) {
      var type = data.dataCustom.type;
      var index = data.dataCustom.index;
      var value = data.dataCustom.value;

      if (type === "INPUT") {
        elem.querySelectorAll("input")[index].value = value;
      } else if (type === "SELECT") {
        elem.querySelectorAll("select")[index].value = value;
      } else if (type === "A") {
        elem.querySelectorAll("a")[index].click();
      } else if (type === "TEXTAREA") {
        elem.querySelectorAll("textarea")[index].value = value;
      }
    },
    getTemplate_uiControl936: function () {
      var selfTemplate = "\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table onClick={this.handleClick}\xA0onBlur={this.handleClick} dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info y_info2 gyjlxx\"></table>\n    )\n  },\n  handleClick:function(e){\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if(tag === \"INPUT\"){\n      idx = target.getAttribute(\"data-input\");\n      val = target.value;\n    } else if (tag === \"SELECT\"){\n    \tidx = target.getAttribute(\"data-select\");\n      val = target.value;\n    } else if (tag === \"A\"){\n    \tidx = target.getAttribute(\"data-a\");\n      val = \"\";\n    } else if (tag === \"TEXTAREA\"){\n    \tidx = target.getAttribute(\"data-textarea\");\n      val = target.value;\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n      \t\ttype: tag,\n          index: idx,\n          value: val\n      \t}\n      })\n    }\n  }\n});\n";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { onClick: this.handleClick, onBlur: this.handleClick, dangerouslySetInnerHTML: { __html: data }, className: \"y_info y_info2 gyjlxx\" });\n  },\n  handleClick: function handleClick(e) {\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if (tag === \"INPUT\") {\n      idx = target.getAttribute(\"data-input\");\n      val = target.value;\n    } else if (tag === \"SELECT\") {\n      idx = target.getAttribute(\"data-select\");\n      val = target.value;\n    } else if (tag === \"A\") {\n      idx = target.getAttribute(\"data-a\");\n      val = \"\";\n    } else if (tag === \"TEXTAREA\") {\n      idx = target.getAttribute(\"data-textarea\");\n      val = target.value;\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          type: tag,\n          index: idx,\n          value: val\n        }\n      });\n    }\n  }\n});";
    },
    getData_control816: function (elem) {
      return elem.innerHTML.replace(/style/ig, 'data-style');
    },
    doAction_uiControl938: function (data, elem) {},
    getTemplate_uiControl938: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <div dangerouslySetInnerHTML={{__html:\xA0data}} className='y_table_aa yhjlxx'>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement('div', { dangerouslySetInnerHTML: { __html: data }, className: 'y_table_aa yhjlxx' });\n  }\n});";
    },
    getData_control1105: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl1288: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl1288: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);