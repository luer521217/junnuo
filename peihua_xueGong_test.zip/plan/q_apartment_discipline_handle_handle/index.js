(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control264: function (elem) {
      var target1 = elem.querySelector("textarea");
      target1.placeholder = "限制在500字内";
      target1.parentNode.parentNode.classList.add("textarea-wrap");
      var target2 = elem.querySelector("select");
      target2.parentNode.parentNode.classList.add("select-wrap");
      return elem.outerHTML.replace(/width/ig, "data-width");
    },
    doAction_uiControl304: function (data, elem) {
      var value = data.dataCustom.value;
      var type = data.dataCustom.type;

      if (type === "SELECT") {
        elem.querySelector("select").value = value;
      } else if (type === "TEXTAREA") {
        elem.querySelector("textarea").value = value;
      }
    },
    getTemplate_uiControl304: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table className=\"y_info y_info2\" dangerouslySetInnerHTML={{__html:\xA0data}} onBlur={this.onClick} onClick={this.onClick}></table>\n    )\n  },\n  onClick: function(e){\n    console.log(\"in\");\n  \tvar target = e.target;\n    var tar = target.tagName,\n        val;\n    if(tar === \"SELECT\"){\n      val = target.value;\n    } else if (tar === \"TEXTAREA\"){\n    \tval = target.value;\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n        \tvalue: val,\n          type: tar\n        }\n      })\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { className: \"y_info y_info2\", dangerouslySetInnerHTML: { __html: data }, onBlur: this.onClick, onClick: this.onClick });\n  },\n  onClick: function onClick(e) {\n    console.log(\"in\");\n    var target = e.target;\n    var tar = target.tagName,\n        val;\n    if (tar === \"SELECT\") {\n      val = target.value;\n    } else if (tar === \"TEXTAREA\") {\n      val = target.value;\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          value: val,\n          type: tar\n        }\n      });\n    }\n  }\n});";
    },
    getData_control1101: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl1284: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl1284: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);