(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control96: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl129: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl129: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control100: function (elem) {
     if (elem && elem.querySelectorAll("dd")) {
        var section = elem.querySelectorAll("dd");
        var list = [];

        for (let i = 0; i < section.length; i++) {
          list.push(section[i].innerText);
        }

        return list;
      }
    },
    doAction_uiControl134: function (data, elem) {
      var text = data.dataCustom;
      elem.querySelectorAll("dd")[text].querySelector("a").click();
    },
    getTemplate_uiControl134: function () {
       var selfTemplate = "var Condition = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    if(data==\"\"){\n      return (<div></div>)\n                }else{\n      var items = data.map(function(item,index){\n        return <div data-index={index}>{item}</div>\n      });\n      return <section>\n        <label>\u5DF2\u9009\u6761\u4EF6\uFF1A</label>\n        <div  onClick={this.handleClick}>{items}</div>\n      </section>\n    }\n  },\n  handleClick: function(event){\n  \tvar text = event.target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n})\nexport default Condition;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Condition = React.createClass({\n  displayName: \"Condition\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data == \"\") {\n      return React.createElement(\"div\", null);\n    } else {\n      var items = data.map(function (item, index) {\n        return React.createElement(\n          \"div\",\n          { \"data-index\": index },\n          item\n        );\n      });\n      return React.createElement(\n        \"section\",\n        null,\n        React.createElement(\n          \"label\",\n          null,\n          \"\\u5DF2\\u9009\\u6761\\u4EF6\\uFF1A\"\n        ),\n        React.createElement(\n          \"div\",\n          { onClick: this.handleClick },\n          items\n        )\n      );\n    }\n  },\n  handleClick: function handleClick(event) {\n    var text = event.target.getAttribute(\"data-index\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Condition;";
    },
    getData_control102: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          oDiv = [];

      for (var i = 1; i < inTr.length; i++) {
        inTd = inTr[i].getElementsByTagName("td");
        oDiv.push({
          selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
          one: inTd[1].innerText,
          two: inTd[2].innerText,
          three: inTd[3].innerText,
          bed_counts: inTd[4].innerText,
          people: inTd[5].innerText,
          score: inTd[6].querySelector("input").value,
          note: inTd[7].querySelector("input").value
        });
      }

      return oDiv;
    },
    doAction_uiControl137: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var content = data.dataCustom.content;
      var row = elem.querySelector("tbody").getElementsByTagName("tr")[index];
      var inp = elem.querySelector("tbody").getElementsByTagName("input")[index * 3];

      if (type == "input") {
        inp.click();
      } else if (type == "text1") {
        row.querySelector("#fz_" + index).value = content;
      } else if (type == "text2") {
        row.querySelector("#bz_" + index).value = content;
      } else {
        row.click();
      }
    },
    getTemplate_uiControl137: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onChange:function(e){\n    \n    // \u4FDD\u5B58input\u76EE\u6807\n    var tempTar = e.target;\n    \n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    var content = \"\";\n    // input\u7684\u5904\u7406\n    if ( (nName === \"INPUT\") && (tempTar.getAttribute(\"type\") === \"checkbox\") ) {\n      type = \"input\";\n    }else if( (tempTar.getAttribute(\"type\") === \"text\") && (tempTar.getAttribute(\"class\") === \"score\") ) {\n    \ttype = \"text1\";\n      content = tempTar.value;\n    }else if( (tempTar.getAttribute(\"type\") === \"text\") && (tempTar.getAttribute(\"class\") === \"note\") ) {\n    \ttype = \"text2\";\n      content = tempTar.value;\n    }\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index,\n          \t\"content\": content\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n       return(\n        <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" /> </div>\n  <div className=\"lv_dbsy_rest\">\n              <span>\n            <b>\u697C\u680B\uFF1A</b>\n              {item.one}</span>\n            <span>\n              <b>\u5C42\u53F7\uFF1A</b>\n              {item.two}</span>\n            <span>\n              <b>\u5BDD\u5BA4\u53F7\uFF1A</b>\n              {item.three}</span>\n            <span>\n              <b>\u5E8A\u4F4D\u6570\uFF1A</b>\n              {item.bed_counts}</span> \n            <span>\n              <b>\u5165\u4F4F\u4EBA\u6570\uFF1A</b>\n              {item.people}</span>\n            <span>\n              <b>\u5206\u503C\uFF1A</b>\n              {item.score}\n    <input type=\"text\" className=\"score\" />\n    </span>\n            <span>\n              <b>\u5206\u503C\u5907\u6CE8\uFF1A</b>\n              {item.note}\n    <input type=\"text\" className=\"note\"/>\n    </span>\n             </div>\n          </li>\n\n\n        ); \n      })\n    return <ul className=\"lv_dbsy_ul\" onChange={this.onChange}>{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onChange: function onChange(e) {\n\n    // \u4FDD\u5B58input\u76EE\u6807\n    var tempTar = e.target;\n\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    var content = \"\";\n    // input\u7684\u5904\u7406\n    if (nName === \"INPUT\" && tempTar.getAttribute(\"type\") === \"checkbox\") {\n      type = \"input\";\n    } else if (tempTar.getAttribute(\"type\") === \"text\" && tempTar.getAttribute(\"class\") === \"score\") {\n      type = \"text1\";\n      content = tempTar.value;\n    } else if (tempTar.getAttribute(\"type\") === \"text\" && tempTar.getAttribute(\"class\") === \"note\") {\n      type = \"text2\";\n      content = tempTar.value;\n    }\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index,\n          \"content\": content\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        return React.createElement(\n          \"li\",\n          { \"data-index\": index, className: \"lv_dbsy_li\" },\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_ip\" },\n            \" \",\n            React.createElement(\"input\", { type: \"checkbox\" }),\n            \" \"\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_rest\" },\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u697C\\u680B\\uFF1A\"\n              ),\n              item.one\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5C42\\u53F7\\uFF1A\"\n              ),\n              item.two\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5BDD\\u5BA4\\u53F7\\uFF1A\"\n              ),\n              item.three\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5E8A\\u4F4D\\u6570\\uFF1A\"\n              ),\n              item.bed_counts\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5165\\u4F4F\\u4EBA\\u6570\\uFF1A\"\n              ),\n              item.people\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5206\\u503C\\uFF1A\"\n              ),\n              item.score,\n              React.createElement(\"input\", { type: \"text\", className: \"score\" })\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5206\\u503C\\u5907\\u6CE8\\uFF1A\"\n              ),\n              item.note,\n              React.createElement(\"input\", { type: \"text\", className: \"note\" })\n            )\n          )\n        );\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onChange: this.onChange },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control103: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl139: function (data, elem) {},
    getTemplate_uiControl139: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control125: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl168: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl168: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);