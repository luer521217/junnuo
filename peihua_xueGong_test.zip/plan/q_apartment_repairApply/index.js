(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control204: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl277: function (data, elem) {},
    getTemplate_uiControl277: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control202: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = function () {
        var trs = elem.querySelectorAll("tr");

        for (var i = 0; i < trs.length; i++) {
          if (trs[i].querySelectorAll("td")[1].innerHTML.trim() == "&nbsp;") {
            return i;
          }
        }

        return trs.length;
      }(),
          oDiv = [];

      var i;

      for (i = 1; i < trLen + 1; i++) {
        var inTd = inTr[i].querySelectorAll("td");

        if (inTr[1].querySelectorAll("td")[1].innerHTML.trim() == "&nbsp;") {
          oDiv.push({
            error: "未找到任何记录！"
          });
        } else {
          oDiv.push({
            selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
            date: inTd[1].innerText,
            item: inTd[2].innerText,
            degree: inTd[3].innerText,
            class: inTd[4].innerText,
            sub_item: inTd[5].innerText,
            date1: inTd[6].innerText,
            date2: inTd[7].innerText,
            status: inTd[8].innerText,
            evaluate: inTd[9].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl275: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var aLi = elem.querySelector("tbody").getElementsByTagName("tr")[index];
      var aip = elem.querySelector("tbody").getElementsByTagName("tr")[index].querySelectorAll("input")[0];
      console.log(aip);

      if (type == "input") {
        aip.click();
      } else {
        aLi.dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl275: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n       return(\n        <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" /> </div>\n  <div className=\"lv_dbsy_rest\">\n              <span>\n            <b>\u62A5\u4FEE\u65F6\u95F4\uFF1A</b>\n              {item.date}</span>\n            <font>\n              <b>\u62A5\u4FEE\u5185\u5BB9\uFF1A</b>\n              {item.item}</font>\n            <font>\n              <b>\u7D27\u6025\u7A0B\u5EA6\uFF1A</b>\n              {item.degree}</font>\n            <span>\n              <b>\u62A5\u4FEE\u7C7B\u522B\uFF1A</b>\n              {item.class}</span> \n            <span>\n              <b>\u62A5\u4FEE\u7C7B\u522B\u5B50\u9879\uFF1A</b>\n              {item.sub_item}</span>\n            <span>\n              <b>\u671F\u671B\u7EF4\u4FEE\u65F6\u95F4\uFF1A</b>\n              {item.date1}</span>\n            <span>\n              <b>\u5B9E\u9645\u7EF4\u4FEE\u65F6\u95F4\uFF1A</b>\n              {item.date2}</span>\n    <span>\n              <b>\u5904\u7406\u72B6\u6001\uFF1A</b>\n              {item.status}</span>\n    <span>\n              <b>\u6EE1\u610F\u7A0B\u5EA6\uFF1A</b>\n              {item.evaluate}</span>\n             </div>\n          </li>\n\n\n        ); \n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        return React.createElement(\n          \"li\",\n          { \"data-index\": index, className: \"lv_dbsy_li\" },\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_ip\" },\n            \" \",\n            React.createElement(\"input\", { type: \"checkbox\" }),\n            \" \"\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"lv_dbsy_rest\" },\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u62A5\\u4FEE\\u65F6\\u95F4\\uFF1A\"\n              ),\n              item.date\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u62A5\\u4FEE\\u5185\\u5BB9\\uFF1A\"\n              ),\n              item.item\n            ),\n            React.createElement(\n              \"font\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u7D27\\u6025\\u7A0B\\u5EA6\\uFF1A\"\n              ),\n              item.degree\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u62A5\\u4FEE\\u7C7B\\u522B\\uFF1A\"\n              ),\n              item.class\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u62A5\\u4FEE\\u7C7B\\u522B\\u5B50\\u9879\\uFF1A\"\n              ),\n              item.sub_item\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u671F\\u671B\\u7EF4\\u4FEE\\u65F6\\u95F4\\uFF1A\"\n              ),\n              item.date1\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5B9E\\u9645\\u7EF4\\u4FEE\\u65F6\\u95F4\\uFF1A\"\n              ),\n              item.date2\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u5904\\u7406\\u72B6\\u6001\\uFF1A\"\n              ),\n              item.status\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              React.createElement(\n                \"b\",\n                null,\n                \"\\u6EE1\\u610F\\u7A0B\\u5EA6\\uFF1A\"\n              ),\n              item.evaluate\n            )\n          )\n        );\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control225: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl291: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl291: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);