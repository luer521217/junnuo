(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1: function (elem) {
      var xx = elem.querySelectorAll("tbody tr");

      for (let i = 0; i < xx.length; i++) {
        xx[i].setAttribute("data-index", i);
      }

      return elem.innerHTML.replace(/onclick/ig, "data-oldClick").replace(/ondblclick/ig, "data-oldDblclick");
    },
    doAction_uiControl4: function (data, elem) {
      var index = data.dataCustom;
      elem.querySelectorAll("tbody tr")[index].click();
      elem.querySelectorAll("tbody tr")[index].ondblclick();
    },
    getTemplate_uiControl4: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  render: function () {\n      var data = this.props.data.customData;\n     return <table className=\"table-show\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;  \n      },\n  onClick: function(e){\n\t\tvar target = e.target;\n    if(target.tagName == \"TD\"){\n\t\t\tvar index = target.parentNode.getAttribute(\"data-index\");\n    }\n    var handler = this.props.customHandler;\n    if(handler){\n     handler({\n       data: index\n      })\n    }\n\n\n  }\n  });\nexport default TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n\t\tvalue: true\n});\nvar TaskList = React.createClass({\n\t\tdisplayName: \"TaskList\",\n\n\t\trender: function render() {\n\t\t\t\tvar data = this.props.data.customData;\n\t\t\t\treturn React.createElement(\"table\", { className: \"table-show\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n\t\t},\n\t\tonClick: function onClick(e) {\n\t\t\t\tvar target = e.target;\n\t\t\t\tif (target.tagName == \"TD\") {\n\t\t\t\t\t\tvar index = target.parentNode.getAttribute(\"data-index\");\n\t\t\t\t}\n\t\t\t\tvar handler = this.props.customHandler;\n\t\t\t\tif (handler) {\n\t\t\t\t\t\thandler({\n\t\t\t\t\t\t\t\tdata: index\n\t\t\t\t\t\t});\n\t\t\t\t}\n\t\t}\n});\nexports.default = TaskList;";
    },
    getData_control655: function (elem) {},
    doAction_uiControl710: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl710: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);