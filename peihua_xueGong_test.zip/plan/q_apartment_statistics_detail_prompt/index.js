(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control761: function (elem) {
      return elem.innerHTML;
    },
    doAction_uiControl854: function (data, elem) {},
    getTemplate_uiControl854: function () {
      var selfTemplate = "var Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    return <div className=\"popup-detail y_table_aa\"><table\xA0dangerouslySetInnerHTML={{__html:\xA0data}}></table></div>\n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"popup-detail y_table_aa\" },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  }\n});\nexports.default = Data;";
    },
    getData_control762: function (elem) {},
    doAction_uiControl856: function (data, elem) {
      ysp.runtime.Browser.activeBrowser.close();
    },
    getTemplate_uiControl856: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);