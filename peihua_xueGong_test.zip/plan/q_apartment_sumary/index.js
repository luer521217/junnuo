(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control6: function (elem) {
      var xx = elem.querySelectorAll("tbody tr");

      for (let i = 0; i < xx.length; i++) {
        xx[i].setAttribute("data-i", i);
      }

      var yy = elem.querySelectorAll("a");

      for (let j = 0; j < yy.length; j++) {
        yy[j].setAttribute("data-j", j);
      }

      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl11: function (data, elem) {
      var index_i = data.dataCustom.i;
      var index_j = data.dataCustom.j;

      if (index_i != null) {
        elem.querySelectorAll("tbody tr")[index_i].click();
        elem.querySelectorAll("tbody tr")[index_i].ondblclick();
      }

      if (index_j != undefined) {
        elem.querySelectorAll("a")[index_j].click();
      }
    },
    getTemplate_uiControl11: function () {
      var selfTemplate = "const\xA0TaskList\xA0=\xA0React.createClass({\n\xA0\xA0render:\xA0function\xA0()\xA0{\n\xA0\xA0\xA0\xA0\xA0\xA0var\xA0data\xA0=\xA0this.props.data.customData;\n\xA0\xA0\xA0\xA0 return\xA0<table\xA0onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}}></table>;\xA0\xA0\n\xA0\xA0\xA0\xA0\xA0\xA0},\n\xA0\xA0onClick:\xA0function(e){\n\xA0\xA0 var\xA0target\xA0=\xA0e.target;\n  \tif(target.tagName\xA0==\xA0\"A\"){\n\xA0\xA0\xA0\xA0 var\xA0index_j\xA0=\xA0target.getAttribute(\"data-j\");\n\xA0\xA0\xA0\xA0}\n    \n    //\u4F7F\u5176\u6307\u5411tr;\n  \tif(target.tagName == \"TD\"){\n     target = target.parentNode;\n    }\n    var index_i = target.getAttribute(\"data-i\");\n        var countTr = document.querySelectorAll(\".xszstj-list table tbody tr\");\n    for(let i=0; i<countTr.length; i++){\n    countTr[i].setAttribute(\"class\", \"\");\n    }\n    target.setAttribute(\"class\", \"current\");\n\xA0\xA0\xA0\xA0var\xA0handler\xA0=\xA0this.props.customHandler;\nif(handler){\n\xA0\xA0\xA0\xA0 handler({\n\xA0\xA0\xA0\xA0\xA0\xA0 data: {\n     \t\ti: index_i,\n       \tj: index_j\n     }\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n\xA0\xA0}\n\xA0\xA0});\nexport\xA0default\xA0TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"A\") {\n      var index_j = target.getAttribute(\"data-j\");\n    }\n\n    //\u4F7F\u5176\u6307\u5411tr;\n    if (target.tagName == \"TD\") {\n      target = target.parentNode;\n    }\n    var index_i = target.getAttribute(\"data-i\");\n    var countTr = document.querySelectorAll(\".xszstj-list table tbody tr\");\n    for (var i = 0; i < countTr.length; i++) {\n      countTr[i].setAttribute(\"class\", \"\");\n    }\n    target.setAttribute(\"class\", \"current\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          i: index_i,\n          j: index_j\n        }\n      });\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control7: function (elem) {
      var aInput = elem.querySelectorAll("input");
      var totalPage = elem.querySelector("#max_page");
      var totalRecords = elem.querySelector("#max_record");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl13: function (data, elem) {},
    getTemplate_uiControl13: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control17: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl7: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "\nmodule.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control19: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl6: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl6: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control24: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl22: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl22: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control654: function (elem) {},
    doAction_uiControl687: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl687: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);