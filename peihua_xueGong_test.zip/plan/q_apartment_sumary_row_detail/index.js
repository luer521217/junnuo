(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {
      var xx = elem.querySelectorAll("tbody tr");

      for (let i = 0; i < xx.length; i++) {
        xx[i].setAttribute("data-i", i);
      }

      var yy = elem.querySelectorAll("a");

      for (let j = 0; j < yy.length; j++) {
        yy[j].setAttribute("data-j", j);
      }

      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl22: function (data, elem) {
      var index_i = data.dataCustom.i;
      var index_j = data.dataCustom.j;

      if (index_i != null) {
        elem.querySelectorAll("tbody tr")[index_i].click();
      }

      if (index_j != undefined) {
        elem.querySelectorAll("a")[index_j].click();
      }
    },
    getTemplate_uiControl22: function () {
      var selfTemplate = "const\xA0TaskList\xA0=\xA0React.createClass({\n\xA0\xA0render:\xA0function\xA0()\xA0{\n\xA0\xA0\xA0\xA0\xA0\xA0var\xA0data\xA0=\xA0this.props.data.customData;\n\xA0\xA0\xA0\xA0 return\xA0<table onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}}></table>;\xA0\xA0\n\xA0\xA0\xA0\xA0\xA0\xA0},\n\xA0\xA0onClick:\xA0function(e){\n\xA0\xA0 var\xA0target\xA0=\xA0e.target;\n  \tif(target.tagName\xA0==\xA0\"A\"){\n\xA0\xA0\xA0\xA0 var\xA0index_j\xA0=\xA0target.getAttribute(\"data-j\");\n\xA0\xA0\xA0\xA0}\n    \n    //\u4F7F\u5176\u6307\u5411tr;\n  \tif(target.tagName == \"TD\"){\n     target = target.parentNode;\n    }\n    var index_i = target.getAttribute(\"data-i\");\n    \n    var countTr = document.querySelectorAll(\".xszstj-list table tbody tr\");\n    for(let i=0; i<countTr.length; i++){\n    countTr[i].setAttribute(\"class\", \"\");\n    }\n    target.setAttribute(\"class\", \"current\");\n    \n\xA0\xA0\xA0\xA0var\xA0handler\xA0=\xA0this.props.customHandler;\nif(handler){\n\xA0\xA0\xA0\xA0 handler({\n\xA0\xA0\xA0\xA0\xA0\xA0 data: {\n     \t\ti: index_i,\n       \tj: index_j\n     }\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n\xA0\xA0}\n\xA0\xA0});\nexport\xA0default\xA0TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"A\") {\n      var index_j = target.getAttribute(\"data-j\");\n    }\n\n    //\u4F7F\u5176\u6307\u5411tr;\n    if (target.tagName == \"TD\") {\n      target = target.parentNode;\n    }\n    var index_i = target.getAttribute(\"data-i\");\n\n    var countTr = document.querySelectorAll(\".xszstj-list table tbody tr\");\n    for (var i = 0; i < countTr.length; i++) {\n      countTr[i].setAttribute(\"class\", \"\");\n    }\n    target.setAttribute(\"class\", \"current\");\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          i: index_i,\n          j: index_j\n        }\n      });\n    }\n  }\n});\nexports.default = TaskList;";
    }
  });
})(window, ysp);