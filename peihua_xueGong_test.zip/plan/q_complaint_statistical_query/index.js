(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control394: function (elem) {
            var getItem = elem.querySelectorAll('ul li');
      var list = [];

      for (var i = 0; i < getItem.length; i++) {
        list.push(getItem[i].textContent);
      }

      return list;
    },
    doAction_uiControl576: function (data, elem) {
            var target = data.dataCustom;
      elem.querySelectorAll('ul li')[target].querySelector('a').click();
    },
    getTemplate_uiControl576: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n\t\tvar items = data.map(function(item, idx){\n    \treturn <li data-idx={idx}>{item}</li>\n    })\n    return <ul onClick={this.handleClick}>{items}</ul>\n  },\n  \n  handleClick: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n\xA0\xA0\xA0\xA0\thandler({\n\xA0\xA0\xA0\xA0\xA0\xA0 \tdata:\xA0e.target.getAttribute('data-idx')\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n\n  }\n});";
      return '\'use strict\';\n\nvar React = require(\'react\');\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, idx) {\n      return React.createElement(\n        \'li\',\n        { \'data-idx\': idx },\n        item\n      );\n    });\n    return React.createElement(\n      \'ul\',\n      { onClick: this.handleClick },\n      items\n    );\n  },\n\n  handleClick: function handleClick(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: e.target.getAttribute(\'data-idx\')\n      });\n    }\n  }\n});';
    }
  });
})(window, ysp);