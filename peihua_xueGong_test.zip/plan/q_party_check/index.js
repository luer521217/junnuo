(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control3: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl7: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control7: function (elem) {
      var odiv = elem.cloneNode(true);
      var aa = odiv.getElementsByTagName("a"),
          i = 0;

      for (; i < aa.length; i++) {
        aa[i].removeAttribute("onclick");
      }

      return odiv.innerHTML;
    },
    doAction_uiControl12: function (data, elem) {
      var target = data.dataCustom;
      var text = elem.getElementsByTagName("span");

      for (i = 0; i < text.length; i++) {
        if (target == text[i].innerText) {
          text[i].click();
        }
      }
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "\nconst Data = React.createClass({\n  render: function render() {\n  \n    var data = this.props.data.customData;\n    //console.log(data)\n  \treturn <div onClick={this.onclick} dangerouslySetInnerHTML={{__html: data}}></div>; \n    \n  },\n  onclick: function onclick(e){\n    var tagLi = findLi(e.target);\n    function findLi(ele){\n    \tif(ele.tagName == \"LI\"){\n      \treturn ele;\n      } else {\n      \treturn findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav ul li\");\n    for(let i=0; i<all.length; i++){\n    \tall[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n    \t handler({\n         data : target\n       })\n    }\n\t}\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n\n    var data = this.props.data.customData;\n    //console.log(data)\n    return React.createElement(\"div\", { onClick: this.onclick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onclick: function onclick(e) {\n    var tagLi = findLi(e.target);\n    function findLi(ele) {\n      if (ele.tagName == \"LI\") {\n        return ele;\n      } else {\n        return findLi(ele.parentNode);\n      }\n    }\n    var all = document.querySelectorAll(\".xg_nav ul li\");\n    for (var i = 0; i < all.length; i++) {\n      all[i].removeAttribute(\"class\");\n    }\n    tagLi.setAttribute(\"class\", \"ha\");\n    var target = e.target.innerText;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control8: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];var i;for (i = 1; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];if (inSpan == undefined) {
          oDiv.push({ error: inTd[0].innerText });
        } else {
          oDiv.push({ selectBoxId: inTd[0].getElementsByTagName("input")[0].checked, id: inTd[2].innerText, name: inTd[3].innerText, grade: inTd[4].innerText, academy: inTd[5].innerText, class: inTd[6].innerText, gender: inTd[7].innerText, term: inTd[8].innerText, date: inTd[9].innerText, status: inTd[14].innerText });
        }
      }return oDiv;
    },
    doAction_uiControl14: function (data, elem) {
      var index = data.dataCustom.index;var type = data.dataCustom.type;var aLi = elem.querySelector("tbody").getElementsByTagName("a")[index];var aip = elem.querySelector("tbody").getElementsByTagName("tr")[index];if (type == "input") {
        aip.dispatchEvent(new Event("click"));
      } else {
        aLi.dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl14: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n<div className=\"lv_dbsy_rest\"><span>\n              <b>\u5B66\u53F7\uFF1A</b>\n  <a>{item.id}</a></span>\n            <font>\n              <b>\u59D3\u540D\uFF1A</b>\n              {item.name}</font>\n            <font>\n              <b>\u5E74\u7EA7\uFF1A</b>\n              {item.grade}</font>\n            <span>\n              <b>\u5B66\u9662\uFF1A</b>\n              {item.academy}</span> \n            <span>\n              <b>\u73ED\u7EA7\uFF1A</b>\n              {item.class}</span>\n            <span>\n              <b>\u6027\u522B\uFF1A</b>\n              {item.gender}</span>\n            <span>\n              <b>\u7533\u8BF7\u9636\u6BB5\u540D\u79F0\uFF1A</b>\n              {item.term}</span>\n            <span>\n              <b>\u7533\u8BF7\u65F6\u95F4\uFF1A</b>\n              {item.date}</span>\n            <span>\n              <b>\u5BA1\u6838\u72B6\u6001\uFF1A</b>\n              {item.status}</span>\n             </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n<div className=\"lv_dbsy_rest\"><span>\n              <b>\u5B66\u53F7\uFF1A</b>\n  <a>{item.id}</a></span>\n            <font>\n              <b>\u59D3\u540D\uFF1A</b>\n              {item.name}</font>\n            <font>\n              <b>\u5E74\u7EA7\uFF1A</b>\n              {item.grade}</font>\n            <span>\n              <b>\u5B66\u9662\uFF1A</b>\n              {item.academy}</span> \n            <span>\n              <b>\u73ED\u7EA7\uFF1A</b>\n              {item.class}</span>\n            <span>\n              <b>\u6027\u522B\uFF1A</b>\n              {item.gender}</span>\n            <span>\n              <b>\u7533\u8BF7\u9636\u6BB5\u540D\u79F0\uFF1A</b>\n              {item.term}</span>\n            <span>\n              <b>\u7533\u8BF7\u65F6\u95F4\uFF1A</b>\n              {item.date}</span>\n            <span>\n              <b>\u5BA1\u6838\u72B6\u6001\uFF1A</b>\n              {item.status}</span>\n             </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u53F7\\uFF1A\"\n                ),\n                React.createElement(\n                  \"a\",\n                  null,\n                  item.id\n                )\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u59D3\\u540D\\uFF1A\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5E74\\u7EA7\\uFF1A\"\n                ),\n                item.grade\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.academy\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.class\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u6027\\u522B\\uFF1A\"\n                ),\n                item.gender\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u9636\\u6BB5\\u540D\\u79F0\\uFF1A\"\n                ),\n                item.term\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u65F6\\u95F4\\uFF1A\"\n                ),\n                item.date\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5BA1\\u6838\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.status\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u53F7\\uFF1A\"\n                ),\n                React.createElement(\n                  \"a\",\n                  null,\n                  item.id\n                )\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u59D3\\u540D\\uFF1A\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5E74\\u7EA7\\uFF1A\"\n                ),\n                item.grade\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.academy\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.class\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u6027\\u522B\\uFF1A\"\n                ),\n                item.gender\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u9636\\u6BB5\\u540D\\u79F0\\uFF1A\"\n                ),\n                item.term\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u7533\\u8BF7\\u65F6\\u95F4\\uFF1A\"\n                ),\n                item.date\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5BA1\\u6838\\u72B6\\u6001\\uFF1A\"\n                ),\n                item.status\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control9: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].textContent,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl16: function (data, elem) {},
    getTemplate_uiControl16: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control14: function (elem) {},
    doAction_uiControl22: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl22: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">返回</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"返回\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control16: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl24: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl24: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control508: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl528: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl528: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control1178: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl1343: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl1343: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);