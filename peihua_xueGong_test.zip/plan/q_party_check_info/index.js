(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control819: function (elem) {
      for (var k = 0; k < elem.querySelectorAll("a").length; k++) {
        elem.querySelectorAll("a")[k].setAttribute("data-a", k);
      }

      return elem.outerHTML;
    },
    doAction_uiControl941: function (data, elem) {
      var type = data.dataCustom.type;
      var index = data.dataCustom.index;
      var value = data.dataCustom.value;
      elem.querySelectorAll("a")[index].click();
    },
    getTemplate_uiControl941: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info y_info2\"></table>\n    )\n  },\n  onClick:function(e){\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n\t\tif (tag === \"A\"){\n    \tidx = target.getAttribute(\"data-a\");\n      val = \"\";\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: {\n      \t\ttype: tag,\n          index: idx,\n          value: val\n      \t}\n      })\n    }\n  }\n});\n";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data }, className: \"y_info y_info2\" });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var tag = target.tagName;\n    var idx, val;\n    if (tag === \"A\") {\n      idx = target.getAttribute(\"data-a\");\n      val = \"\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          type: tag,\n          index: idx,\n          value: val\n        }\n      });\n    }\n  }\n});";
    },
    getData_control821: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl943: function (data, elem) {},
    getTemplate_uiControl943: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table\xA0dangerouslySetInnerHTML={{__html:\xA0data}} className='y_info y_info2'></table>\n    )\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement('table', { dangerouslySetInnerHTML: { __html: data }, className: 'y_info y_info2' });\n  }\n});";
    },
    getData_control822: function (elem) {
      return elem.innerHTML;
    },
    doAction_uiControl944: function (data, elem) {},
    getTemplate_uiControl944: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <div\xA0dangerouslySetInnerHTML={{__html:\xA0data}} className='y_table_aa'>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement('div', { dangerouslySetInnerHTML: { __html: data }, className: 'y_table_aa' });\n  }\n});";
    }
  });
})(window, ysp);