(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1: function (elem) {
      elem.querySelectorAll("img")[0].src = "http://42.247.16.108/xgxt/xsgzgl/dtjs/dtxxglnew/color/sys.png";
      elem.querySelectorAll("img")[1].src = "http://42.247.16.108/xgxt/xsgzgl/dtjs/dtxxglnew/color/qys.png";
      return elem.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl27: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelector("a");

      if (event.getAttribute("onclick") == index) {
        event.click();
      }
    },
    getTemplate_uiControl27: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  render: function () {\n         var data = this.props.data.customData;\n     return <div className=\"party-tip\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>;  \n      },\n  onClick: function(e){\n   var target = e.target;\n    if(target.tagName == \"A\"){\n     var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n\t\tif(handler){\n     handler({\n       data: index\n      })\n    }\n  }\n  });\nexport default TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"party-tip\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"A\") {\n      var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control4: function (elem) {
      if (elem.querySelector("input")) {
        var inIpt = elem.getElementsByTagName("input")[0];
        return {
          val: inIpt.value,
          name: inIpt.getAttribute("name"),
          type: inIpt.getAttribute("type")
        };
      } else if (elem.querySelector("a")) {
        var aA = elem.getElementsByTagName("a")[0];
        return {
          con: aA.innerText
        };
      }
    },
    doAction_uiControl6: function (data, elem) {
      elem.querySelector("a").click();
    },
    getTemplate_uiControl6: function () {
      var selfTemplate = "const Data = React.createClass({\n  \trender: function() {\n  \tvar data = this.props.data.customData;\n    if(data.type===\"text\"){\n    return (\n    \t<span>\n        <input value={data.val} name={data.name} type={data.type}/>\n      </span>\n    );\n      }\n    else if(data.type===\"hidden\"){\n      return(   \n        <span>\n          <input value={data.val} name={data.name} type={data.type}/>\n          <span>{data.val}</span>\n        </span>\n      )\n        }\n      else{\n      return (\n        <span className = \"y_aA\" onClick={this.onClick}>{data.con}</span>\n        )\n      } \n  },\n  onClick: function(e) {\n    var handler = this.props.customHandler;\n    handler({\n    });\n  }\n});\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data.type === \"text\") {\n      return React.createElement(\n        \"span\",\n        null,\n        React.createElement(\"input\", { value: data.val, name: data.name, type: data.type })\n      );\n    } else if (data.type === \"hidden\") {\n      return React.createElement(\n        \"span\",\n        null,\n        React.createElement(\"input\", { value: data.val, name: data.name, type: data.type }),\n        React.createElement(\n          \"span\",\n          null,\n          data.val\n        )\n      );\n    } else {\n      return React.createElement(\n        \"span\",\n        { className: \"y_aA\", onClick: this.onClick },\n        data.con\n      );\n    }\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = Data;";
    },
    getData_control8: function (elem) {
      var clone = elem.cloneNode(true);var getLi = clone.querySelectorAll("li");for (var i = 0; i < getLi.length; i++) {
        var haveTime = getLi[i].querySelector("span[name='sj']");if (haveTime.innerText != "") {
          getLi[i].setAttribute("id", "pass");
        }
      }return clone.innerHTML.replace(/onclick/ig, "data-oldEvent");
    },
    doAction_uiControl13: function (data, elem) {
      var index = data.dataCustom;var event = elem.querySelectorAll("a");for (let i = 0; i < event.length; i++) {
        if (event[i].getAttribute("onclick") == index) {
          event[i].click();
        }
      }
    },
    getTemplate_uiControl13: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  render: function () {\n  var data = this.props.data.customData;\n     return <table className=\"process-show\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></table>;  \n      },\n  onClick: function(e){\n   var target = e.target;\n    console.log(target.tagName);\n    if(target.tagName == \"A\"){\n     var index = target.getAttribute(\"data-oldEvent\");\n    } else if(target.tagName == \"I\"){\n      var index = target.parentNode.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\nif(handler){\n     handler({\n       data: index\n      })\n    }\n  }\n  });\nexport default TaskList;\n";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n    value: true\n});\nvar TaskList = React.createClass({\n    displayName: \"TaskList\",\n\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"table\", { className: \"process-show\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    },\n    onClick: function onClick(e) {\n        var target = e.target;\n        console.log(target.tagName);\n        if (target.tagName == \"A\") {\n            var index = target.getAttribute(\"data-oldEvent\");\n        } else if (target.tagName == \"I\") {\n            var index = target.parentNode.getAttribute(\"data-oldEvent\");\n        }\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: index\n            });\n        }\n    }\n});\nexports.default = TaskList;";
    },
    getData_control1067: function (elem) {
      var ta = elem.cloneNode(true);var ip = ta.querySelectorAll("input");if (ip.length == 2) {
        ip[0].className = "xg_two_btn";ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");return ta.innerHTML;
    },
    doAction_uiControl1241: function (data, elem) {
      var aa = elem.querySelectorAll("input");for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl1241: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);