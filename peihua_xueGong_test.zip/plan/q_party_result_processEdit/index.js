(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control9: function (elem) {
      var target = elem.querySelectorAll("tr")[2];
      return target.querySelector("th").innerHTML;
    },
    doAction_uiControl0: function (data, elem) {},
    getTemplate_uiControl0: function () {
      var selfTemplate = "var Data = React.createClass({\n\trender: function(){\n  \tvar data = this.props.data.customData;\n    return <span className=\"textarea-hd\" dangerouslySetInnerHTML={{__html: data}}></span>;  \n  }\n})\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"span\", { className: \"textarea-hd\", dangerouslySetInnerHTML: { __html: data } });\n  }\n});\nexports.default = Data;";
    }
  });
})(window, ysp);