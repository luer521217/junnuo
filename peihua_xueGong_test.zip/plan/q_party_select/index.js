(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control25: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td");
        oDiv.push({
          id: inTd[0].innerText,
          name: inTd[1].innerText,
          gender: inTd[2].innerText,
          college: inTd[3].innerText,
          skill: inTd[4].innerText,
          class: inTd[5].innerText,
          btn: inTd[6].innerHTML.replace(/onclick/ig, "data-oldEvent")
        });
      }

      return oDiv;
    },
    doAction_uiControl9: function (data, elem) {
      var index = data.dataCustom;
      var event = elem.querySelectorAll("label");

      for (let i = 0; i < event.length; i++) {
        if (event[i].getAttribute("onclick") == index) {
          event[i].click();
        }
      }
    },
    getTemplate_uiControl9: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=e.target;\n    if(target.tagName == \"LABEL\"){\n    \tvar index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if(handler){\n     handler({\n       data: index\n      })\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>学号：</b>\n                {item.id}</span>\n              <font>\n                <b>姓名：</b>\n                {item.name}</font>\n              <font>\n                <b>性别：</b>\n                {item.gender}</font>\n              <span>\n                <b>学院：</b>\n                {item.college}</span> \n              <span>\n                <b>专业：</b>\n                {item.skill}</span>\n              <span>\n                <b>班级：</b>\n                {item.class}</span>\n              \n                <span className=\"select-btn\"><b>操作：</b>\n                <section dangerouslySetInnerHTML={{__html: item.btn}}></section></span>\n               </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n              <div className=\"lv_dbsy_rest\"><span>\n                <b>学号：</b>\n                {item.id}</span>\n              <font>\n                <b>姓名：</b>\n                {item.name}</font>\n              <font>\n                <b>性别：</b>\n                {item.gender}</font>\n              <span>\n                <b>学院：</b>\n                {item.college}</span> \n              <span>\n                <b>专业：</b>\n                {item.skill}</span>\n              <span>\n                <b>班级：</b>\n                {item.class}</span>\n              \n                <span className=\"select-btn\"><b>操作：</b>\n                <section dangerouslySetInnerHTML={{__html: item.btn}}></section></span>\n               </div>\n          </li>\n\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\" onClick={this.onClick}>{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName == \"LABEL\") {\n      var index = target.getAttribute(\"data-oldEvent\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学号：\"\n                ),\n                item.id\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"姓名：\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"性别：\"\n                ),\n                item.gender\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学院：\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"专业：\"\n                ),\n                item.skill\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"班级：\"\n                ),\n                item.class\n              ),\n              React.createElement(\n                \"span\",\n                { className: \"select-btn\" },\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"操作：\"\n                ),\n                React.createElement(\"section\", { dangerouslySetInnerHTML: { __html: item.btn } })\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学号：\"\n                ),\n                item.id\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"姓名：\"\n                ),\n                item.name\n              ),\n              React.createElement(\n                \"font\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"性别：\"\n                ),\n                item.gender\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"学院：\"\n                ),\n                item.college\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"专业：\"\n                ),\n                item.skill\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"班级：\"\n                ),\n                item.class\n              ),\n              React.createElement(\n                \"span\",\n                { className: \"select-btn\" },\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"操作：\"\n                ),\n                React.createElement(\"section\", { dangerouslySetInnerHTML: { __html: item.btn } })\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },
    getData_control26: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].textContent,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl11: function (data, elem) {},
    getTemplate_uiControl11: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control32: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl19: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl19: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control1110: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl1293: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl1293: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);