(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {},
    doAction_uiControl1: function (data, elem) {
      ysp.source.postMessage({
        resultType: "EAPI:back"
      });
    },
    getTemplate_uiControl1: function () {
      var selfTemplate = "const Data = React.createClass({ \n  render: function () { \n    var data = this.props.data.customData;\n    return <button className=\"xg_back\" onClick={this.onClick} >返回</button>;  \n  },\n  onClick: function(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    } \n  }\n}); \n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"button\",\n      { className: \"xg_back\", onClick: this.onClick },\n      \"返回\"\n    );\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"class\");\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control3: function (elem) {
      var iDiv = elem.getElementsByTagName("div"),
          oDiv = [];

      for (var i = 0; i < iDiv.length; i++) {
        oDiv.push({
          id: iDiv[i].getAttribute("id"),
          txt: iDiv[i].textContent
        });
      }

      return oDiv;
    },
    doAction_uiControl7: function (data, elem) {
      var myId = data.dataCustom;
      var iDiv = elem.getElementsByTagName("div");

      for (var i = 0; i < iDiv.length; i++) {
        var iId = iDiv[i].getAttribute("id");

        if (iId == myId) {
          iDiv[i].click();
        }
      }
    },
    getTemplate_uiControl7: function () {
      var selfTemplate = "const Data = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    //console.log(data);\n    \n    var items = data.map(function(item, index){\n    \n      return (\n      \t<option value={item.id}>{item.txt}</option>\n      );\n    \n    });\n    \n    return (\n      <section>\n      <select className=\"w_search_select\" onChange={this.onchange}>{items}</select>\n      </section>\n    );\n  },\n  onchange: function(e) {\n  \tvar target = e.target;\n    var val = target.value;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n    \t handler({\n         data : val\n       })\n    }\n    \n  }\n});\n\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    //console.log(data);\n\n    var items = data.map(function (item, index) {\n\n      return React.createElement(\n        \"option\",\n        { value: item.id },\n        item.txt\n      );\n    });\n\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { className: \"w_search_select\", onChange: this.onchange },\n        items\n      )\n    );\n  },\n  onchange: function onchange(e) {\n    var target = e.target;\n    var val = target.value;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: val\n      });\n    }\n  }\n});\n\nexports.default = Data;";
    },
    getData_control8: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl12: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl12: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control9: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].innerText,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl14: function (data, elem) {},
    getTemplate_uiControl14: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control14: function (elem) {
      if (elem) {
        var inTr = elem.getElementsByTagName("tr"),
            trLen = inTr.length,
            oDiv = [];
        var i;

        for (i = 0; i < trLen; i++) {
          inTd = inTr[i].getElementsByTagName("td"), tdLen = inTd.length, inSpan = inTd[0].getElementsByTagName("input")[0];

          if (inSpan == undefined) {
            oDiv.push({
              error: inTd[0].innerText
            });
          } else {
            oDiv.push({
              selectBoxId: inTd[0].getElementsByTagName("input")[0].checked,
              a: inTd[1].innerText,
              b: inTd[2].innerText,
              c: inTd[3].innerText,
              d: inTd[4].innerText,
              e: inTd[6].innerText
            });
          }
        }

        return oDiv;
      }
    },
    doAction_uiControl20: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var aip = elem.getElementsByTagName("tr")[index];

      if (type == "input") {
        aip.dispatchEvent(new Event("click"));
      } else {
        aip.getElementsByTagName("a")[0].dispatchEvent(new Event("click"));
      }
    },
    getTemplate_uiControl20: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var val;\n    var all=target.parentNode.childNodes;\n    for(var i=0;i<all.length;i++){\n      if(all[i].querySelector(\"input\").checked){\n        all[i].className=(\"lv_dbsy_li lv_bgon\");\n      }else{\n      \tall[i].className=(\"lv_dbsy_li\");\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n\t\t\t  return findR(elem.parentNode);\n      }\n    }    \n    var type = \"li\";\n    if ( nName === \"INPUT\" ) {\n      type = \"input\";\n    } else if(nName===\"A\"){\n    \tval=e.target.getAttribute(\"class\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index,\n            \"val\":val\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    if( data[0].error ){\n      var items2=data[0].error;\n         return (\n           <div className=\"w_jxsb_table\"><h2>{items2}</h2></div>\n      );\n      }else{\n    var items = data.map( function(item, index) {\n      if(item.selectBoxId){\n       return(\n        <li data-index={index} className=\"lv_dbsy_li lv_bgon\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\"><span>\n               <b>\u5E74\u7EA7\uFF1A</b>\n                {item.a}</span>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.b}</span>\n              <span>\n                <b>\u4E13\u4E1A\uFF1A</b>\n                {item.c}</span> \n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.d}</span> \n              <span>\n                <b>\u73ED\u7EA7\u603B\u4EBA\u6570\uFF1A</b>\n                {item.e}</span>  \n               </div>\n          </li>\n\n\n        ); \n      }else{\n         return (\n          <li data-index={index} className=\"lv_dbsy_li\">\n               <div className=\"lv_dbsy_ip\"> <input type=\"checkbox\" checked={item.selectBoxId}/> </div>\n              <div className=\"lv_dbsy_rest\"><span>\n              <b>\u5E74\u7EA7\uFF1A</b>\n                {item.a}</span>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.b}</span>\n              <span>\n                <b>\u4E13\u4E1A\uFF1A</b>\n                {item.c}</span> \n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.d}</span> \n              <span>\n                <b>\u73ED\u7EA7\u603B\u4EBA\u6570\uFF1A</b>\n                {item.e}</span>  \n               </div>\n          </li>\n\n        ); \n      }\n      })\n    return <ul className=\"lv_dbsy_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = findR(e.target);\n    var index = target.getAttribute(\"data-index\");\n    var nName = e.target.nodeName;\n    var val;\n    var all = target.parentNode.childNodes;\n    for (var i = 0; i < all.length; i++) {\n      if (all[i].querySelector(\"input\").checked) {\n        all[i].className = \"lv_dbsy_li lv_bgon\";\n      } else {\n        all[i].className = \"lv_dbsy_li\";\n      }\n    }\n    function findR(elem) {\n      if (elem.tagName === \"LI\") {\n        return elem;\n      } else {\n        return findR(elem.parentNode);\n      }\n    }\n    var type = \"li\";\n    if (nName === \"INPUT\") {\n      type = \"input\";\n    } else if (nName === \"A\") {\n      val = e.target.getAttribute(\"class\");\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index,\n          \"val\": val\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data[0].error) {\n      var items2 = data[0].error;\n      return React.createElement(\n        \"div\",\n        { className: \"w_jxsb_table\" },\n        React.createElement(\n          \"h2\",\n          null,\n          items2\n        )\n      );\n    } else {\n      var items = data.map(function (item, index) {\n        if (item.selectBoxId) {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li lv_bgon\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5E74\\u7EA7\\uFF1A\"\n                ),\n                item.a\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.b\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u4E13\\u4E1A\\uFF1A\"\n                ),\n                item.c\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.d\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\u603B\\u4EBA\\u6570\\uFF1A\"\n                ),\n                item.e\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            \"li\",\n            { \"data-index\": index, className: \"lv_dbsy_li\" },\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_ip\" },\n              \" \",\n              React.createElement(\"input\", { type: \"checkbox\", checked: item.selectBoxId }),\n              \" \"\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"lv_dbsy_rest\" },\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5E74\\u7EA7\\uFF1A\"\n                ),\n                item.a\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u5B66\\u9662\\uFF1A\"\n                ),\n                item.b\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u4E13\\u4E1A\\uFF1A\"\n                ),\n                item.c\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\uFF1A\"\n                ),\n                item.d\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                React.createElement(\n                  \"b\",\n                  null,\n                  \"\\u73ED\\u7EA7\\u603B\\u4EBA\\u6570\\uFF1A\"\n                ),\n                item.e\n              )\n            )\n          );\n        }\n      });\n      return React.createElement(\n        \"ul\",\n        { className: \"lv_dbsy_ul\", onClick: this.onClick },\n        items\n      );\n    }\n  }\n});\nexports.default = TaskList;";
    },

    getData_control17: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      for (var i = 0; i < ip.length; i++) {
        ip[i].removeAttribute("onclick");
      }

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      return ta.innerHTML;
    },
    doAction_uiControl29: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl29: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});\n";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);