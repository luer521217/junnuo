(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1261: function (elem) {
      var dom = elem.cloneNode(true);
      var aA = dom.querySelectorAll("a");

      for (var i = 0; i < aA.length; i++) {
        var td = aA[i].parentNode;
        td.textContent = aA[i].textContent;
        td.setAttribute("data-index", i);
        td.setAttribute("class", "y_color");
      }

      var res = dom.outerHTML;
      return res;
    },
    doAction_uiControl1467: function (data, elem) {
      var index = data.dataCustom;
      elem.querySelectorAll("a")[index].dispatchEvent(new Event("click"));
    },
    getTemplate_uiControl1467: function () {
      var selfTemplate = "const MyList = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"y_table_aa\" onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}} />\n  },\n  onClick: function(e) {\n  \tvar target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    if (index) {\n      var handler = this.props.customHandler;\n      handler({\n      \tdata: index\n      });\n    }\n  }\n});\nexport default MyList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyList = React.createClass({\n  displayName: \"MyList\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"div\", { className: \"y_table_aa\", onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n  },\n  onClick: function onClick(e) {\n    var target = e.target;\n    var index = target.getAttribute(\"data-index\");\n    if (index) {\n      var handler = this.props.customHandler;\n      handler({\n        data: index\n      });\n    }\n  }\n});\nexports.default = MyList;";
    }
  });
})(window, ysp);