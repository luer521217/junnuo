(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control737: function (elem) {
      return elem.innerHTML;
    },
    doAction_uiControl828: function (data, elem) {
      elem.querySelector('a').click();
    },
    getTemplate_uiControl828: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n\t\t\t<table onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"zgxs-bd\"></table>\n    )\n  },\n  \n  onClick: function(e){\n  \tvar target = e.target;\n    if(target.tagName === \"A\"){\n    \t\xA0var\xA0handler\xA0=\xA0this.props.customHandler;\nif(handler){\n\xA0\xA0\xA0\xA0 handler({\n\xA0\xA0\xA0\xA0\xA0\xA0})\n\xA0\xA0\xA0\xA0}\n\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data }, className: \"zgxs-bd\" });\n  },\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName === \"A\") {\n      var handler = this.props.customHandler;\n      if (handler) {\n        handler({});\n      }\n    }\n  }\n});";
    }
  });
})(window, ysp);