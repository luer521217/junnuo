(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control547: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl571: function (data, elem) {},
    getTemplate_uiControl571: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n\t\t<table className='y_info y_info2' dangerouslySetInnerHTML={{__html:\xA0data}}></table>\n    )\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement('table', { className: 'y_info y_info2', dangerouslySetInnerHTML: { __html: data } });\n  }\n});";
    },
    getData_control548: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl572: function (data, elem) {},
    getTemplate_uiControl572: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n\t\t<table className='y_info y_info2' dangerouslySetInnerHTML={{__html:\xA0data}}></table>\n    )\n  }\n});";
      return "'use strict';\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement('table', { className: 'y_info y_info2', dangerouslySetInnerHTML: { __html: data } });\n  }\n});";
    }
  });
})(window, ysp);