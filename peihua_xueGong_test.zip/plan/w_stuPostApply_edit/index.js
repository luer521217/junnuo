(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control702: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl788: function (data, elem) {
      elem.querySelector('a').click();
    },
    getTemplate_uiControl788: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table \xA0onClick={this.onClick}\xA0dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info y_info2\">\n      </table>\n    )\n  },\n  \n  onClick: function(e){\n  \tvar target = e.target;\n    if(target.tagName === \"A\") {\n    \tvar\xA0handler\xA0=\xA0this.props.customHandler;\n\t\t\t\tif(handler){\n\xA0\xA0\xA0\xA0 \t\t\thandler({})\n\xA0\xA0\xA0\xA0\t\t}\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data }, className: \"y_info y_info2\" });\n  },\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    if (target.tagName === \"A\") {\n      var handler = this.props.customHandler;\n      if (handler) {\n        handler({});\n      }\n    }\n  }\n});";
    },
    getData_control705: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl792: function (data, elem) {},
    getTemplate_uiControl792: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info y_info2\"></table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info y_info2\" });\n  }\n});";
    },
    getData_control732: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl821: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl821: function () {
      var selfTemplate = "\nmodule.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);