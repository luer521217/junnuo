(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control692: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl777: function (data, elem) {
      elem.querySelector('a').click();
    },
    getTemplate_uiControl777: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table dangerouslySetInnerHTML={{__html:\xA0data}} onClick={this.handleClick} className=\"y_info y_info2\"></table>\n    )\n  },\n  handleClick: function(e){\n  \tvar target = e.target;\n    if(target.tagName === \"A\") {\n    \t\xA0var\xA0handler\xA0=\xA0this.props.customHandler;\n      if(handler){\n\xA0\xA0\xA0\xA0 handler({})\n\xA0\xA0\xA0\xA0}\n\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, onClick: this.handleClick, className: \"y_info y_info2\" });\n  },\n  handleClick: function handleClick(e) {\n    var target = e.target;\n    if (target.tagName === \"A\") {\n      var handler = this.props.customHandler;\n      if (handler) {\n        handler({});\n      }\n    }\n  }\n});";
    },
    getData_control694: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl779: function (data, elem) {},
    getTemplate_uiControl779: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info y_info2\"></table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info y_info2\" });\n  }\n});";
    },
    getData_control696: function (elem) {
      return elem.outerHTML;
    },
    doAction_uiControl781: function (data, elem) {},
    getTemplate_uiControl781: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    return (\n      <table dangerouslySetInnerHTML={{__html:\xA0data}} className=\"y_info y_info2\"></table>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data }, className: \"y_info y_info2\" });\n  }\n});";
    }
  });
})(window, ysp);