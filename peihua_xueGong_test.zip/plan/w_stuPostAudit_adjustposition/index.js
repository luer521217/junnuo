(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control121: function (elem) {},
    doAction_uiControl209: function (data, elem) {
      elem.querySelector(".ui_close").click();
    },
    getTemplate_uiControl209: function () {
      var selfTemplate = "const MyBack = React.createClass({\n  render: function() {\n    return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n  },\n  onClick: function() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    },
    getData_control122: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td");

        if (inTd.length > 5) {
          oDiv.push({
            a: inTd[2].innerText,
            b: inTd[3].innerText,
            c: inTd[4].innerText,
            d: inTd[5].innerText,
            e: inTd[6].innerText,
            f: inTd[7].innerText,
            g: inTd[8].innerText,
            h: inTd[9].innerText,
            note: inTd[11].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl210: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var iBtn = elem.getElementsByTagName("label");

      if (type == "button") {
        iBtn[index].click();
      }
    },
    getTemplate_uiControl210: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=e.target;\n    var nName = e.target.nodeName;\n    \n    if ( nName === \"BUTTON\" ) {\n    var index = target.parentNode.getAttribute(\"data-index\"),\n        type = \"button\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    var items = data.map( function(item, index) {\n      \n         return (\n          <li className=\"lv_grc_li\">\n               <span> <b>\u7528\u4EBA\u5355\u4F4D\uFF1A</b>\n                {item.a}</span>\n              <span>\n                <b>\u5C97\u4F4D\u540D\u79F0\uFF1A</b>\n                {item.b}</span>\n              <span>\n                <b>\u5C97\u4F4D\u6027\u8D28\uFF1A</b>\n                {item.c}</span>\n              <span>\n                <b>\u5C97\u4F4D\u6709\u6548\u65F6\uFF1A</b>\n                {item.d}</span> \n              <span>\n                <b>\u9700\u6C42\u4EBA\u6570\uFF1A</b>\n                {item.e}</span>\n              <span>\n                <b>\u7533\u8BF7\u4EBA\u6570\uFF1A</b>\n                {item.f}</span>\n               <span>\n                <b>\u56F0\u96BE\u751F\u6570\uFF1A</b>\n                {item.g}</span>\n                <span>\n                <b>\u5728\u5C97\u4EBA\u6570\uFF1A</b>\n                {item.h}</span>\n              <span data-index={index}>\n                <b>\u64CD\u4F5C\uFF1A</b>\n                <button>{item.note}</button></span>\n          </li>\n\n\n        ); \n      })\n    return <ul className=\"lv_grc_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    var nName = e.target.nodeName;\n\n    if (nName === \"BUTTON\") {\n      var index = target.parentNode.getAttribute(\"data-index\"),\n          type = \"button\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n\n      return React.createElement(\n        \"li\",\n        { className: \"lv_grc_li\" },\n        React.createElement(\n          \"span\",\n          null,\n          \" \",\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u7528\\u4EBA\\u5355\\u4F4D\\uFF1A\"\n          ),\n          item.a\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u5C97\\u4F4D\\u540D\\u79F0\\uFF1A\"\n          ),\n          item.b\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u5C97\\u4F4D\\u6027\\u8D28\\uFF1A\"\n          ),\n          item.c\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u5C97\\u4F4D\\u6709\\u6548\\u65F6\\uFF1A\"\n          ),\n          item.d\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u9700\\u6C42\\u4EBA\\u6570\\uFF1A\"\n          ),\n          item.e\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u7533\\u8BF7\\u4EBA\\u6570\\uFF1A\"\n          ),\n          item.f\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u56F0\\u96BE\\u751F\\u6570\\uFF1A\"\n          ),\n          item.g\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u5728\\u5C97\\u4EBA\\u6570\\uFF1A\"\n          ),\n          item.h\n        ),\n        React.createElement(\n          \"span\",\n          { \"data-index\": index },\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u64CD\\u4F5C\\uFF1A\"\n          ),\n          React.createElement(\n            \"button\",\n            null,\n            item.note\n          )\n        )\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { className: \"lv_grc_ul\", onClick: this.onClick },\n      items\n    );\n  }\n});\nexports.default = TaskList;";
    },
    getData_control135: function (elem) {
      var currentPage = elem.querySelector("#pageNum");
      var totalPage = elem.querySelector("#pageCount");
      var totalRecords = elem.querySelector("#rowConut");
      var oPage = {
        "currentPage": currentPage.value,
        "totalPage": totalPage.textContent,
        "totalRecords": totalRecords.textContent
      };
      return oPage;
    },
    doAction_uiControl229: function (data, elem) {},
    getTemplate_uiControl229: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>\u7B2C{data.currentPage}\u9875/\u5171<p className=\"red\">{data.totalPage}</p>\u9875</span><span>\u603B\u5171<p className=\"red\">{data.totalRecords}</p>\u6761\u8BB0\u5F55</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u7B2C\",\n        data.currentPage,\n        \"\\u9875/\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"\\u9875\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"\\u603B\\u5171\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"\\u6761\\u8BB0\\u5F55\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    }
  });
})(window, ysp);