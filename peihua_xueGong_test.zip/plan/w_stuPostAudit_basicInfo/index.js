(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control89: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl149: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl149: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n    return (\n      <div  className=\"w_xsgwsh_table\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_table\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control93: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl153: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl153: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n    return (\n      <div  className=\"w_xsgwsh_table\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_table\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control94: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl154: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl154: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n    return (\n      <div  className=\"w_xsgwsh_table\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_table\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    },
    getData_control95: function (elem) {
      if (elem) {
        var wholeHtml = elem.cloneNode(true);
        return wholeHtml.outerHTML.replace(/onclick/g, "data-click");
      }
    },
    doAction_uiControl155: function (data, elem) {
      var data = data.dataCustom;

      if (data == "A") {
        elem.getElementsByTagName("a")[0].click();
      }
    },
    getTemplate_uiControl155: function () {
      var selfTemplate = "var React = require('react');\n\nmodule.exports = React.createClass({\n  render: function(){\n    var data = this.props.data.customData;\n    \n    return (\n      <div  className=\"w_xsgwsh_tableLong\" onClick={this.onclick}>\n      <table dangerouslySetInnerHTML={{__html: data}}></table>\n      </div>\n    )\n  },\n  onclick: function(e) {\n  \tvar target = e.target;\n    \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
      return "\"use strict\";\n\nvar React = require('react');\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n\n    return React.createElement(\n      \"div\",\n      { className: \"w_xsgwsh_tableLong\", onClick: this.onclick },\n      React.createElement(\"table\", { dangerouslySetInnerHTML: { __html: data } })\n    );\n  },\n  onclick: function onclick(e) {\n    var target = e.target;\n\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: target.tagName\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);