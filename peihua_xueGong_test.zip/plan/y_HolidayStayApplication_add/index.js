(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control1199: function (elem) {
      if (elem.querySelector("input")) {
        var inIpt = elem.getElementsByTagName("input")[0];
        return {
          val: inIpt.value,
          name: inIpt.getAttribute("name"),
          type: inIpt.getAttribute("type")
        };
      } else if (elem.querySelector("a")) {
        var aA = elem.getElementsByTagName("a")[0];
        return {
          con: aA.innerText
        };
      }
    },
    doAction_uiControl1382: function (data, elem) {
      elem.querySelector("a").click();
    },
    getTemplate_uiControl1382: function () {
      var selfTemplate = "const Data = React.createClass({\n  \trender: function() {\n  \tvar data = this.props.data.customData;\n    if(data.type===\"text\"){\n    return (\n    \t<span>\n        <input value={data.val} name={data.name} type={data.type}/>\n      </span>\n    );\n      }\n    else if(data.type===\"hidden\"){\n      return(   \n        <span>\n          <input value={data.val} name={data.name} type={data.type}/>\n          <span>{data.val}</span>\n        </span>\n      )\n        }\n      else{\n      return (\n        <span className = \"y_aA\" onClick={this.onClick}>{data.con}</span>\n        )\n      } \n  },\n  onClick: function(e) {\n    var handler = this.props.customHandler;\n    handler({\n    });\n  }\n});\nexport default Data;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Data = React.createClass({\n  displayName: \"Data\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    if (data.type === \"text\") {\n      return React.createElement(\n        \"span\",\n        null,\n        React.createElement(\"input\", { value: data.val, name: data.name, type: data.type })\n      );\n    } else if (data.type === \"hidden\") {\n      return React.createElement(\n        \"span\",\n        null,\n        React.createElement(\"input\", { value: data.val, name: data.name, type: data.type }),\n        React.createElement(\n          \"span\",\n          null,\n          data.val\n        )\n      );\n    } else {\n      return React.createElement(\n        \"span\",\n        { className: \"y_aA\", onClick: this.onClick },\n        data.con\n      );\n    }\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = Data;";
    },
    getData_control1224: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl1415: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl1415: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    }
  });
})(window, ysp);