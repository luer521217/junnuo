(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control0: function (elem) {
      var list = [];
      var getDiv = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < getDiv.length; i++) {
        list.push(getDiv[i].innerText);
      }

      return list;
    },
    doAction_uiControl106: function (data, elem) {
      var text = data.dataCustom;
      var origin = elem.querySelector("dd").querySelectorAll("div");

      for (let i = 0; i < origin.length; i++) {
        if (text == origin[i].innerText) {
          origin[i].click();
        }
      }
    },
    getTemplate_uiControl106: function () {
      var selfTemplate = "var Select = React.createClass({\n\trender: function(){\n\t\tvar data = this.props.data.customData;\n    var items = data.map(function(item){\n    \treturn <option>{item}</option>\n    });\n   return (\n     <section>\n       <select onChange={this.handleChange}>{items}</select>\n     </section>\n       )\n  },\n  handleChange: function(event){\n  \tvar text = event.target.value;\n  \tvar handler = this.props.customHandler;\n\t\tif(handler){\n    \thandler({\n      \tdata: text\n      })\n    }\n  }\n});\nexport default Select;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar Select = React.createClass({\n  displayName: \"Select\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item) {\n      return React.createElement(\n        \"option\",\n        null,\n        item\n      );\n    });\n    return React.createElement(\n      \"section\",\n      null,\n      React.createElement(\n        \"select\",\n        { onChange: this.handleChange },\n        items\n      )\n    );\n  },\n  handleChange: function handleChange(event) {\n    var text = event.target.value;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: text\n      });\n    }\n  }\n});\nexports.default = Select;";
    },
    getData_control4: function (elem) {
      var inTr = elem.getElementsByTagName("tr"),
          trLen = inTr.length,
          oDiv = [];
      var i;

      for (i = 0; i < trLen; i++) {
        inTd = inTr[i].getElementsByTagName("td");

        if (inTd.length > 5) {
          oDiv.push({
            s_id: inTd[0].innerText,
            name: inTd[1].innerText,
            sex: inTd[2].innerText,
            college: inTd[3].innerText,
            major: inTd[4].innerText,
            class: inTd[5].innerText,
            note: inTd[6].innerText
          });
        }
      }

      return oDiv;
    },
    doAction_uiControl110: function (data, elem) {
      var index = data.dataCustom.index;
      var type = data.dataCustom.type;
      var iBtn = elem.getElementsByTagName("label");
      ysp.runtime.Flow.setLastFlow("uiControl110", "context3");

      if (type == "button") {
        iBtn[index].click();
      }
    },
    getTemplate_uiControl110: function () {
      var selfTemplate = "const TaskList = React.createClass({\n  onClick:function(e){\n    var target=e.target;\n    var nName = e.target.nodeName;\n    \n    if ( nName === \"BUTTON\" ) {\n    var index = target.parentNode.getAttribute(\"data-index\"),\n        type = \"button\";\n    } \n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data:{\n            \"type\": type,\n            \"index\": index\n        }\n      });\n    }\n  },\n  render: function () {\n    var data = this.props.data.customData; \n    var items = data.map( function(item, index) {\n      \n         return (\n          <li className=\"lv_grc_li\">\n               <span> <b>\u5B66\u53F7\uFF1A</b>\n                {item.s_id}</span>\n              <font>\n                <b>\u59D3\u540D\uFF1A</b>\n                {item.name}</font>\n              <font>\n                <b>\u6027\u522B\uFF1A</b>\n                {item.sex}</font>\n              <span>\n                <b>\u5B66\u9662\uFF1A</b>\n                {item.college}</span> \n              <span>\n                <b>\u4E13\u4E1A\uFF1A</b>\n                {item.major}</span>\n              <span>\n                <b>\u73ED\u7EA7\uFF1A</b>\n                {item.class}</span>\n              <span data-index={index}>\n                <b>\u64CD\u4F5C\uFF1A</b>\n                <button>{item.note}</button></span>\n          </li>\n\n\n        ); \n      })\n    return <ul className=\"lv_grc_ul\"  onClick={this.onClick} >{items}</ul>\n  }\n});\t\nexport default TaskList;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar TaskList = React.createClass({\n  displayName: \"TaskList\",\n\n  onClick: function onClick(e) {\n    var target = e.target;\n    var nName = e.target.nodeName;\n\n    if (nName === \"BUTTON\") {\n      var index = target.parentNode.getAttribute(\"data-index\"),\n          type = \"button\";\n    }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          \"type\": type,\n          \"index\": index\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    var items = data.map(function (item, index) {\n\n      return React.createElement(\n        \"li\",\n        { className: \"lv_grc_li\" },\n        React.createElement(\n          \"span\",\n          null,\n          \" \",\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u5B66\\u53F7\\uFF1A\"\n          ),\n          item.s_id\n        ),\n        React.createElement(\n          \"font\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u59D3\\u540D\\uFF1A\"\n          ),\n          item.name\n        ),\n        React.createElement(\n          \"font\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u6027\\u522B\\uFF1A\"\n          ),\n          item.sex\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u5B66\\u9662\\uFF1A\"\n          ),\n          item.college\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u4E13\\u4E1A\\uFF1A\"\n          ),\n          item.major\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u73ED\\u7EA7\\uFF1A\"\n          ),\n          item.class\n        ),\n        React.createElement(\n          \"span\",\n          { \"data-index\": index },\n          React.createElement(\n            \"b\",\n            null,\n            \"\\u64CD\\u4F5C\\uFF1A\"\n          ),\n          React.createElement(\n            \"button\",\n            null,\n            item.note\n          )\n        )\n      );\n    });\n    return React.createElement(\n      \"ul\",\n      { className: \"lv_grc_ul\", onClick: this.onClick },\n      items\n    );\n  }\n});\nexports.default = TaskList;";
    },
    getData_control5: function (elem) {
      var aSpan = elem.querySelectorAll("span");
      var aInput = elem.querySelectorAll("input");
      var oPage = {
        "currentPage": aInput[0].value,
        "totalPage": aSpan[0].textContent,
        "totalRecords": aSpan[1].textContent
      };
      return oPage;
    },
    doAction_uiControl111: function (data, elem) {},
    getTemplate_uiControl111: function () {
      var selfTemplate = "const MyPage = React.createClass({\n\trender: function() {\n  \tvar data = this.props.data.customData;\n    return <div className=\"pagenation\"><span>第{data.currentPage}页/共<p className=\"red\">{data.totalPage}</p>页</span><span>总共<p className=\"red\">{data.totalRecords}</p>条记录</span></div>\n  }\n});\nexport default MyPage;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyPage = React.createClass({\n  displayName: \"MyPage\",\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"pagenation\" },\n      React.createElement(\n        \"span\",\n        null,\n        \"第\",\n        data.currentPage,\n        \"页/共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalPage\n        ),\n        \"页\"\n      ),\n      React.createElement(\n        \"span\",\n        null,\n        \"总共\",\n        React.createElement(\n          \"p\",\n          { className: \"red\" },\n          data.totalRecords\n        ),\n        \"条记录\"\n      )\n    );\n  }\n});\nexports.default = MyPage;";
    },
    getData_control192: function (elem) {
      var ta = elem.cloneNode(true);
      var ip = ta.querySelectorAll("input");

      if (ip.length == 2) {
        ip[0].className = "xg_two_btn";
        ip[1].className = "xg_two_btn1";
      } else if (ip.length == 1) {
        ip[0].className = "xg_one_btn";
      }

      ta.innerHTML = ta.innerHTML.replace(/onclick/g, "option");
      return ta.innerHTML;
    },
    doAction_uiControl217: function (data, elem) {
      var aa = elem.querySelectorAll("input");

      for (var i = 0; i < aa.length; i++) {
        var aId = aa[i].getAttribute("id");

        if (data.dataCustom == aId) {
          aa[i].click();
        }
      }
    },
    getTemplate_uiControl217: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function(e) { \n            var handler = this.props.customHandler;\n            if (handler) {\n                handler({\n                    data:e.target.getAttribute(\"id\")\n                });\n            }\n      },\n  render: function() {\n    var data = this.props.data.customData;\n   \treturn <div  onClick={this.onClick} dangerouslySetInnerHTML={{__html: data}}></div>; \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n    displayName: \"exports\",\n\n    onClick: function onClick(e) {\n        var handler = this.props.customHandler;\n        if (handler) {\n            handler({\n                data: e.target.getAttribute(\"id\")\n            });\n        }\n    },\n    render: function render() {\n        var data = this.props.data.customData;\n        return React.createElement(\"div\", { onClick: this.onClick, dangerouslySetInnerHTML: { __html: data } });\n    }\n});";
    },
    getData_control750: function (elem) {},
    doAction_uiControl844: function (data, elem) {
      elem.querySelector('.ui_close').click();
    },
    getTemplate_uiControl844: function () {
      var selfTemplate = "const MyBack = React.createClass({\n\xA0 render: function() {\n\xA0 \xA0 return <button onClick={this.onClick} className=\"xg_back\">\u8FD4\u56DE</button>\n\xA0 },\n\xA0 onClick: function() {\n\xA0 \xA0 var handler = this.props.customHandler;\n\xA0 \xA0 handler({});\n\xA0 }\n});\nexport default MyBack;";
      return "\"use strict\";\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar MyBack = React.createClass({\n  displayName: \"MyBack\",\n\n  render: function render() {\n    return React.createElement(\n      \"button\",\n      { onClick: this.onClick, className: \"xg_back\" },\n      \"\\u8FD4\\u56DE\"\n    );\n  },\n  onClick: function onClick() {\n    var handler = this.props.customHandler;\n    handler({});\n  }\n});\nexports.default = MyBack;";
    }
  });
})(window, ysp);